jQuery(document).ready(function($) {
  App.setup();
});

$(window).resize(function() {
  //Resize Stuff
});

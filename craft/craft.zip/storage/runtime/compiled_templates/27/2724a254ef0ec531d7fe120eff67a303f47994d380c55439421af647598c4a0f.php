<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layout */
class __TwigTemplate_0437c91353e9de31399ac532c9be81f0e6b2ab05dbc83fd43a5c705d39c4142c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layout");
        // line 1
        echo "<html lang=\"";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "app", []), "language", []), "html", null, true);
        echo "\">
  <head>
    <meta content=\"IE=edge\" http-equiv=\"X-UA-Compatible\">
    <meta charset=\"utf-8\"/>
    <title>";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["siteName"]) || array_key_exists("siteName", $context) ? $context["siteName"] : (function () { throw new RuntimeError('Variable "siteName" does not exist.', 5, $this->source); })()), "html", null, true);
        echo "</title>
    <meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\" name=\"viewport\">
    <link href=\"/styles.css\" rel=\"stylesheet\">
\t\t<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.14.0/css/all.css\" integrity=\"sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc\" crossorigin=\"anonymous\">
  ";
        // line 9
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>
  <body class=\"ltr\">";
        // line 10
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "
\t\t<header>
\t\t\t<nav>
\t\t\t\t<ul>
\t\t\t\t\t<li><a href=\"/\">Home</a></li>
\t\t\t\t\t<li><a href=\"/program\">Program</a></li>
\t\t\t\t\t<li><a href=\"/about\">About</a></li>
\t\t\t\t\t<li><a href=\"/logbook\">Logbook</a></li>
\t\t\t\t\t<li><a href=\"/stream\">Stream</a></li>
\t\t\t\t</ul>
\t\t\t</nav>
\t</header>
    <div class=\"container mx-auto px-4\">
      ";
        // line 23
        $this->displayBlock('content', $context, $blocks);
        // line 25
        echo "    </div>
\t\t<footer>
\t\t\t<div class=\"footer-contact\">
\t\t\t\t<p class=\"bold\">Contact</p>
\t\t\t\t<p class=\"text\"><a href=\"mailto:info@seekult.de\">info@seekult.de</a></p>
\t\t\t\t<p class=\"text\">Am Seemooser Horn 20</p>
\t\t\t\t<p class=\"text\">88045 Friedrichshafen, Germany</p>
\t\t\t</div>
\t\t\t<div class=\"footer-privacy\">
\t\t\t\t<p class=\"bold\">Privacy Policy</p>
\t\t\t\t<p class=\"text\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis tempore itaque nisi. Doloribus reprehenderit earum illo corporis accusamus necessitatibus sequi distinctio, voluptatem aliquam culpa. Voluptatibus, eaque incidunt! Sunt quidem suscipit inventore velit. Mollitia veritatis qui porro consequatur odit voluptate libero architecto sunt nobis labore! Magnam sed ducimus quidem iusto dolorum.</p>
\t\t\t</div>
\t\t</footer>
  ";
        // line 38
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), []);
        echo "</body>
</html>";
        craft\helpers\Template::endProfile("template", "_layout");
    }

    // line 23
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 24
        echo "      ";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "_layout";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 24,  98 => 23,  91 => 38,  76 => 25,  74 => 23,  58 => 10,  54 => 9,  47 => 5,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<html lang=\"{{ craft.app.language }}\">
  <head>
    <meta content=\"IE=edge\" http-equiv=\"X-UA-Compatible\">
    <meta charset=\"utf-8\"/>
    <title>{{ siteName }}</title>
    <meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\" name=\"viewport\">
    <link href=\"/styles.css\" rel=\"stylesheet\">
\t\t<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.14.0/css/all.css\" integrity=\"sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc\" crossorigin=\"anonymous\">
  </head>
  <body class=\"ltr\">
\t\t<header>
\t\t\t<nav>
\t\t\t\t<ul>
\t\t\t\t\t<li><a href=\"/\">Home</a></li>
\t\t\t\t\t<li><a href=\"/program\">Program</a></li>
\t\t\t\t\t<li><a href=\"/about\">About</a></li>
\t\t\t\t\t<li><a href=\"/logbook\">Logbook</a></li>
\t\t\t\t\t<li><a href=\"/stream\">Stream</a></li>
\t\t\t\t</ul>
\t\t\t</nav>
\t</header>
    <div class=\"container mx-auto px-4\">
      {% block content %}
      {% endblock %}
    </div>
\t\t<footer>
\t\t\t<div class=\"footer-contact\">
\t\t\t\t<p class=\"bold\">Contact</p>
\t\t\t\t<p class=\"text\"><a href=\"mailto:info@seekult.de\">info@seekult.de</a></p>
\t\t\t\t<p class=\"text\">Am Seemooser Horn 20</p>
\t\t\t\t<p class=\"text\">88045 Friedrichshafen, Germany</p>
\t\t\t</div>
\t\t\t<div class=\"footer-privacy\">
\t\t\t\t<p class=\"bold\">Privacy Policy</p>
\t\t\t\t<p class=\"text\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis tempore itaque nisi. Doloribus reprehenderit earum illo corporis accusamus necessitatibus sequi distinctio, voluptatem aliquam culpa. Voluptatibus, eaque incidunt! Sunt quidem suscipit inventore velit. Mollitia veritatis qui porro consequatur odit voluptate libero architecto sunt nobis labore! Magnam sed ducimus quidem iusto dolorum.</p>
\t\t\t</div>
\t\t</footer>
  </body>
</html>", "_layout", "/home/ubuntu/sites/seekult-nitro/craft/templates/_layout.twig");
    }
}

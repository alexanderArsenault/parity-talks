<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms */
class __TwigTemplate_c81fcbd19545694d2761e107c82433babe460e3fb7ad3bc6f69e38a2801a2ea4 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $macros["_self"] = $this->macros["_self"] = $this;
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms");
        // line 4
        echo "

";
        // line 7
        echo "

";
        // line 12
        echo "

";
        // line 17
        echo "

";
        // line 22
        echo "

";
        // line 27
        echo "

";
        // line 32
        echo "

";
        // line 37
        echo "

";
        // line 42
        echo "

";
        // line 47
        echo "

";
        // line 52
        echo "

";
        // line 57
        echo "

";
        // line 62
        echo "

";
        // line 67
        echo "

";
        // line 72
        echo "

";
        // line 77
        echo "

";
        // line 82
        echo "

";
        // line 87
        echo "

";
        // line 92
        echo "

";
        // line 97
        echo "

";
        // line 102
        echo "

";
        // line 107
        echo "

";
        // line 112
        echo "

";
        // line 115
        echo "

";
        // line 120
        echo "

";
        // line 135
        echo "

";
        // line 140
        echo "

";
        // line 145
        echo "

";
        // line 150
        echo "

";
        // line 155
        echo "

";
        // line 160
        echo "

";
        // line 171
        echo "

";
        // line 176
        echo "

";
        // line 181
        echo "

";
        // line 186
        echo "

";
        // line 205
        echo "

";
        // line 210
        echo "

";
        // line 215
        echo "

";
        // line 220
        echo "

";
        // line 225
        echo "

";
        // line 234
        echo "

";
        // line 240
        echo "

";
        // line 245
        echo "

";
        // line 268
        echo "

";
        // line 275
        echo "

";
        // line 278
        echo "

";
        craft\helpers\Template::endProfile("template", "_includes/forms");
    }

    // line 1
    public function macro_errorList($__errors__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "errors" => $__errors__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "errorList");
            // line 2
            echo "    ";
            $this->loadTemplate("_includes/forms/errorList", "_includes/forms", 2)->display($context);
            craft\helpers\Template::endProfile("macro", "errorList");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 9
    public function macro_hidden($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "hidden");
            // line 10
            $this->loadTemplate("_includes/forms/hidden", "_includes/forms", 10)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 10, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "hidden");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 14
    public function macro_text($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "text");
            // line 15
            echo "    ";
            $this->loadTemplate("_includes/forms/text", "_includes/forms", 15)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 15, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "text");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 19
    public function macro_password($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "password");
            // line 20
            echo "    ";
            $this->loadTemplate("_includes/forms/password", "_includes/forms", 20)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 20, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "password");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 24
    public function macro_copytext($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "copytext");
            // line 25
            echo "    ";
            $this->loadTemplate("_includes/forms/copytext", "_includes/forms", 25)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 25, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "copytext");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 29
    public function macro_date($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "date");
            // line 30
            echo "    ";
            $this->loadTemplate("_includes/forms/date", "_includes/forms", 30)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 30, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "date");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 34
    public function macro_time($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "time");
            // line 35
            echo "    ";
            $this->loadTemplate("_includes/forms/time", "_includes/forms", 35)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 35, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "time");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 39
    public function macro_color($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "color");
            // line 40
            echo "    ";
            $this->loadTemplate("_includes/forms/color", "_includes/forms", 40)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 40, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "color");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 44
    public function macro_textarea($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "textarea");
            // line 45
            echo "    ";
            $this->loadTemplate("_includes/forms/textarea", "_includes/forms", 45)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 45, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "textarea");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 49
    public function macro_select($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "select");
            // line 50
            echo "    ";
            $this->loadTemplate("_includes/forms/select", "_includes/forms", 50)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 50, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "select");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 54
    public function macro_multiselect($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "multiselect");
            // line 55
            echo "    ";
            $this->loadTemplate("_includes/forms/multiselect", "_includes/forms", 55)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 55, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "multiselect");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 59
    public function macro_checkbox($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkbox");
            // line 60
            echo "    ";
            $this->loadTemplate("_includes/forms/checkbox", "_includes/forms", 60)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 60, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkbox");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 64
    public function macro_checkboxGroup($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxGroup");
            // line 65
            echo "    ";
            $this->loadTemplate("_includes/forms/checkboxGroup", "_includes/forms", 65)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 65, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkboxGroup");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 69
    public function macro_checkboxSelect($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxSelect");
            // line 70
            echo "    ";
            $this->loadTemplate("_includes/forms/checkboxSelect", "_includes/forms", 70)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 70, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "checkboxSelect");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 74
    public function macro_radio($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "radio");
            // line 75
            echo "    ";
            $this->loadTemplate("_includes/forms/radio", "_includes/forms", 75)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 75, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "radio");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 79
    public function macro_radioGroup($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "radioGroup");
            // line 80
            echo "    ";
            $this->loadTemplate("_includes/forms/radioGroup", "_includes/forms", 80)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 80, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "radioGroup");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 84
    public function macro_file($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "file");
            // line 85
            echo "    ";
            $this->loadTemplate("_includes/forms/file", "_includes/forms", 85)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 85, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "file");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 89
    public function macro_lightswitch($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "lightswitch");
            // line 90
            echo "    ";
            $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms", 90)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 90, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "lightswitch");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 94
    public function macro_editableTable($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "editableTable");
            // line 95
            echo "    ";
            $this->loadTemplate("_includes/forms/editableTable", "_includes/forms", 95)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 95, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "editableTable");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 99
    public function macro_elementSelect($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "elementSelect");
            // line 100
            echo "    ";
            $this->loadTemplate("_includes/forms/elementSelect", "_includes/forms", 100)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 100, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "elementSelect");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 104
    public function macro_autosuggest($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "autosuggest");
            // line 105
            echo "    ";
            $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms", 105)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 105, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "autosuggest");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 109
    public function macro_fieldLayoutDesigner($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "fieldLayoutDesigner");
            // line 110
            echo "    ";
            $this->loadTemplate("_includes/forms/fieldLayoutDesigner", "_includes/forms", 110)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 110, $this->source); })())));
            craft\helpers\Template::endProfile("macro", "fieldLayoutDesigner");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 117
    public function macro_field($__config__ = null, $__input__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "input" => $__input__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "field");
            // line 118
            echo "    ";
            $this->loadTemplate("_includes/forms/field", "_includes/forms", 118)->display(twig_to_array($this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 118, $this->source); })()), ["input" => (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 118, $this->source); })())])));
            craft\helpers\Template::endProfile("macro", "field");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 122
    public function macro_textField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "textField");
            // line 123
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "unit", [], "any", true, true)) {
                // line 124
                echo "        ";
                ob_start();
                // line 125
                echo "            <div class=\"flex\">
                <div class=\"textwrapper\">";
                // line 126
                echo twig_call_macro($macros["_self"], "macro_text", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 126, $this->source); })())], 126, $context, $this->getSourceContext());
                echo "</div>
                <div class=\"label light\">";
                // line 127
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 127, $this->source); })()), "unit", []), "html", null, true);
                echo "</div>
            </div>
        ";
                $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
                // line 130
                echo "    ";
            } else {
                // line 131
                echo "        ";
                $context["input"] = twig_call_macro($macros["_self"], "macro_text", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 131, $this->source); })())], 131, $context, $this->getSourceContext());
                // line 132
                echo "    ";
            }
            // line 133
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 133, $this->source); })()), (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 133, $this->source); })())], 133, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "textField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 137
    public function macro_copytextField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "copytextField");
            // line 138
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 138, $this->source); })()), twig_call_macro($macros["_self"], "macro_copytext", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 138, $this->source); })())], 138, $context, $this->getSourceContext())], 138, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "copytextField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 142
    public function macro_passwordField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "passwordField");
            // line 143
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 143, $this->source); })()), twig_call_macro($macros["_self"], "macro_password", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 143, $this->source); })())], 143, $context, $this->getSourceContext())], 143, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "passwordField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 147
    public function macro_dateField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "dateField");
            // line 148
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 148, $this->source); })()), twig_call_macro($macros["_self"], "macro_date", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 148, $this->source); })())], 148, $context, $this->getSourceContext())], 148, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "dateField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 152
    public function macro_timeField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "timeField");
            // line 153
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 153, $this->source); })()), twig_call_macro($macros["_self"], "macro_time", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 153, $this->source); })())], 153, $context, $this->getSourceContext())], 153, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "timeField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 157
    public function macro_colorField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "colorField");
            // line 158
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 158, $this->source); })()), twig_call_macro($macros["_self"], "macro_color", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 158, $this->source); })())], 158, $context, $this->getSourceContext())], 158, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "colorField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 162
    public function macro_dateTimeField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "dateTimeField");
            // line 163
            echo "    ";
            ob_start();
            // line 164
            echo "        <div class=\"datetimewrapper\">
            ";
            // line 165
            echo twig_call_macro($macros["_self"], "macro_date", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 165, $this->source); })())], 165, $context, $this->getSourceContext());
            echo "
            ";
            // line 166
            echo twig_call_macro($macros["_self"], "macro_time", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 166, $this->source); })())], 166, $context, $this->getSourceContext());
            echo "
        </div>
    ";
            $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 169
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 169, $this->source); })()), (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 169, $this->source); })())], 169, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "dateTimeField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 173
    public function macro_textareaField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "textareaField");
            // line 174
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 174, $this->source); })()), twig_call_macro($macros["_self"], "macro_textarea", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 174, $this->source); })())], 174, $context, $this->getSourceContext())], 174, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "textareaField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 178
    public function macro_selectField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "selectField");
            // line 179
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 179, $this->source); })()), twig_call_macro($macros["_self"], "macro_select", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 179, $this->source); })())], 179, $context, $this->getSourceContext())], 179, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "selectField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 183
    public function macro_multiselectField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "multiselectField");
            // line 184
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 184, $this->source); })()), twig_call_macro($macros["_self"], "macro_multiselect", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 184, $this->source); })())], 184, $context, $this->getSourceContext())], 184, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "multiselectField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 188
    public function macro_checkboxField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxField");
            // line 189
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldLabel", [], "any", true, true)) {
                // line 190
                echo "        ";
                echo twig_call_macro($macros["_self"], "macro_field", [$this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 190, $this->source); })()), ["label" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 190, $this->source); })()), "fieldLabel", [])]), twig_call_macro($macros["_self"], "macro_checkbox", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 190, $this->source); })())], 190, $context, $this->getSourceContext())], 190, $context, $this->getSourceContext());
                echo "
    ";
            } else {
                // line 192
                echo "        ";
                $context["instructions"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructions", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructions", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "instructions", [])) : (null));
                // line 193
                $context["warning"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "warning", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "warning", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "warning", [])) : (null));
                // line 194
                echo "<div class=\"field checkboxfield";
                if ((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "first", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 194, $this->source); })()), "first", []))) {
                    echo " first";
                }
                if ((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 194, $this->source); })())) {
                    echo " has-instructions";
                }
                echo "\"";
                if ((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "id", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 194, $this->source); })()), "id", []))) {
                    echo " id=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 194, $this->source); })()), "id", []), "html", null, true);
                    echo "-field\"";
                }
                echo ">
            ";
                // line 195
                echo twig_call_macro($macros["_self"], "macro_checkbox", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 195, $this->source); })())], 195, $context, $this->getSourceContext());
                echo "
            ";
                // line 196
                if ((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 196, $this->source); })())) {
                    // line 197
                    echo "                <div class=\"instructions\">";
                    echo $this->extensions['craft\web\twig\Extension']->markdownFilter((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 197, $this->source); })()));
                    echo "</div>
            ";
                }
                // line 199
                echo "            ";
                if ((isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 199, $this->source); })())) {
                    // line 200
                    echo "                <p class=\"warning with-icon\">";
                    echo twig_escape_filter($this->env, (isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 200, $this->source); })()), "html", null, true);
                    echo "</p>
            ";
                }
                // line 202
                echo "        </div>
    ";
            }
            craft\helpers\Template::endProfile("macro", "checkboxField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 207
    public function macro_checkboxGroupField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxGroupField");
            // line 208
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 208, $this->source); })()), twig_call_macro($macros["_self"], "macro_checkboxGroup", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 208, $this->source); })())], 208, $context, $this->getSourceContext())], 208, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "checkboxGroupField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 212
    public function macro_checkboxSelectField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "checkboxSelectField");
            // line 213
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 213, $this->source); })()), twig_call_macro($macros["_self"], "macro_checkboxSelect", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 213, $this->source); })())], 213, $context, $this->getSourceContext())], 213, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "checkboxSelectField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 217
    public function macro_radioGroupField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "radioGroupField");
            // line 218
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 218, $this->source); })()), twig_call_macro($macros["_self"], "macro_radioGroup", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 218, $this->source); })())], 218, $context, $this->getSourceContext())], 218, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "radioGroupField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 222
    public function macro_fileField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "fileField");
            // line 223
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 223, $this->source); })()), twig_call_macro($macros["_self"], "macro_file", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 223, $this->source); })())], 223, $context, $this->getSourceContext())], 223, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "fileField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 227
    public function macro_lightswitchField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "lightswitchField");
            // line 228
            echo "    ";
            if (( !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "labelId", [], "any", true, true) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 228, $this->source); })()), "labelId", []))) {
                // line 229
                echo "        ";
                $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 229, $this->source); })()), ["labelId" => ("label" . twig_random($this->env))]);
                // line 230
                echo "    ";
            }
            // line 231
            echo "    ";
            $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 231, $this->source); })()), ["fieldClass" => ("lightswitch-field " . (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "fieldClass", [])) : ("")))]);
            // line 232
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 232, $this->source); })()), twig_call_macro($macros["_self"], "macro_lightswitch", [$this->extensions['craft\web\twig\Extension']->withoutKeyFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 232, $this->source); })()), "label")], 232, $context, $this->getSourceContext())], 232, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "lightswitchField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 236
    public function macro_editableTableField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "editableTableField");
            // line 237
            echo "    ";
            ob_start();
            $this->loadTemplate("_includes/forms/editableTable", "_includes/forms", 237)->display(twig_to_array((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 237, $this->source); })())));
            $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 238
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 238, $this->source); })()), (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 238, $this->source); })())], 238, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "editableTableField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 242
    public function macro_elementSelectField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "elementSelectField");
            // line 243
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 243, $this->source); })()), twig_call_macro($macros["_self"], "macro_elementSelect", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 243, $this->source); })())], 243, $context, $this->getSourceContext())], 243, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "elementSelectField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 247
    public function macro_autosuggestField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "autosuggestField");
            // line 248
            echo "
    ";
            // line 250
            echo "    ";
            if ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestEnvVars", [])) : (false))) {
                // line 251
                echo "        ";
                $context["value"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "value", [])) : (""));
                // line 252
                echo "        ";
                if (( !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "tip", [], "any", true, true) && !twig_in_filter(twig_slice($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 252, $this->source); })()), 0, 1), [0 => "\$", 1 => "@"]))) {
                    // line 253
                    echo "            ";
                    $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 253, $this->source); })()), ["tip" => ((((((((craft\helpers\Template::attribute($this->env, $this->source,                     // line 254
($context["config"] ?? null), "suggestAliases", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestAliases", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "suggestAliases", [])) : (false))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable, or begin with an alias.", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable.", "app"))) . " <a href=\"https://craftcms.com/docs/3.x/config/#environmental-configuration\" class=\"go\">") . $this->extensions['craft\web\twig\Extension']->translateFilter("Learn more", "app")) . "</a>")]);
                    // line 259
                    echo "        ";
                } elseif ((( !craft\helpers\Template::attribute($this->env, $this->source, ($context["config"] ?? null), "warning", [], "any", true, true) && (((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 259, $this->source); })()) == "@web") || (twig_slice($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 259, $this->source); })()), 0, 5) == "@web/"))) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 259, $this->source); })()), "app", []), "request", []), "isWebAliasSetDynamically", []))) {
                    // line 260
                    echo "            ";
                    $context["config"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 260, $this->source); })()), ["warning" => $this->extensions['craft\web\twig\Extension']->translateFilter("The `@web` alias is not recommended if it is determined automatically.", "app")]);
                    // line 263
                    echo "        ";
                }
                // line 264
                echo "    ";
            }
            // line 265
            echo "
    ";
            // line 266
            echo twig_call_macro($macros["_self"], "macro_field", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 266, $this->source); })()), twig_call_macro($macros["_self"], "macro_autosuggest", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 266, $this->source); })())], 266, $context, $this->getSourceContext())], 266, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "autosuggestField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 270
    public function macro_fieldLayoutDesignerField($__config__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "fieldLayoutDesignerField");
            // line 271
            echo "    ";
            echo twig_call_macro($macros["_self"], "macro_field", [$this->extensions['craft\web\twig\Extension']->mergeFilter(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Layout", "app")],             // line 273
(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 273, $this->source); })())), twig_call_macro($macros["_self"], "macro_fieldLayoutDesigner", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 273, $this->source); })())], 273, $context, $this->getSourceContext())], 271, $context, $this->getSourceContext());
            echo "
";
            craft\helpers\Template::endProfile("macro", "fieldLayoutDesignerField");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 280
    public function macro_optionShortcutLabel($__key__ = null, $__shift__ = null, $__alt__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "key" => $__key__,
            "shift" => $__shift__,
            "alt" => $__alt__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "optionShortcutLabel");
            // line 281
            ob_start();
            // line 282
            echo "        ";
            switch (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 282, $this->source); })()), "app", []), "request", []), "getClientOs", [], "method")) {
                case "Mac":
                {
                    // line 284
                    echo "                <span class=\"shortcut\">";
                    echo twig_escape_filter($this->env, ((((((isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new RuntimeError('Variable "alt" does not exist.', 284, $this->source); })())) ? ("⌥") : ("")) . (((isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new RuntimeError('Variable "shift" does not exist.', 284, $this->source); })())) ? ("⇧") : (""))) . "⌘") . (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 284, $this->source); })())), "html", null, true);
                    echo "</span>
            ";
                    break;
                }
                default:
                {
                    // line 286
                    echo "                <span class=\"shortcut\">";
                    echo twig_escape_filter($this->env, ((("Ctrl+" . (((isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new RuntimeError('Variable "alt" does not exist.', 286, $this->source); })())) ? ("Alt+") : (""))) . (((isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new RuntimeError('Variable "shift" does not exist.', 286, $this->source); })())) ? ("Shift+") : (""))) . (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 286, $this->source); })())), "html", null, true);
                    echo "</span>
        ";
                }
            }
            // line 288
            echo "    ";
            echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
            craft\helpers\Template::endProfile("macro", "optionShortcutLabel");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1522 => 288,  1515 => 286,  1506 => 284,  1501 => 282,  1499 => 281,  1483 => 280,  1471 => 273,  1469 => 271,  1455 => 270,  1443 => 266,  1440 => 265,  1437 => 264,  1434 => 263,  1431 => 260,  1428 => 259,  1426 => 254,  1424 => 253,  1421 => 252,  1418 => 251,  1415 => 250,  1412 => 248,  1398 => 247,  1385 => 243,  1371 => 242,  1358 => 238,  1353 => 237,  1339 => 236,  1326 => 232,  1323 => 231,  1320 => 230,  1317 => 229,  1314 => 228,  1300 => 227,  1287 => 223,  1273 => 222,  1260 => 218,  1246 => 217,  1233 => 213,  1219 => 212,  1206 => 208,  1192 => 207,  1180 => 202,  1174 => 200,  1171 => 199,  1165 => 197,  1163 => 196,  1159 => 195,  1143 => 194,  1141 => 193,  1138 => 192,  1132 => 190,  1129 => 189,  1115 => 188,  1102 => 184,  1088 => 183,  1075 => 179,  1061 => 178,  1048 => 174,  1034 => 173,  1021 => 169,  1015 => 166,  1011 => 165,  1008 => 164,  1005 => 163,  991 => 162,  978 => 158,  964 => 157,  951 => 153,  937 => 152,  924 => 148,  910 => 147,  897 => 143,  883 => 142,  870 => 138,  856 => 137,  843 => 133,  840 => 132,  837 => 131,  834 => 130,  828 => 127,  824 => 126,  821 => 125,  818 => 124,  815 => 123,  801 => 122,  790 => 118,  775 => 117,  764 => 110,  750 => 109,  739 => 105,  725 => 104,  714 => 100,  700 => 99,  689 => 95,  675 => 94,  664 => 90,  650 => 89,  639 => 85,  625 => 84,  614 => 80,  600 => 79,  589 => 75,  575 => 74,  564 => 70,  550 => 69,  539 => 65,  525 => 64,  514 => 60,  500 => 59,  489 => 55,  475 => 54,  464 => 50,  450 => 49,  439 => 45,  425 => 44,  414 => 40,  400 => 39,  389 => 35,  375 => 34,  364 => 30,  350 => 29,  339 => 25,  325 => 24,  314 => 20,  300 => 19,  289 => 15,  275 => 14,  265 => 10,  251 => 9,  240 => 2,  226 => 1,  219 => 278,  215 => 275,  211 => 268,  207 => 245,  203 => 240,  199 => 234,  195 => 225,  191 => 220,  187 => 215,  183 => 210,  179 => 205,  175 => 186,  171 => 181,  167 => 176,  163 => 171,  159 => 160,  155 => 155,  151 => 150,  147 => 145,  143 => 140,  139 => 135,  135 => 120,  131 => 115,  127 => 112,  123 => 107,  119 => 102,  115 => 97,  111 => 92,  107 => 87,  103 => 82,  99 => 77,  95 => 72,  91 => 67,  87 => 62,  83 => 57,  79 => 52,  75 => 47,  71 => 42,  67 => 37,  63 => 32,  59 => 27,  55 => 22,  51 => 17,  47 => 12,  43 => 7,  39 => 4,);
    }

    public function getSourceContext()
    {
        return new Source("{% macro errorList(errors) %}
    {% include \"_includes/forms/errorList\" %}
{% endmacro %}


{# Inputs #}


{% macro hidden(config) -%}
    {% include \"_includes/forms/hidden\" with config only %}
{%- endmacro %}


{% macro text(config) %}
    {% include \"_includes/forms/text\" with config only %}
{% endmacro %}


{% macro password(config) %}
    {% include \"_includes/forms/password\" with config only %}
{% endmacro %}


{% macro copytext(config) %}
    {% include \"_includes/forms/copytext\" with config only %}
{% endmacro %}


{% macro date(config) %}
    {% include \"_includes/forms/date\" with config only %}
{% endmacro %}


{% macro time(config) %}
    {% include \"_includes/forms/time\" with config only %}
{% endmacro %}


{% macro color(config) %}
    {% include \"_includes/forms/color\" with config only %}
{% endmacro %}


{% macro textarea(config) %}
    {% include \"_includes/forms/textarea\" with config only %}
{% endmacro %}


{% macro select(config) %}
    {% include \"_includes/forms/select\" with config only %}
{% endmacro %}


{% macro multiselect(config) %}
    {% include \"_includes/forms/multiselect\" with config only %}
{% endmacro %}


{% macro checkbox(config) %}
    {% include \"_includes/forms/checkbox\" with config only %}
{% endmacro %}


{% macro checkboxGroup(config) %}
    {% include \"_includes/forms/checkboxGroup\" with config only %}
{% endmacro %}


{% macro checkboxSelect(config) %}
    {% include \"_includes/forms/checkboxSelect\" with config only %}
{% endmacro %}


{% macro radio(config) %}
    {% include \"_includes/forms/radio\" with config only %}
{% endmacro %}


{% macro radioGroup(config) %}
    {% include \"_includes/forms/radioGroup\" with config only %}
{% endmacro %}


{% macro file(config) %}
    {% include \"_includes/forms/file\" with config only %}
{% endmacro %}


{% macro lightswitch(config) %}
    {% include \"_includes/forms/lightswitch\" with config only %}
{% endmacro %}


{% macro editableTable(config) %}
    {% include \"_includes/forms/editableTable\" with config only %}
{% endmacro %}


{% macro elementSelect(config) %}
    {% include \"_includes/forms/elementSelect\" with config only %}
{% endmacro %}


{% macro autosuggest(config) %}
    {% include \"_includes/forms/autosuggest\" with config only %}
{% endmacro %}


{% macro fieldLayoutDesigner(config) %}
    {% include \"_includes/forms/fieldLayoutDesigner\" with config only %}
{% endmacro %}


{# Fields #}


{% macro field(config, input) %}
    {% include \"_includes/forms/field\" with config|merge({ input: input }) only %}
{% endmacro %}


{% macro textField(config) %}
    {% if config.unit is defined %}
        {% set input %}
            <div class=\"flex\">
                <div class=\"textwrapper\">{{ _self.text(config) }}</div>
                <div class=\"label light\">{{ config.unit }}</div>
            </div>
        {% endset %}
    {% else %}
        {% set input = _self.text(config) %}
    {% endif %}
    {{ _self.field(config, input) }}
{% endmacro %}


{% macro copytextField(config) %}
    {{ _self.field(config, _self.copytext(config)) }}
{% endmacro %}


{% macro passwordField(config) %}
    {{ _self.field(config, _self.password(config)) }}
{% endmacro %}


{% macro dateField(config) %}
    {{ _self.field(config, _self.date(config)) }}
{% endmacro %}


{% macro timeField(config) %}
    {{ _self.field(config, _self.time(config)) }}
{% endmacro %}


{% macro colorField(config) %}
    {{ _self.field(config, _self.color(config)) }}
{% endmacro %}


{% macro dateTimeField(config) %}
    {% set input %}
        <div class=\"datetimewrapper\">
            {{ _self.date(config) }}
            {{ _self.time(config) }}
        </div>
    {% endset %}
    {{ _self.field(config, input) }}
{% endmacro %}


{% macro textareaField(config) %}
    {{ _self.field(config, _self.textarea(config)) }}
{% endmacro %}


{% macro selectField(config) %}
    {{ _self.field(config, _self.select(config)) }}
{% endmacro %}


{% macro multiselectField(config) %}
    {{ _self.field(config, _self.multiselect(config)) }}
{% endmacro %}


{% macro checkboxField(config) %}
    {% if config.fieldLabel is defined %}
        {{ _self.field(config|merge({label: config.fieldLabel}), _self.checkbox(config)) }}
    {% else %}
        {% set instructions = config.instructions ?? null -%}
        {% set warning = config.warning ?? null -%}
        <div class=\"field checkboxfield{% if config.first is defined and config.first %} first{% endif %}{% if instructions %} has-instructions{% endif %}\"{% if config.id is defined and config.id %} id=\"{{ config.id }}-field\"{% endif %}>
            {{ _self.checkbox(config) }}
            {% if instructions %}
                <div class=\"instructions\">{{ instructions|md }}</div>
            {% endif %}
            {% if warning %}
                <p class=\"warning with-icon\">{{ warning }}</p>
            {% endif %}
        </div>
    {% endif %}
{% endmacro %}


{% macro checkboxGroupField(config) %}
    {{ _self.field(config, _self.checkboxGroup(config)) }}
{% endmacro %}


{% macro checkboxSelectField(config) %}
    {{ _self.field(config, _self.checkboxSelect(config)) }}
{% endmacro %}


{% macro radioGroupField(config) %}
    {{ _self.field(config, _self.radioGroup(config)) }}
{% endmacro %}


{% macro fileField(config) %}
    {{ _self.field(config, _self.file(config)) }}
{% endmacro %}


{% macro lightswitchField(config) %}
    {% if config.labelId is not defined or not config.labelId %}
        {% set config = config|merge({ labelId: 'label'~random() }) %}
    {% endif %}
    {% set config = config|merge({ fieldClass: 'lightswitch-field ' ~ (config.fieldClass ?? '') }) %}
    {{ _self.field(config, _self.lightswitch(config|withoutKey('label'))) }}
{% endmacro %}


{% macro editableTableField(config) %}
    {% set input %}{% include \"_includes/forms/editableTable\" with config only %}{% endset %}
    {{ _self.field(config, input) }}
{% endmacro %}


{% macro elementSelectField(config) %}
    {{ _self.field(config, _self.elementSelect(config)) }}
{% endmacro %}


{% macro autosuggestField(config) %}

    {# Suggest an environment variable / alias? #}
    {% if (config.suggestEnvVars ?? false) %}
        {% set value = config.value ?? '' %}
        {% if config.tip is not defined and value[0:1] not in ['\$', '@'] %}
            {% set config = config|merge({
                tip: ((config.suggestAliases ?? false)
                    ? 'This can be set to an environment variable, or begin with an alias.'|t('app')
                    : 'This can be set to an environment variable.'|t('app'))
                    ~ ' <a href=\"https://craftcms.com/docs/3.x/config/#environmental-configuration\" class=\"go\">' ~ 'Learn more'|t('app') ~ '</a>'
            }) %}
        {% elseif config.warning is not defined and (value == '@web' or value[0:5] == '@web/') and craft.app.request.isWebAliasSetDynamically %}
            {% set config = config|merge({
                warning: 'The `@web` alias is not recommended if it is determined automatically.'|t('app')
            }) %}
        {% endif %}
    {% endif %}

    {{ _self.field(config, _self.autosuggest(config)) }}
{% endmacro %}


{% macro fieldLayoutDesignerField(config) %}
    {{ _self.field({
        label: 'Field Layout'|t('app'),
    }|merge(config), _self.fieldLayoutDesigner(config)) }}
{% endmacro %}


{# Other #}


{% macro optionShortcutLabel(key, shift, alt) %}
    {%- spaceless %}
        {% switch craft.app.request.getClientOs() %}
            {% case 'Mac' %}
                <span class=\"shortcut\">{{ (alt ? '⌥') ~ (shift ? '⇧') ~ '⌘' ~ key }}</span>
            {% default %}
                <span class=\"shortcut\">{{ 'Ctrl+' ~ (alt ? 'Alt+') ~ (shift ? 'Shift+') ~ key }}</span>
        {% endswitch %}
    {% endspaceless -%}
{% endmacro %}
", "_includes/forms", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/forms.html");
    }
}

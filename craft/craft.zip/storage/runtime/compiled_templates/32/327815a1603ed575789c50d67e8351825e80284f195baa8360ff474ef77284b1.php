<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__8c8bd001368be8a0f98af59d9b999eb8a9d0643864032469fe0156f0c5ef5f0e */
class __TwigTemplate_eb6ef1fb0e97a458cd01c032c8c85af6dffeac2b055d58c2bdf427cae7f57e9c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__8c8bd001368be8a0f98af59d9b999eb8a9d0643864032469fe0156f0c5ef5f0e");
        // line 1
        echo "program/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        craft\helpers\Template::endProfile("template", "__string_template__8c8bd001368be8a0f98af59d9b999eb8a9d0643864032469fe0156f0c5ef5f0e");
    }

    public function getTemplateName()
    {
        return "__string_template__8c8bd001368be8a0f98af59d9b999eb8a9d0643864032469fe0156f0c5ef5f0e";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("program/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__8c8bd001368be8a0f98af59d9b999eb8a9d0643864032469fe0156f0c5ef5f0e", "");
    }
}

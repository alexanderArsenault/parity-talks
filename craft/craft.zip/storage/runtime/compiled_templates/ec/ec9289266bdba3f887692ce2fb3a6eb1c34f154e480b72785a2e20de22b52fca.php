<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* stream/_entry */
class __TwigTemplate_3aeaf1a3131735e9937e6f92ebac4f093dffc996069a92b47ea07f04e99a4915 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "stream/_entry");
        $this->parent = $this->loadTemplate("_layout", "stream/_entry", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "stream/_entry");
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 4
        echo "
<section id=\"stream\">
\t<div class=\"wrapper\">
\t\t<div id=\"twitch-embed\"></div>
\t\t<p>Chat disclaimer: ,ust have account to comment</p>
\t</div>
</section>

";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "stream/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layout\" %}

{% block content %}

<section id=\"stream\">
\t<div class=\"wrapper\">
\t\t<div id=\"twitch-embed\"></div>
\t\t<p>Chat disclaimer: ,ust have account to comment</p>
\t</div>
</section>

{% endblock %}
", "stream/_entry", "/home/ubuntu/sites/seekult-nitro/craft/templates/stream/_entry.twig");
    }
}

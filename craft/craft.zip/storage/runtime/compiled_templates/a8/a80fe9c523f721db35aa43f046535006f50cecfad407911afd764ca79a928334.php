<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/_entry */
class __TwigTemplate_ccafb65730a65cef1fe3d1e702981242e7bef59fb83d71db82307ab3e1e24708 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "home/_entry");
        $this->parent = $this->loadTemplate("_layout", "home/_entry", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "home/_entry");
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 4
        echo "<main>
\t<section id=\"hero\">
\t\t<div class=\"wrapper\">

\t\t\t<div class=\"hero-header__content\">
\t\t\t\t<h1 class=\"page-title\">Prasenzen</h1>
\t\t\t\t<h3 class=\"page-subtitle\">Kunstinterventionen im Friedrichshafener Stadtraum</h3>
\t\t\t\t<h3>10.10.2020</h3>
\t\t\t\t<button class=\"primary\"> View Program</button>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"hero-background\">
\t\t\t<div class=\"logo-container\"></div>
\t\t</div>
\t</section>
\t</main>
\t<section id=\"logbook\">
\t\t<div class=\"wrapper\">
\t\t\t<div class=\"interaction-container active main\">
\t\t\t\t";
        // line 23
        $context["logbookEntry"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 23, $this->source); })()), "entries", []), "section", [0 => "logbookEntries"], "method"), "first", [], "method");
        // line 24
        echo "
\t\t\t\t<div class=\"interaction-header\">
\t\t\t\t\t<h4 class=\"interaction-date\">Interaction ";
        // line 26
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logbookEntry"]) || array_key_exists("logbookEntry", $context) ? $context["logbookEntry"] : (function () { throw new RuntimeError('Variable "logbookEntry" does not exist.', 26, $this->source); })()), "entryDate", []), "short"), "html", null, true);
        echo "</h4>
\t\t\t\t\t<h3 class=\"interaction-prompt\"> ";
        // line 27
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logbookEntry"]) || array_key_exists("logbookEntry", $context) ? $context["logbookEntry"] : (function () { throw new RuntimeError('Variable "logbookEntry" does not exist.', 27, $this->source); })()), "title", []), "html", null, true);
        echo "</h3>
\t\t\t\t</div>

\t\t\t\t<div class=\"answers-list\">

\t\t\t\t\t";
        // line 32
        if (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logbookEntry"]) || array_key_exists("logbookEntry", $context) ? $context["logbookEntry"] : (function () { throw new RuntimeError('Variable "logbookEntry" does not exist.', 32, $this->source); })()), "logbookResponses", []))) {
            // line 33
            echo "\t\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logbookEntry"]) || array_key_exists("logbookEntry", $context) ? $context["logbookEntry"] : (function () { throw new RuntimeError('Variable "logbookEntry" does not exist.', 33, $this->source); })()), "logbookResponses", []));
            foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                // line 34
                echo "\t\t\t\t\t\t\t<div class=\"answer-container active\">
\t\t\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t\t\t<p class=\"answer-name\">";
                // line 37
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "responseName", []), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t\t\t<p class=\"answer-title\">";
                // line 38
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "responseTitle", []), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t\t\t";
                // line 41
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "type", []) == "photo")) {
                    // line 42
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"answer-photo\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                    // line 43
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "photo", []), "first", [], "method"), "url", []), "html", null, true);
                    echo "\" />
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 46
                echo "
\t\t\t\t\t\t\t\t\t";
                // line 47
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "type", []) == "video")) {
                    // line 48
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"answer-video\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "video", []), "html", null, true);
                    echo "</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 50
                echo "
\t\t\t\t\t\t\t\t\t";
                // line 51
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "type", []) == "audio")) {
                    // line 52
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"answer-audio\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "audio", []), "html", null, true);
                    echo "</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 54
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 55
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "type", []) == "text")) {
                    // line 56
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"answer-text\">
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 57
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "text", []), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 60
                echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 63
            echo "\t\t\t\t\t";
        }
        // line 64
        echo "\t\t\t<p><a class=\"link\" href=\"/logbook\">View more answers</a></p>
\t\t</div>
\t</section>
\t<section id=\"events\">
\t\t<div class=\"wrapper\">
\t\t\t<h3>Locations</h3>
\t\t\t<div class=\"events-container\">
\t\t\t\t<a href=\"#\" class=\"event-container adenauerplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type \">Adenauerplatz</div>
\t\t\t\t\t\t<h3>Adenauerplatz</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t\t<span>Larry Bingo</span>
\t\t\t\t\t\t<span>Oppsie, Daisey</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container buchhornplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Buchhornplatz</div>
\t\t\t\t\t\t<h3>Buchhornplatz</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container moleturm\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Moleturm</div>
\t\t\t\t\t\t<h3>Moleturm</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t</div>
\t\t\t<a href=\"./program.html\"><button class=\"primary\">View All Interventions</button></a>
\t\t</div>

\t</section>
";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "home/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 64,  169 => 63,  161 => 60,  155 => 57,  152 => 56,  150 => 55,  147 => 54,  141 => 52,  139 => 51,  136 => 50,  130 => 48,  128 => 47,  125 => 46,  119 => 43,  116 => 42,  114 => 41,  108 => 38,  104 => 37,  99 => 34,  94 => 33,  92 => 32,  84 => 27,  80 => 26,  76 => 24,  74 => 23,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layout\" %}

{% block content %}
<main>
\t<section id=\"hero\">
\t\t<div class=\"wrapper\">

\t\t\t<div class=\"hero-header__content\">
\t\t\t\t<h1 class=\"page-title\">Prasenzen</h1>
\t\t\t\t<h3 class=\"page-subtitle\">Kunstinterventionen im Friedrichshafener Stadtraum</h3>
\t\t\t\t<h3>10.10.2020</h3>
\t\t\t\t<button class=\"primary\"> View Program</button>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"hero-background\">
\t\t\t<div class=\"logo-container\"></div>
\t\t</div>
\t</section>
\t</main>
\t<section id=\"logbook\">
\t\t<div class=\"wrapper\">
\t\t\t<div class=\"interaction-container active main\">
\t\t\t\t{% set logbookEntry = craft.entries.section('logbookEntries').first() %}

\t\t\t\t<div class=\"interaction-header\">
\t\t\t\t\t<h4 class=\"interaction-date\">Interaction {{ logbookEntry.entryDate|date('short') }}</h4>
\t\t\t\t\t<h3 class=\"interaction-prompt\"> {{ logbookEntry.title }}</h3>
\t\t\t\t</div>

\t\t\t\t<div class=\"answers-list\">

\t\t\t\t\t{% if logbookEntry.logbookResponses|length %}
\t\t\t\t\t\t{% for entry in logbookEntry.logbookResponses %}
\t\t\t\t\t\t\t<div class=\"answer-container active\">
\t\t\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t\t\t<p class=\"answer-name\">{{ entry.responseName }}</p>
\t\t\t\t\t\t\t\t\t<p class=\"answer-title\">{{ entry.responseTitle }}</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t\t\t{% if entry.type == 'photo' %}
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-photo\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"{{entry.photo.first().url }}\" />
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t{% if entry.type == 'video' %}
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-video\">{{entry.video}}</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t{% if entry.type == 'audio' %}
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-audio\">{{entry.audio}}</div>
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t{% if entry.type == 'text' %}
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-text\">
\t\t\t\t\t\t\t\t\t\t\t{{entry.text}}
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t{% endif %}
\t\t\t<p><a class=\"link\" href=\"/logbook\">View more answers</a></p>
\t\t</div>
\t</section>
\t<section id=\"events\">
\t\t<div class=\"wrapper\">
\t\t\t<h3>Locations</h3>
\t\t\t<div class=\"events-container\">
\t\t\t\t<a href=\"#\" class=\"event-container adenauerplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type \">Adenauerplatz</div>
\t\t\t\t\t\t<h3>Adenauerplatz</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t\t<span>Larry Bingo</span>
\t\t\t\t\t\t<span>Oppsie, Daisey</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container buchhornplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Buchhornplatz</div>
\t\t\t\t\t\t<h3>Buchhornplatz</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container moleturm\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Moleturm</div>
\t\t\t\t\t\t<h3>Moleturm</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t</div>
\t\t\t<a href=\"./program.html\"><button class=\"primary\">View All Interventions</button></a>
\t\t</div>

\t</section>
{% endblock %}
", "home/_entry", "/home/ubuntu/sites/seekult-nitro/craft/templates/home/_entry.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__2e7b45cc208fbf7c31bad75cebc95f36c3be1ec614a80708ebd0929adb0de96b */
class __TwigTemplate_d3952190e55f17f4cb012277f927092c8af6bdbe3c7e4bb82de66998ae4291ce extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__2e7b45cc208fbf7c31bad75cebc95f36c3be1ec614a80708ebd0929adb0de96b");
        // line 1
        echo "artist/category/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        craft\helpers\Template::endProfile("template", "__string_template__2e7b45cc208fbf7c31bad75cebc95f36c3be1ec614a80708ebd0929adb0de96b");
    }

    public function getTemplateName()
    {
        return "__string_template__2e7b45cc208fbf7c31bad75cebc95f36c3be1ec614a80708ebd0929adb0de96b";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("artist/category/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__2e7b45cc208fbf7c31bad75cebc95f36c3be1ec614a80708ebd0929adb0de96b", "");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/assets/volumes/_edit */
class __TwigTemplate_b38fa4fad59a1af7d25f84c10d2d23001ec983844061cc10e06661bb50d84c8b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/assets/volumes/_edit");
        // line 3
        $context["fullPageForm"] = true;
        // line 5
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/assets/volumes/_edit", 5)->unwrap();
        // line 96
        if (( !(isset($context["volume"]) || array_key_exists("volume", $context)) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 96, $this->source); })()), "handle", []))) {
            // line 97
            ob_start();
            // line 98
            echo "        new Craft.HandleGenerator('#name', '#handle');
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/assets/volumes/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/assets/volumes/_edit");
    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 9
        echo "    ";
        echo craft\helpers\Html::actionInput("volumes/save-volume");
        echo "
    ";
        // line 10
        echo craft\helpers\Html::redirectInput("settings/assets");
        echo "
    ";
        // line 11
        if ( !(isset($context["isNewVolume"]) || array_key_exists("isNewVolume", $context) ? $context["isNewVolume"] : (function () { throw new RuntimeError('Variable "isNewVolume" does not exist.', 11, $this->source); })())) {
            echo craft\helpers\Html::hiddenInput("volumeId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 11, $this->source); })()), "id", []));
        }
        // line 12
        echo "
    ";
        // line 13
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "id" => "name", "name" => "name", "value" => ((        // line 18
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 18, $this->source); })()), "name", [])) : (null)), "errors" => ((        // line 19
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 19, $this->source); })()), "getErrors", [0 => "name"], "method")) : (null)), "autofocus" => true, "required" => true]], 13, $context, $this->getSourceContext());
        // line 22
        echo "

    ";
        // line 24
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => ((        // line 32
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 32, $this->source); })()), "handle", [])) : (null)), "errors" => ((        // line 33
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 33, $this->source); })()), "getErrors", [0 => "handle"], "method")) : (null)), "required" => true]], 24, $context, $this->getSourceContext());
        // line 35
        echo "

    ";
        // line 37
        echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Assets in this volume have public URLs", "app"), "name" => "hasUrls", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 40
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 40, $this->source); })()), "hasUrls", []), "toggle" => "url-field"]], 37, $context, $this->getSourceContext());
        // line 42
        echo "

    <div id=\"url-field\" class=\"";
        // line 44
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 44, $this->source); })()), "hasUrls", [])) {
            echo "hidden";
        }
        echo "\">
        ";
        // line 45
        echo twig_call_macro($macros["forms"], "macro_autosuggestField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The base URL to the assets in this volume.", "app"), "id" => "url", "class" => [0 => "ltr", 1 => "volume-url"], "name" => "url", "suggestEnvVars" => true, "suggestAliases" => true, "value" => ((        // line 53
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 53, $this->source); })()), "url", [])) : (null)), "errors" => ((        // line 54
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 54, $this->source); })()), "getErrors", [0 => "url"], "method")) : (null)), "required" => true, "placeholder" => "//example.com/path/to/folder"]], 45, $context, $this->getSourceContext());
        // line 57
        echo "
    </div>

    <hr>

    ";
        // line 62
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Volume Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of volume is this?", "app"), "id" => "type", "name" => "type", "options" =>         // line 67
(isset($context["volumeTypeOptions"]) || array_key_exists("volumeTypeOptions", $context) ? $context["volumeTypeOptions"] : (function () { throw new RuntimeError('Variable "volumeTypeOptions" does not exist.', 67, $this->source); })()), "value" => get_class(        // line 68
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 68, $this->source); })())), "toggle" => true]], 62, $context, $this->getSourceContext());
        // line 70
        echo "

    ";
        // line 72
        echo (isset($context["missingVolumePlaceholder"]) || array_key_exists("missingVolumePlaceholder", $context) ? $context["missingVolumePlaceholder"] : (function () { throw new RuntimeError('Variable "missingVolumePlaceholder" does not exist.', 72, $this->source); })());
        echo "

    ";
        // line 74
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["volumeTypes"]) || array_key_exists("volumeTypes", $context) ? $context["volumeTypes"] : (function () { throw new RuntimeError('Variable "volumeTypes" does not exist.', 74, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["volumeType"]) {
            // line 75
            echo "        ";
            $context["isCurrent"] = ($context["volumeType"] == get_class((isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 75, $this->source); })())));
            // line 76
            echo "
        <div id=\"";
            // line 77
            echo twig_escape_filter($this->env, craft\helpers\Html::id($context["volumeType"]), "html", null, true);
            echo "\"";
            if ( !(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 77, $this->source); })())) {
                echo " class=\"hidden\"";
            }
            echo ">
            ";
            // line 78
            $_namespace = (("types[" . $context["volumeType"]) . "]");
            if ($_namespace) {
                $_originalNamespace = Craft::$app->getView()->getNamespace();
                Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                ob_start();
                try {
                    // line 79
                    echo "                ";
                    if ((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 79, $this->source); })())) {
                        // line 80
                        echo "                    ";
                        echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 80, $this->source); })()), "getSettingsHtml", [], "method");
                        echo "
                ";
                    } else {
                        // line 82
                        echo "                    ";
                        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volumeInstances"]) || array_key_exists("volumeInstances", $context) ? $context["volumeInstances"] : (function () { throw new RuntimeError('Variable "volumeInstances" does not exist.', 82, $this->source); })()), $context["volumeType"], [], "array"), "getSettingsHtml", [], "method");
                        echo "
                ";
                    }
                    // line 84
                    echo "            ";
                } catch (Exception $e) {
                    ob_end_clean();

                    throw $e;
                }
                echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                Craft::$app->getView()->setNamespace($_originalNamespace);
            } else {
                // line 79
                echo "                ";
                if ((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 79, $this->source); })())) {
                    // line 80
                    echo "                    ";
                    echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 80, $this->source); })()), "getSettingsHtml", [], "method");
                    echo "
                ";
                } else {
                    // line 82
                    echo "                    ";
                    echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volumeInstances"]) || array_key_exists("volumeInstances", $context) ? $context["volumeInstances"] : (function () { throw new RuntimeError('Variable "volumeInstances" does not exist.', 82, $this->source); })()), $context["volumeType"], [], "array"), "getSettingsHtml", [], "method");
                    echo "
                ";
                }
                // line 84
                echo "            ";
            }
            unset($_originalNamespace, $_namespace);
            // line 85
            echo "        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['volumeType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 87
        echo "
    <hr>

    ";
        // line 90
        echo twig_call_macro($macros["forms"], "macro_fieldLayoutDesignerField", [["fieldLayout" => craft\helpers\Template::attribute($this->env, $this->source,         // line 91
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 91, $this->source); })()), "getFieldLayout", [], "method")]], 90, $context, $this->getSourceContext());
        // line 92
        echo "
";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/assets/volumes/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  220 => 92,  218 => 91,  217 => 90,  212 => 87,  205 => 85,  201 => 84,  195 => 82,  189 => 80,  186 => 79,  176 => 84,  170 => 82,  164 => 80,  161 => 79,  154 => 78,  146 => 77,  143 => 76,  140 => 75,  136 => 74,  131 => 72,  127 => 70,  125 => 68,  124 => 67,  123 => 62,  116 => 57,  114 => 54,  113 => 53,  112 => 45,  106 => 44,  102 => 42,  100 => 40,  99 => 37,  95 => 35,  93 => 33,  92 => 32,  91 => 24,  87 => 22,  85 => 19,  84 => 18,  83 => 13,  80 => 12,  76 => 11,  72 => 10,  67 => 9,  62 => 8,  56 => 1,  51 => 98,  49 => 97,  47 => 96,  45 => 5,  43 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
    {{ actionInput('volumes/save-volume') }}
    {{ redirectInput('settings/assets') }}
    {% if not isNewVolume %}{{ hiddenInput('volumeId', volume.id) }}{% endif %}

    {{ forms.textField({
        first: true,
        label: \"Name\"|t('app'),
        id: 'name',
        name: 'name',
        value: (volume is defined ? volume.name : null),
        errors: (volume is defined ? volume.getErrors('name') : null),
        autofocus: true,
        required: true,
    }) }}

    {{ forms.textField({
        first: true,
        label: \"Handle\"|t('app'),
        id: 'handle',
        name: 'handle',
        class: 'code',
        autocorrect: false,
        autocapitalize: false,
        value: (volume is defined ? volume.handle : null),
        errors: (volume is defined ? volume.getErrors('handle') : null),
        required: true,
    }) }}

    {{ forms.lightswitchField({
        label: \"Assets in this volume have public URLs\"|t('app'),
        name: 'hasUrls',
        on:   volume.hasUrls,
        toggle: \"url-field\"
    }) }}

    <div id=\"url-field\" class=\"{% if not volume.hasUrls %}hidden{% endif %}\">
        {{ forms.autosuggestField({
            label: \"Base URL\"|t('app'),
            instructions: \"The base URL to the assets in this volume.\"|t('app'),
            id: 'url',
            class: ['ltr', 'volume-url'],
            name: 'url',
            suggestEnvVars: true,
            suggestAliases: true,
            value: (volume is defined ? volume.url : null),
            errors: (volume is defined ? volume.getErrors('url') : null),
            required: true,
            placeholder: \"//example.com/path/to/folder\"
        }) }}
    </div>

    <hr>

    {{ forms.selectField({
        label: \"Volume Type\"|t('app'),
        instructions: \"What type of volume is this?\"|t('app'),
        id: 'type',
        name: 'type',
        options: volumeTypeOptions,
        value: className(volume),
        toggle: true
    }) }}

    {{ missingVolumePlaceholder|raw }}

    {% for volumeType in volumeTypes %}
        {% set isCurrent = (volumeType == className(volume)) %}

        <div id=\"{{ volumeType|id }}\"{% if not isCurrent %} class=\"hidden\"{% endif %}>
            {% namespace 'types['~volumeType~']' %}
                {% if isCurrent %}
                    {{ volume.getSettingsHtml()|raw }}
                {% else %}
                    {{ volumeInstances[volumeType].getSettingsHtml()|raw }}
                {% endif %}
            {% endnamespace %}
        </div>
    {% endfor %}

    <hr>

    {{ forms.fieldLayoutDesignerField({
        fieldLayout: volume.getFieldLayout(),
    }) }}
{% endblock %}


{% if volume is not defined or not volume.handle %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');
    {% endjs %}
{% endif %}
", "settings/assets/volumes/_edit", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/settings/assets/volumes/_edit.html");
    }
}

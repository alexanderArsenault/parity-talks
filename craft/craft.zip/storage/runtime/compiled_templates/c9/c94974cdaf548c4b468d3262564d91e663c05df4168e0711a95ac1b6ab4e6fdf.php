<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* artist.html */
class __TwigTemplate_4cc964cbc88f985fa9265cbf8cb7c9a4924a7aa4d90eacf9bc40a2ca36552895 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "artist.html");
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
\t<meta charset=\"UTF-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<title>SeeKULT</title>
\t<link rel=\"stylesheet\" href=\"<%=htmlWebpackPlugin.files.chunks.main.css %>\">
\t<link rel=\"icon\" href=\"./favicon.ico\">
\t<link rel=\"apple-touch-icon\" href=\"/apple-touch-icon.png\" />
";
        // line 10
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>
<body>";
        // line 11
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "


\t<header>
\t\t<nav>
\t\t\t<ul>
\t\t\t\t<li><a href=\"/index.html\">Home</a></li>
\t\t\t\t<li><a href=\"/program.html\">Program</a></li>
\t\t\t\t<li><a href=\"/about.html\">About</a></li>
\t\t\t\t<li><a href=\"/logbook.html\">Logbook</a></li>
\t\t\t\t<li><a href=\"/stream.html\">Stream</a></li>
\t\t\t</ul>
\t\t</nav>
</header>

<section id=\"single-artist\">
\t<div class=\"wrapper\">
\t\t<a class=\"back-link\" href=\"./program.html\"> <i class=\"fa-lg fa fa-caret-left\"></i>Back to Artists</a>
\t\t<div class=\"artist-container\">
\t\t\t<div class=\"artist-image\" style=\"background-image: url('src/assets/img/theme/Hintergrtund.Blau.png');\"></div>
\t\t\t<div class=\"artist-content\">
\t\t\t\t<div class=\"event-type\">Moleturm</div>
\t\t\t\t<h3>Please Feed the Dancers</h3>
\t\t\t\t<p class=\"text artist-text\">In Zeiten des Physical Distancing werden wir vor allem an Eines erinnert: wir brauchen einander, und die Unmittelbarkeit der physischen Begegnung ist nicht ersetzbar. 
\t\t\t\t\t
\t\t\t\t\tDarum lädt die compagnie O. zum Tanz ein.
\t\t\t\t\tTretet ein - allein, zu zweit oder zu dritt - und feiert mit uns den Moment! 
\t\t\t\t\tEine Ode an die zwischenmenschliche Begegnung. 
\t\t\t\t\tIntim und trotzdem virenfrei.
\t\t\t\t\t<br />
\t\t\t\t\tMarie Alexis | Konzept, künstl. Leitung, Choreografie
\t\t\t\t\t<br />
\t\t\t\t\tIvalina Yapova | Szenografie, Co-Leitung
\t\t\t\t\t<br />\t
\t\t\t\t\tLyn Bentschik | Tanz
\t\t\t\t\t<br />
\t\t\t\t\tAlice D’Angelo | Tanz
\t\t\t\t\t<br />
\t\t\t\t\tAmbra Peyer | Tanz
\t\t\t\t\t
\t\t\t\t\t<br />
\t\t\t\t\tlong durational
\t\t\t\t\t<br />
\t\t\t\t\tcome & go
\t\t\t\t\t
\t\t\t\t\t<br />
\t\t\t\t\tcompagnie O. ist ein Kollektiv aus Künstler*innen rund um den zeitgenössischen Tanz. Unter der Leitung von Marie Alexis (Choreografin, Videokünstlerin) und Ivalina Yapova (Szenografin, Lichtdesignerin, Architektin) realisieren sie Projekte für die Bühne und den öffentlichen Raum. </p>
\t\t\t\t<div class=\"artist-links\">
\t\t\t\t\t<i class=\"fab fa-twitter\"></i>
\t\t\t\t\t<i class=\"fab fa-instagram\"></i>
\t\t\t\t\t<i class=\"fab fa-facebook\"></i>
\t\t\t\t\t<i class=\"fab fa-youtube\"></i>
\t\t\t\t\t<i class=\"fab fa-vimeo\"></i>
\t\t\t\t\t<i class=\"fab fa-soundcloud\"></i>
\t\t\t\t\t<i class=\"fab fa-spotify\"></i>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</section>


<section id=\"more-artists\">
\t<div class=\"wrapper\">
\t\t<h3>More Artists</h3>
\t\t<div class=\"artist-gallery\">
\t\t\t<a href=\"/artist.html\" class=\"artist\">
\t\t\t\t<article>
\t\t\t\t\t<div class=\"artist-image\" style=\"background-image: url('src/assets/img/theme/Hintergrtund.Blau.png');\"></div>
\t\t\t\t\t<p class=\"artist-title\">Marcello Luigiano</p>
\t\t\t\t</article>
\t\t\t</a>
\t\t\t<a href=\"/artist.html\" class=\"artist\">
\t\t\t\t<article>
\t\t\t\t\t<div class=\"artist-image\" style=\"background-image: url('src/assets/img/theme/Hintergrtund.Blau.png');\"></div>
\t\t\t\t\t<p class=\"artist-title\">Marcello Luigiano</p>
\t\t\t\t</article>
\t\t\t</a>
\t\t\t<a href=\"/artist.html\" class=\"artist\">
\t\t\t\t<article>
\t\t\t\t\t<div class=\"artist-image\" style=\"background-image: url('src/assets/img/theme/Hintergrtund.Blau.png');\"></div>
\t\t\t\t\t<p class=\"artist-title\">Marcello Luigiano</p>
\t\t\t\t</article>
\t\t\t</a>
\t\t</div>
\t</div>
</section>
<footer>
\t<div class=\"footer-contact\">
\t\t<p class=\"bold\">Contact</p>
\t\t<p class=\"text\"><a href=\"mailto:info@seekult.de\">info@seekult.de</a></p>
\t\t<p class=\"text\">Am Seemooser Horn 20</p>
\t\t<p class=\"text\">88045 Friedrichshafen, Germany</p>
\t</div>
\t<div class=\"footer-privacy\">
\t\t<p class=\"bold\">Privacy Policy</p>
\t\t<p class=\"text\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis tempore itaque nisi. Doloribus reprehenderit earum illo corporis accusamus necessitatibus sequi distinctio, voluptatem aliquam culpa. Voluptatibus, eaque incidunt! Sunt quidem suscipit inventore velit. Mollitia veritatis qui porro consequatur odit voluptate libero architecto sunt nobis labore! Magnam sed ducimus quidem iusto dolorum.</p>
\t</div>
</footer>
<script defer src=\"<%= htmlWebpackPlugin.files.chunks.main.entry %>\"></script>
</html>";
        craft\helpers\Template::endProfile("template", "artist.html");
    }

    public function getTemplateName()
    {
        return "artist.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 11,  49 => 10,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
\t<meta charset=\"UTF-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<title>SeeKULT</title>
\t<link rel=\"stylesheet\" href=\"<%=htmlWebpackPlugin.files.chunks.main.css %>\">
\t<link rel=\"icon\" href=\"./favicon.ico\">
\t<link rel=\"apple-touch-icon\" href=\"/apple-touch-icon.png\" />
</head>
<body>


\t<header>
\t\t<nav>
\t\t\t<ul>
\t\t\t\t<li><a href=\"/index.html\">Home</a></li>
\t\t\t\t<li><a href=\"/program.html\">Program</a></li>
\t\t\t\t<li><a href=\"/about.html\">About</a></li>
\t\t\t\t<li><a href=\"/logbook.html\">Logbook</a></li>
\t\t\t\t<li><a href=\"/stream.html\">Stream</a></li>
\t\t\t</ul>
\t\t</nav>
</header>

<section id=\"single-artist\">
\t<div class=\"wrapper\">
\t\t<a class=\"back-link\" href=\"./program.html\"> <i class=\"fa-lg fa fa-caret-left\"></i>Back to Artists</a>
\t\t<div class=\"artist-container\">
\t\t\t<div class=\"artist-image\" style=\"background-image: url('src/assets/img/theme/Hintergrtund.Blau.png');\"></div>
\t\t\t<div class=\"artist-content\">
\t\t\t\t<div class=\"event-type\">Moleturm</div>
\t\t\t\t<h3>Please Feed the Dancers</h3>
\t\t\t\t<p class=\"text artist-text\">In Zeiten des Physical Distancing werden wir vor allem an Eines erinnert: wir brauchen einander, und die Unmittelbarkeit der physischen Begegnung ist nicht ersetzbar. 
\t\t\t\t\t
\t\t\t\t\tDarum lädt die compagnie O. zum Tanz ein.
\t\t\t\t\tTretet ein - allein, zu zweit oder zu dritt - und feiert mit uns den Moment! 
\t\t\t\t\tEine Ode an die zwischenmenschliche Begegnung. 
\t\t\t\t\tIntim und trotzdem virenfrei.
\t\t\t\t\t<br />
\t\t\t\t\tMarie Alexis | Konzept, künstl. Leitung, Choreografie
\t\t\t\t\t<br />
\t\t\t\t\tIvalina Yapova | Szenografie, Co-Leitung
\t\t\t\t\t<br />\t
\t\t\t\t\tLyn Bentschik | Tanz
\t\t\t\t\t<br />
\t\t\t\t\tAlice D’Angelo | Tanz
\t\t\t\t\t<br />
\t\t\t\t\tAmbra Peyer | Tanz
\t\t\t\t\t
\t\t\t\t\t<br />
\t\t\t\t\tlong durational
\t\t\t\t\t<br />
\t\t\t\t\tcome & go
\t\t\t\t\t
\t\t\t\t\t<br />
\t\t\t\t\tcompagnie O. ist ein Kollektiv aus Künstler*innen rund um den zeitgenössischen Tanz. Unter der Leitung von Marie Alexis (Choreografin, Videokünstlerin) und Ivalina Yapova (Szenografin, Lichtdesignerin, Architektin) realisieren sie Projekte für die Bühne und den öffentlichen Raum. </p>
\t\t\t\t<div class=\"artist-links\">
\t\t\t\t\t<i class=\"fab fa-twitter\"></i>
\t\t\t\t\t<i class=\"fab fa-instagram\"></i>
\t\t\t\t\t<i class=\"fab fa-facebook\"></i>
\t\t\t\t\t<i class=\"fab fa-youtube\"></i>
\t\t\t\t\t<i class=\"fab fa-vimeo\"></i>
\t\t\t\t\t<i class=\"fab fa-soundcloud\"></i>
\t\t\t\t\t<i class=\"fab fa-spotify\"></i>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</section>


<section id=\"more-artists\">
\t<div class=\"wrapper\">
\t\t<h3>More Artists</h3>
\t\t<div class=\"artist-gallery\">
\t\t\t<a href=\"/artist.html\" class=\"artist\">
\t\t\t\t<article>
\t\t\t\t\t<div class=\"artist-image\" style=\"background-image: url('src/assets/img/theme/Hintergrtund.Blau.png');\"></div>
\t\t\t\t\t<p class=\"artist-title\">Marcello Luigiano</p>
\t\t\t\t</article>
\t\t\t</a>
\t\t\t<a href=\"/artist.html\" class=\"artist\">
\t\t\t\t<article>
\t\t\t\t\t<div class=\"artist-image\" style=\"background-image: url('src/assets/img/theme/Hintergrtund.Blau.png');\"></div>
\t\t\t\t\t<p class=\"artist-title\">Marcello Luigiano</p>
\t\t\t\t</article>
\t\t\t</a>
\t\t\t<a href=\"/artist.html\" class=\"artist\">
\t\t\t\t<article>
\t\t\t\t\t<div class=\"artist-image\" style=\"background-image: url('src/assets/img/theme/Hintergrtund.Blau.png');\"></div>
\t\t\t\t\t<p class=\"artist-title\">Marcello Luigiano</p>
\t\t\t\t</article>
\t\t\t</a>
\t\t</div>
\t</div>
</section>
<footer>
\t<div class=\"footer-contact\">
\t\t<p class=\"bold\">Contact</p>
\t\t<p class=\"text\"><a href=\"mailto:info@seekult.de\">info@seekult.de</a></p>
\t\t<p class=\"text\">Am Seemooser Horn 20</p>
\t\t<p class=\"text\">88045 Friedrichshafen, Germany</p>
\t</div>
\t<div class=\"footer-privacy\">
\t\t<p class=\"bold\">Privacy Policy</p>
\t\t<p class=\"text\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis tempore itaque nisi. Doloribus reprehenderit earum illo corporis accusamus necessitatibus sequi distinctio, voluptatem aliquam culpa. Voluptatibus, eaque incidunt! Sunt quidem suscipit inventore velit. Mollitia veritatis qui porro consequatur odit voluptate libero architecto sunt nobis labore! Magnam sed ducimus quidem iusto dolorum.</p>
\t</div>
</footer>
<script defer src=\"<%= htmlWebpackPlugin.files.chunks.main.entry %>\"></script>
</html>", "artist.html", "/home/ubuntu/sites/seekult-nitro/craft/templates/artist.html");
    }
}

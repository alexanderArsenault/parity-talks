<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Matrix/settings */
class __TwigTemplate_bbf21289209a97ee2972eb111f559df01923c4db0423a275fbaf6907671761ea extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Matrix/settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Matrix/settings", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        ob_start();
        // line 4
        echo "    <div class=\"mc-sidebar block-types\">
        <div class=\"mc-col-inner-container\">
            <div class=\"mc-col-heading\">
                <h5>";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Block Types", "app"), "html", null, true);
        echo "</h5>
            </div>
            <div class=\"mc-col-items\">
                <div class=\"mc-blocktypes\">
                    ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 11, $this->source); })()));
        foreach ($context['_seq'] as $context["blockTypeId"] => $context["blockType"]) {
            // line 12
            echo "                        <div class=\"matrixconfigitem mci-blocktype";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "hasFieldErrors", [])) {
                echo " error";
            }
            echo "\" data-id=\"";
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "\"";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "hasErrors", [], "method")) {
                echo " data-errors=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "getErrors", [], "method")), "html", null, true);
                echo "\"";
            }
            echo ">
                            <div class=\"mci-name\">
                                <h4>
                                    ";
            // line 15
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "name", []), "html", null, true);
            echo "
                                    ";
            // line 16
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "hasFieldErrors", [])) {
                // line 17
                echo "                                        <span data-icon=\"alert\"></span>
                                    ";
            }
            // line 19
            echo "                                </h4>
                                <div class=\"smalltext light code\">";
            // line 20
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "handle", []), "html", null, true);
            echo "</div>
                            </div>
                            <a class=\"settings icon";
            // line 22
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "hasErrors", [], "method")) {
                echo " error";
            }
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "html", null, true);
            echo "\" role=\"button\"></a>
                            <a class=\"move icon\" title=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
            echo "\" role=\"button\"></a>
                            <input class=\"hidden\" name=\"blockTypes[";
            // line 24
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "][name]\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "name", []), "html", null, true);
            echo "\">
                            <input class=\"hidden\" name=\"blockTypes[";
            // line 25
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "][handle]\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "handle", []), "html", null, true);
            echo "\">
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['blockTypeId'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "                </div>
                <button type=\"button\" class=\"btn add icon\">";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New block type", "app"), "html", null, true);
        echo "</button>
            </div>
        </div>
    </div>
    <div class=\"mc-sidebar mc-fields\">
        <div class=\"mc-col-inner-container hidden\">
            <div class=\"mc-col-heading\">
                <h5>";
        // line 36
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Fields", "app"), "html", null, true);
        echo "</h5>
            </div>
            <div class=\"mc-col-items\">
                ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 39, $this->source); })()));
        foreach ($context['_seq'] as $context["blockTypeId"] => $context["blockType"]) {
            // line 40
            echo "                    <div data-id=\"";
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "\" class=\"hidden\">
                        ";
            // line 41
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["blockTypeFields"]) || array_key_exists("blockTypeFields", $context) ? $context["blockTypeFields"] : (function () { throw new RuntimeError('Variable "blockTypeFields" does not exist.', 41, $this->source); })()), $context["blockTypeId"], [], "array"));
            foreach ($context['_seq'] as $context["fieldId"] => $context["layoutElement"]) {
                // line 42
                echo "                            ";
                $context["field"] = craft\helpers\Template::attribute($this->env, $this->source, $context["layoutElement"], "getField", [], "method");
                // line 43
                echo "                            <div class=\"matrixconfigitem mci-field";
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 43, $this->source); })()), "hasErrors", [], "method")) {
                    echo " error";
                }
                echo "\" data-id=\"";
                echo twig_escape_filter($this->env, $context["fieldId"], "html", null, true);
                echo "\">
                                <div class=\"mci-name\">
                                    <h4";
                // line 45
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["layoutElement"], "required", [])) {
                    echo " class=\"mci-required\"";
                }
                echo ">";
                // line 46
                if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 46, $this->source); })()), "name", []) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 46, $this->source); })()), "name", []) != "__blank__"))) {
                    // line 47
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 47, $this->source); })()), "name", []), "html", null, true);
                } else {
                    // line 49
                    echo "<em class=\"light\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("(blank)", "app"), "html", null, true);
                    echo "</em>";
                }
                // line 51
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 51, $this->source); })()), "hasErrors", [], "method")) {
                    echo " <span data-icon=\"alert\"></span>";
                }
                // line 52
                echo "</h4>
                                    <div class=\"smalltext light code\">";
                // line 53
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 53, $this->source); })()), "handle", []), "html", null, true);
                echo "</div>
                                </div>
                                <a class=\"move icon\" title=\"";
                // line 55
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\" role=\"button\"></a>
                            </div>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['fieldId'], $context['layoutElement'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 58
            echo "                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['blockTypeId'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "                <button type=\"button\" class=\"btn add icon\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New field", "app"), "html", null, true);
        echo "</button>
            </div>
        </div>
    </div>
    <div class=\"mc-field-settings\">
        <div class=\"mc-col-inner-container hidden\">
            <div class=\"mc-col-heading\">
                <h5>";
        // line 67
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Field Settings", "app"), "html", null, true);
        echo "</h5>
            </div>
            <div class=\"mc-col-items\">
                ";
        // line 70
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 70, $this->source); })()));
        foreach ($context['_seq'] as $context["blockTypeId"] => $context["blockType"]) {
            // line 71
            echo "                    <div data-id=\"";
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "\">
                        ";
            // line 72
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["blockTypeFields"]) || array_key_exists("blockTypeFields", $context) ? $context["blockTypeFields"] : (function () { throw new RuntimeError('Variable "blockTypeFields" does not exist.', 72, $this->source); })()), $context["blockTypeId"], [], "array"));
            foreach ($context['_seq'] as $context["fieldId"] => $context["layoutElement"]) {
                // line 73
                echo "                            ";
                $context["field"] = craft\helpers\Template::attribute($this->env, $this->source, $context["layoutElement"], "getField", [], "method");
                // line 74
                echo "                            <div data-id=\"";
                echo twig_escape_filter($this->env, $context["fieldId"], "html", null, true);
                echo "\" class=\"hidden\">
                                ";
                // line 75
                $_namespace = (((("blockTypes[" . $context["blockTypeId"]) . "][fields][") . $context["fieldId"]) . "]");
                if ($_namespace) {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 76
                        echo "                                    ";
                        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "id" => "name", "name" => "name", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 80
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 80, $this->source); })()), "name", []) != "__blank__")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 80, $this->source); })()), "name", [])) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 81
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 81, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true]], 76, $context, $this->getSourceContext());
                        // line 83
                        echo "

                                    ";
                        // line 85
                        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 93
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 93, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 94
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 94, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 85, $context, $this->getSourceContext());
                        // line 96
                        echo "

                                    ";
                        // line 98
                        echo twig_call_macro($macros["forms"], "macro_textareaField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 103
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 103, $this->source); })()), "instructions", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 104
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 104, $this->source); })()), "getErrors", [0 => "instructions"], "method")]], 98, $context, $this->getSourceContext());
                        // line 105
                        echo "

                                    <fieldset>
                                        ";
                        // line 108
                        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is required", "app"), "id" => "required", "name" => "required", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 112
$context["layoutElement"], "required", [])]], 108, $context, $this->getSourceContext());
                        // line 113
                        echo "

                                        ";
                        // line 115
                        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use this field’s values as search keywords", "app"), "id" => "searchable", "name" => "searchable", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 119
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 119, $this->source); })()), "searchable", [])]], 115, $context, $this->getSourceContext());
                        // line 120
                        echo "
                                    </fieldset>

                                    ";
                        // line 123
                        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "app"), "warning" => ((( !craft\helpers\Template::attribute($this->env, $this->source,                         // line 125
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 125, $this->source); })()), "getIsNew", [], "method") &&  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 125, $this->source); })()), "hasErrors", [0 => "type"], "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" => (((twig_slice($this->env,                         // line 128
$context["fieldId"], 0, 3) != "new")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new RuntimeError('Variable "fieldTypes" does not exist.', 128, $this->source); })()), $context["fieldId"], [], "array")) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new RuntimeError('Variable "fieldTypes" does not exist.', 128, $this->source); })()), "new", []))), "value" => get_class(                        // line 129
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 129, $this->source); })())), "errors" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 130
($context["field"] ?? null), "getErrors", [0 => "type"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "getErrors", [0 => "type"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "getErrors", [0 => "type"], "method")) : (null))]], 123, $context, $this->getSourceContext());
                        // line 131
                        echo "

                                    ";
                        // line 133
                        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 133, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
                            // line 134
                            echo "                                        ";
                            $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 134, $this->source); })()), "supportedTranslationMethods", []);
                            // line 135
                            echo "                                        <div id=\"translation-settings\"";
                            if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 135, $this->source); })())) < 2)) {
                                echo " class=\"hidden\"";
                            }
                            echo ">
                                            ";
                            // line 136
                            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "app"), "id" => "translation-method", "name" => "translationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((twig_in_filter("none",                             // line 141
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 141, $this->source); })()))) ? (["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")]) : ("")), 1 => ((twig_in_filter("site",                             // line 142
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 142, $this->source); })()))) ? (["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")]) : ("")), 2 => ((twig_in_filter("siteGroup",                             // line 143
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 143, $this->source); })()))) ? (["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")]) : ("")), 3 => ((twig_in_filter("language",                             // line 144
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 144, $this->source); })()))) ? (["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")]) : ("")), 4 => ((twig_in_filter("custom",                             // line 145
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 145, $this->source); })()))) ? (["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]) : (""))]), "value" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 147
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 147, $this->source); })()), "translationMethod", []), "toggle" => true, "targetPrefix" => "translation-method-"]], 136, $context, $this->getSourceContext());
                            // line 150
                            echo "

                                            ";
                            // line 152
                            if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 152, $this->source); })()))) {
                                // line 153
                                echo "                                                <div id=\"translation-method-custom\" ";
                                if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 153, $this->source); })()), "translationMethod", []) != "custom")) {
                                    echo "class=\"hidden\"";
                                }
                                echo ">
                                                    ";
                                // line 154
                                echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "app"), "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,                                 // line 158
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 158, $this->source); })()), "translationKeyFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                                 // line 159
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 159, $this->source); })()), "getErrors", [0 => "translationKeyFormat"], "method")]], 154, $context, $this->getSourceContext());
                                // line 160
                                echo "
                                                </div>
                                            ";
                            }
                            // line 163
                            echo "                                        </div>
                                    ";
                        }
                        // line 165
                        echo "
                                    ";
                        // line 166
                        echo craft\helpers\Html::hiddenInput("width", craft\helpers\Template::attribute($this->env, $this->source, $context["layoutElement"], "width", []), ["id" => "width"]);
                        // line 168
                        echo "
                                ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    // line 76
                    echo "                                    ";
                    echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "id" => "name", "name" => "name", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 80
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 80, $this->source); })()), "name", []) != "__blank__")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 80, $this->source); })()), "name", [])) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 81
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 81, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true]], 76, $context, $this->getSourceContext());
                    // line 83
                    echo "

                                    ";
                    // line 85
                    echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 93
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 93, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 94
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 94, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 85, $context, $this->getSourceContext());
                    // line 96
                    echo "

                                    ";
                    // line 98
                    echo twig_call_macro($macros["forms"], "macro_textareaField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 103
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 103, $this->source); })()), "instructions", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 104
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 104, $this->source); })()), "getErrors", [0 => "instructions"], "method")]], 98, $context, $this->getSourceContext());
                    // line 105
                    echo "

                                    <fieldset>
                                        ";
                    // line 108
                    echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is required", "app"), "id" => "required", "name" => "required", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 112
$context["layoutElement"], "required", [])]], 108, $context, $this->getSourceContext());
                    // line 113
                    echo "

                                        ";
                    // line 115
                    echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use this field’s values as search keywords", "app"), "id" => "searchable", "name" => "searchable", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 119
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 119, $this->source); })()), "searchable", [])]], 115, $context, $this->getSourceContext());
                    // line 120
                    echo "
                                    </fieldset>

                                    ";
                    // line 123
                    echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "app"), "warning" => ((( !craft\helpers\Template::attribute($this->env, $this->source,                     // line 125
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 125, $this->source); })()), "getIsNew", [], "method") &&  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 125, $this->source); })()), "hasErrors", [0 => "type"], "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" => (((twig_slice($this->env,                     // line 128
$context["fieldId"], 0, 3) != "new")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new RuntimeError('Variable "fieldTypes" does not exist.', 128, $this->source); })()), $context["fieldId"], [], "array")) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new RuntimeError('Variable "fieldTypes" does not exist.', 128, $this->source); })()), "new", []))), "value" => get_class(                    // line 129
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 129, $this->source); })())), "errors" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 130
($context["field"] ?? null), "getErrors", [0 => "type"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "getErrors", [0 => "type"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "getErrors", [0 => "type"], "method")) : (null))]], 123, $context, $this->getSourceContext());
                    // line 131
                    echo "

                                    ";
                    // line 133
                    if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 133, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
                        // line 134
                        echo "                                        ";
                        $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 134, $this->source); })()), "supportedTranslationMethods", []);
                        // line 135
                        echo "                                        <div id=\"translation-settings\"";
                        if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 135, $this->source); })())) < 2)) {
                            echo " class=\"hidden\"";
                        }
                        echo ">
                                            ";
                        // line 136
                        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "app"), "id" => "translation-method", "name" => "translationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((twig_in_filter("none",                         // line 141
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 141, $this->source); })()))) ? (["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")]) : ("")), 1 => ((twig_in_filter("site",                         // line 142
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 142, $this->source); })()))) ? (["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")]) : ("")), 2 => ((twig_in_filter("siteGroup",                         // line 143
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 143, $this->source); })()))) ? (["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")]) : ("")), 3 => ((twig_in_filter("language",                         // line 144
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 144, $this->source); })()))) ? (["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")]) : ("")), 4 => ((twig_in_filter("custom",                         // line 145
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 145, $this->source); })()))) ? (["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]) : (""))]), "value" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 147
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 147, $this->source); })()), "translationMethod", []), "toggle" => true, "targetPrefix" => "translation-method-"]], 136, $context, $this->getSourceContext());
                        // line 150
                        echo "

                                            ";
                        // line 152
                        if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 152, $this->source); })()))) {
                            // line 153
                            echo "                                                <div id=\"translation-method-custom\" ";
                            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 153, $this->source); })()), "translationMethod", []) != "custom")) {
                                echo "class=\"hidden\"";
                            }
                            echo ">
                                                    ";
                            // line 154
                            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "app"), "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 158
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 158, $this->source); })()), "translationKeyFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 159
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 159, $this->source); })()), "getErrors", [0 => "translationKeyFormat"], "method")]], 154, $context, $this->getSourceContext());
                            // line 160
                            echo "
                                                </div>
                                            ";
                        }
                        // line 163
                        echo "                                        </div>
                                    ";
                    }
                    // line 165
                    echo "
                                    ";
                    // line 166
                    echo craft\helpers\Html::hiddenInput("width", craft\helpers\Template::attribute($this->env, $this->source, $context["layoutElement"], "width", []), ["id" => "width"]);
                    // line 168
                    echo "
                                ";
                }
                unset($_originalNamespace, $_namespace);
                // line 170
                echo "
                                <hr>

                                <div class=\"mc-fieldtype-settings\">
                                    <div>
                                        ";
                // line 175
                $_namespace = (((("blockTypes[" . $context["blockTypeId"]) . "][fields][") . $context["fieldId"]) . "][typesettings]");
                if ($_namespace) {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 176
                        echo "                                            ";
                        echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 176, $this->source); })()), "getSettingsHtml", [], "method");
                        echo "
                                        ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    echo "                                            ";
                    echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 176, $this->source); })()), "getSettingsHtml", [], "method");
                    echo "
                                        ";
                }
                unset($_originalNamespace, $_namespace);
                // line 178
                echo "                                    </div>
                                </div>

                                <hr>

                                <a class=\"error delete\">";
                // line 183
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                echo "</a>
                            </div>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['fieldId'], $context['layoutElement'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 186
            echo "                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['blockTypeId'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 188
        echo "            </div>
        </div>
    </div>
";
        $context["blockTypeInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 192
        echo "
<div id=\"matrix-configurator\" class=\"matrix-configurator\">
    ";
        // line 194
        echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Configuration", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Define the types of blocks that can be created within this Matrix field, as well as the fields each block type is made up of.", "app"), "name" => "config", "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 198
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 198, $this->source); })()), "getErrors", [0 => "blockTypes"], "method")],         // line 199
(isset($context["blockTypeInput"]) || array_key_exists("blockTypeInput", $context) ? $context["blockTypeInput"] : (function () { throw new RuntimeError('Variable "blockTypeInput" does not exist.', 199, $this->source); })())], 194, $context, $this->getSourceContext());
        echo "
</div>

";
        // line 202
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 202, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 203
            echo "    ";
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Propagation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which sites should blocks be saved to?", "app"), "id" => "propagationMethod", "name" => "propagationMethod", "options" => [0 => ["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Only save blocks to the site they were created in", "app")], 1 => ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save blocks to other sites in the same site group", "app")], 2 => ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save blocks to other sites with the same language", "app")], 3 => ["value" => "all", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save blocks to all sites the owner element is saved in", "app")]], "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 214
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 214, $this->source); })()), "propagationMethod", [])]], 203, $context, $this->getSourceContext());
            // line 215
            echo "

    ";
            // line 217
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 217, $this->source); })()), "id", []) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 217, $this->source); })()), "propagationMethod", []) != "none"))) {
                // line 218
                echo "        ";
                ob_start();
                // line 219
                echo "            (function() {
                var showingWarning = false;
                \$(\"#";
                // line 221
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["propagationMethod"]), "html", null, true);
                echo "\").on('change', function() {
                    if (\$(this).val() !== '";
                // line 222
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 222, $this->source); })()), "propagationMethod", []), "html", null, true);
                echo "') {
                        if (!showingWarning) {
                            \$('<p/>', {'class': 'warning', text: \"";
                // line 224
                echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Applying this change to existing blocks can take some time.", "app"), "js"), "html", null, true);
                echo "\"})
                                .appendTo(\$(\"#";
                // line 225
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["propagationMethod-field"]), "html", null, true);
                echo "\"));
                            showingWarning = true;
                        }
                    } else if (showingWarning) {
                        \$(\"#";
                // line 229
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["propagationMethod-field"]), "html", null, true);
                echo " .warning\").remove();
                        showingWarning = false;
                    }
                });
            })();
        ";
                craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
                // line 235
                echo "    ";
            }
        }
        // line 237
        echo "
";
        // line 238
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Min Blocks", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The minimum number of blocks the field is allowed to have.", "app"), "id" => "minBlocks", "name" => "minBlocks", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 243
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 243, $this->source); })()), "minBlocks", []), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 245
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 245, $this->source); })()), "getErrors", [0 => "minBlocks"], "method")]], 238, $context, $this->getSourceContext());
        // line 246
        echo "

";
        // line 248
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Blocks", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of blocks the field is allowed to have.", "app"), "id" => "maxBlocks", "name" => "maxBlocks", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 253
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 253, $this->source); })()), "maxBlocks", []), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 255
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 255, $this->source); })()), "getErrors", [0 => "maxBlocks"], "method")]], 248, $context, $this->getSourceContext());
        // line 256
        echo "
";
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Matrix/settings");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Matrix/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  619 => 256,  617 => 255,  616 => 253,  615 => 248,  611 => 246,  609 => 245,  608 => 243,  607 => 238,  604 => 237,  600 => 235,  591 => 229,  584 => 225,  580 => 224,  575 => 222,  571 => 221,  567 => 219,  564 => 218,  562 => 217,  558 => 215,  556 => 214,  554 => 203,  552 => 202,  546 => 199,  545 => 198,  544 => 194,  540 => 192,  534 => 188,  527 => 186,  518 => 183,  511 => 178,  492 => 176,  485 => 175,  478 => 170,  473 => 168,  471 => 166,  468 => 165,  464 => 163,  459 => 160,  457 => 159,  456 => 158,  455 => 154,  448 => 153,  446 => 152,  442 => 150,  440 => 147,  439 => 145,  438 => 144,  437 => 143,  436 => 142,  435 => 141,  434 => 136,  427 => 135,  424 => 134,  422 => 133,  418 => 131,  416 => 130,  415 => 129,  414 => 128,  413 => 125,  412 => 123,  407 => 120,  405 => 119,  404 => 115,  400 => 113,  398 => 112,  397 => 108,  392 => 105,  390 => 104,  389 => 103,  388 => 98,  384 => 96,  382 => 94,  381 => 93,  380 => 85,  376 => 83,  374 => 81,  373 => 80,  371 => 76,  360 => 168,  358 => 166,  355 => 165,  351 => 163,  346 => 160,  344 => 159,  343 => 158,  342 => 154,  335 => 153,  333 => 152,  329 => 150,  327 => 147,  326 => 145,  325 => 144,  324 => 143,  323 => 142,  322 => 141,  321 => 136,  314 => 135,  311 => 134,  309 => 133,  305 => 131,  303 => 130,  302 => 129,  301 => 128,  300 => 125,  299 => 123,  294 => 120,  292 => 119,  291 => 115,  287 => 113,  285 => 112,  284 => 108,  279 => 105,  277 => 104,  276 => 103,  275 => 98,  271 => 96,  269 => 94,  268 => 93,  267 => 85,  263 => 83,  261 => 81,  260 => 80,  258 => 76,  251 => 75,  246 => 74,  243 => 73,  239 => 72,  234 => 71,  230 => 70,  224 => 67,  213 => 60,  206 => 58,  197 => 55,  192 => 53,  189 => 52,  185 => 51,  180 => 49,  177 => 47,  175 => 46,  170 => 45,  160 => 43,  157 => 42,  153 => 41,  148 => 40,  144 => 39,  138 => 36,  128 => 29,  125 => 28,  114 => 25,  108 => 24,  104 => 23,  96 => 22,  91 => 20,  88 => 19,  84 => 17,  82 => 16,  78 => 15,  61 => 12,  57 => 11,  50 => 7,  45 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% set blockTypeInput %}
    <div class=\"mc-sidebar block-types\">
        <div class=\"mc-col-inner-container\">
            <div class=\"mc-col-heading\">
                <h5>{{ \"Block Types\"|t('app') }}</h5>
            </div>
            <div class=\"mc-col-items\">
                <div class=\"mc-blocktypes\">
                    {% for blockTypeId, blockType in blockTypes %}
                        <div class=\"matrixconfigitem mci-blocktype{% if blockType.hasFieldErrors %} error{% endif %}\" data-id=\"{{ blockTypeId }}\"{% if blockType.hasErrors() %} data-errors=\"{{ blockType.getErrors() | json_encode }}\"{% endif %}>
                            <div class=\"mci-name\">
                                <h4>
                                    {{ blockType.name }}
                                    {% if blockType.hasFieldErrors %}
                                        <span data-icon=\"alert\"></span>
                                    {% endif %}
                                </h4>
                                <div class=\"smalltext light code\">{{ blockType.handle }}</div>
                            </div>
                            <a class=\"settings icon{% if blockType.hasErrors() %} error{% endif %}\" title=\"{{ 'Settings'|t('app') }}\" role=\"button\"></a>
                            <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a>
                            <input class=\"hidden\" name=\"blockTypes[{{ blockTypeId }}][name]\" value=\"{{ blockType.name }}\">
                            <input class=\"hidden\" name=\"blockTypes[{{ blockTypeId }}][handle]\" value=\"{{ blockType.handle }}\">
                        </div>
                    {% endfor %}
                </div>
                <button type=\"button\" class=\"btn add icon\">{{ \"New block type\"|t('app') }}</button>
            </div>
        </div>
    </div>
    <div class=\"mc-sidebar mc-fields\">
        <div class=\"mc-col-inner-container hidden\">
            <div class=\"mc-col-heading\">
                <h5>{{ \"Fields\"|t('app') }}</h5>
            </div>
            <div class=\"mc-col-items\">
                {% for blockTypeId, blockType in blockTypes %}
                    <div data-id=\"{{ blockTypeId }}\" class=\"hidden\">
                        {% for fieldId, layoutElement in blockTypeFields[blockTypeId] %}
                            {% set field = layoutElement.getField() %}
                            <div class=\"matrixconfigitem mci-field{% if field.hasErrors() %} error{% endif %}\" data-id=\"{{ fieldId }}\">
                                <div class=\"mci-name\">
                                    <h4{% if layoutElement.required %} class=\"mci-required\"{% endif %}>
                                        {%- if field.name and field.name != '__blank__' -%}
                                            {{ field.name }}
                                        {%- else -%}
                                            <em class=\"light\">{{ '(blank)'|t('app') }}</em>
                                        {%- endif -%}
                                        {%- if field.hasErrors() %} <span data-icon=\"alert\"></span>{% endif -%}
                                    </h4>
                                    <div class=\"smalltext light code\">{{ field.handle }}</div>
                                </div>
                                <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a>
                            </div>
                        {% endfor %}
                    </div>
                {% endfor %}
                <button type=\"button\" class=\"btn add icon\">{{ \"New field\"|t('app') }}</button>
            </div>
        </div>
    </div>
    <div class=\"mc-field-settings\">
        <div class=\"mc-col-inner-container hidden\">
            <div class=\"mc-col-heading\">
                <h5>{{ \"Field Settings\"|t('app') }}</h5>
            </div>
            <div class=\"mc-col-items\">
                {% for blockTypeId, blockType in blockTypes %}
                    <div data-id=\"{{ blockTypeId }}\">
                        {% for fieldId, layoutElement in blockTypeFields[blockTypeId] %}
                            {% set field = layoutElement.getField() %}
                            <div data-id=\"{{ fieldId }}\" class=\"hidden\">
                                {% namespace 'blockTypes['~blockTypeId~'][fields]['~fieldId~']' %}
                                    {{ forms.textField({
                                        label: \"Name\"|t('app'),
                                        id: 'name',
                                        name: 'name',
                                        value: (field.name != '__blank__' ? field.name),
                                        errors: field.getErrors('name'),
                                        autofocus: true
                                    }) }}

                                    {{ forms.textField({
                                        label: \"Handle\"|t('app'),
                                        id: 'handle',
                                        name: 'handle',
                                        class: 'code',
                                        autocorrect: false,
                                        autocapitalize: false,
                                        maxlength: 64,
                                        value: field.handle,
                                        errors: field.getErrors('handle'),
                                        required: true,
                                    }) }}

                                    {{ forms.textareaField({
                                        label: \"Instructions\"|t('app'),
                                        id: 'instructions',
                                        class: 'nicetext',
                                        name: 'instructions',
                                        value: field.instructions,
                                        errors: field.getErrors('instructions'),
                                    }) }}

                                    <fieldset>
                                        {{ forms.checkboxField({
                                            label: \"This field is required\"|t('app'),
                                            id: 'required',
                                            name: 'required',
                                            checked: layoutElement.required
                                        }) }}

                                        {{ forms.checkboxField({
                                            label: 'Use this field’s values as search keywords'|t('app'),
                                            id: 'searchable',
                                            name: 'searchable',
                                            checked: field.searchable
                                        }) }}
                                    </fieldset>

                                    {{ forms.selectField({
                                        label: \"Field Type\"|t('app'),
                                        warning: (not field.getIsNew() and not field.hasErrors('type') ? \"Changing this may result in data loss.\"|t('app')),
                                        id: 'type',
                                        name: 'type',
                                        options: fieldId[0:3] != 'new' ? fieldTypes[fieldId] : fieldTypes.new,
                                        value: className(field),
                                        errors: field.getErrors('type') ?? null
                                    }) }}

                                    {% if craft.app.getIsMultiSite() %}
                                        {% set translationMethods = field.supportedTranslationMethods %}
                                        <div id=\"translation-settings\"{% if translationMethods|length < 2 %} class=\"hidden\"{% endif %}>
                                            {{ forms.selectField({
                                                label: \"Translation Method\"|t('app'),
                                                id: 'translation-method',
                                                name: 'translationMethod',
                                                options: [
                                                    'none' in translationMethods ? { value: 'none', label: \"Not translatable\"|t('app') },
                                                    'site' in translationMethods ? { value: 'site', label: \"Translate for each site\"|t('app') },
                                                    'siteGroup' in translationMethods ? { value: 'siteGroup', label: \"Translate for each site group\"|t('app') },
                                                    'language' in translationMethods ? { value: 'language', label: \"Translate for each language\"|t('app') },
                                                    'custom' in translationMethods ? { value: 'custom', label: \"Custom…\"|t('app') }
                                                ]|filter,
                                                value: field.translationMethod,
                                                toggle: true,
                                                targetPrefix: 'translation-method-'
                                            }) }}

                                            {% if 'custom' in translationMethods %}
                                                <div id=\"translation-method-custom\" {% if field.translationMethod != 'custom' %}class=\"hidden\"{% endif %}>
                                                    {{ forms.textField({
                                                        label: \"Translation Key Format\"|t('app'),
                                                        id: 'translation-key-format',
                                                        name: 'translationKeyFormat',
                                                        value: field.translationKeyFormat,
                                                        errors: field.getErrors('translationKeyFormat')
                                                    }) }}
                                                </div>
                                            {% endif %}
                                        </div>
                                    {% endif %}

                                    {{ hiddenInput('width', layoutElement.width, {
                                        id: 'width',
                                    }) }}
                                {% endnamespace %}

                                <hr>

                                <div class=\"mc-fieldtype-settings\">
                                    <div>
                                        {% namespace 'blockTypes['~blockTypeId~'][fields]['~fieldId~'][typesettings]' %}
                                            {{ field.getSettingsHtml()|raw  }}
                                        {% endnamespace %}
                                    </div>
                                </div>

                                <hr>

                                <a class=\"error delete\">{{ \"Delete\"|t('app') }}</a>
                            </div>
                        {% endfor %}
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>
{% endset %}

<div id=\"matrix-configurator\" class=\"matrix-configurator\">
    {{ forms.field({
        label: \"Configuration\"|t('app'),
        instructions: \"Define the types of blocks that can be created within this Matrix field, as well as the fields each block type is made up of.\"|t('app'),
        name: 'config',
        errors: matrixField.getErrors('blockTypes'),
    }, blockTypeInput) }}
</div>

{% if craft.app.getIsMultiSite() %}
    {{ forms.selectField({
        label: 'Propagation Method'|t('app'),
        instructions: 'Which sites should blocks be saved to?'|t('app'),
        id: 'propagationMethod',
        name: 'propagationMethod',
        options: [
            { value: 'none', label: 'Only save blocks to the site they were created in'|t('app') },
            { value: 'siteGroup', label: 'Save blocks to other sites in the same site group'|t('app') },
            { value: 'language', label: 'Save blocks to other sites with the same language'|t('app') },
            { value: 'all', label: 'Save blocks to all sites the owner element is saved in'|t('app') },
        ],
        value: matrixField.propagationMethod
    }) }}

    {% if matrixField.id and matrixField.propagationMethod != 'none' %}
        {% js %}
            (function() {
                var showingWarning = false;
                \$(\"#{{ 'propagationMethod'|namespaceInputId }}\").on('change', function() {
                    if (\$(this).val() !== '{{ matrixField.propagationMethod }}') {
                        if (!showingWarning) {
                            \$('<p/>', {'class': 'warning', text: \"{{ 'Applying this change to existing blocks can take some time.'|t('app')|e('js') }}\"})
                                .appendTo(\$(\"#{{ 'propagationMethod-field'|namespaceInputId }}\"));
                            showingWarning = true;
                        }
                    } else if (showingWarning) {
                        \$(\"#{{ 'propagationMethod-field'|namespaceInputId }} .warning\").remove();
                        showingWarning = false;
                    }
                });
            })();
        {% endjs %}
    {% endif %}
{% endif %}

{{ forms.textField({
    label: \"Min Blocks\"|t('app'),
    instructions: \"The minimum number of blocks the field is allowed to have.\"|t('app'),
    id: 'minBlocks',
    name: 'minBlocks',
    value: matrixField.minBlocks,
    size: 3,
    errors: matrixField.getErrors('minBlocks')
}) }}

{{ forms.textField({
    label: \"Max Blocks\"|t('app'),
    instructions: \"The maximum number of blocks the field is allowed to have.\"|t('app'),
    id: 'maxBlocks',
    name: 'maxBlocks',
    value: matrixField.maxBlocks,
    size: 3,
    errors: matrixField.getErrors('maxBlocks')
}) }}
", "_components/fieldtypes/Matrix/settings", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_components/fieldtypes/Matrix/settings.html");
    }
}

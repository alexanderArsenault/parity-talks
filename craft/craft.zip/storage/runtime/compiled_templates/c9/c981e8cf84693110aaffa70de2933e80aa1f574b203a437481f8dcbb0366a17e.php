<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/lightswitch */
class __TwigTemplate_3955348179899185c6722c975f015516bcd78344f01e0c260caced4458051a63 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/lightswitch");
        // line 1
        $context["id"] = (($context["id"]) ?? (("lightswitch" . twig_random($this->env))));
        // line 2
        $context["on"] = (($context["on"]) ?? (false));
        // line 3
        $context["indeterminate"] = ( !(isset($context["on"]) || array_key_exists("on", $context) ? $context["on"] : (function () { throw new RuntimeError('Variable "on" does not exist.', 3, $this->source); })()) && (($context["indeterminate"]) ?? (false)));
        // line 4
        $context["value"] = (($context["value"]) ?? ("1"));
        // line 5
        $context["indeterminateValue"] = (($context["indeterminateValue"]) ?? ("-"));
        // line 6
        $context["small"] = (($context["small"]) ?? (false));
        // line 7
        $context["toggle"] = (($context["toggle"]) ?? (null));
        // line 8
        $context["reverseToggle"] = (($context["reverseToggle"]) ?? (null));
        // line 9
        $context["disabled"] = (((($context["disabled"]) ?? (false))) ? (true) : (false));
        // line 10
        $context["onLabel"] = (($context["onLabel"]) ?? ((($context["label"]) ?? (false))));
        // line 11
        $context["offLabel"] = (($context["offLabel"]) ?? (false));
        // line 12
        $context["hasOnLabel"] =  !((isset($context["onLabel"]) || array_key_exists("onLabel", $context) ? $context["onLabel"] : (function () { throw new RuntimeError('Variable "onLabel" does not exist.', 12, $this->source); })()) === false);
        // line 13
        $context["hasOffLabel"] =  !((isset($context["offLabel"]) || array_key_exists("offLabel", $context) ? $context["offLabel"] : (function () { throw new RuntimeError('Variable "offLabel" does not exist.', 13, $this->source); })()) === false);
        // line 14
        $context["hasLabels"] = ((isset($context["hasOnLabel"]) || array_key_exists("hasOnLabel", $context) ? $context["hasOnLabel"] : (function () { throw new RuntimeError('Variable "hasOnLabel" does not exist.', 14, $this->source); })()) || (isset($context["hasOffLabel"]) || array_key_exists("hasOffLabel", $context) ? $context["hasOffLabel"] : (function () { throw new RuntimeError('Variable "hasOffLabel" does not exist.', 14, $this->source); })()));
        // line 16
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 17
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 17, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "lightswitch", 1 => ((        // line 20
(isset($context["on"]) || array_key_exists("on", $context) ? $context["on"] : (function () { throw new RuntimeError('Variable "on" does not exist.', 20, $this->source); })())) ? ("on") : ("")), 2 => ((        // line 21
(isset($context["hasLabels"]) || array_key_exists("hasLabels", $context) ? $context["hasLabels"] : (function () { throw new RuntimeError('Variable "hasLabels" does not exist.', 21, $this->source); })())) ? ("has-labels") : ("")), 3 => ((        // line 22
(isset($context["indeterminate"]) || array_key_exists("indeterminate", $context) ? $context["indeterminate"] : (function () { throw new RuntimeError('Variable "indeterminate" does not exist.', 22, $this->source); })())) ? ("indeterminate") : ("")), 4 => ((        // line 23
(isset($context["small"]) || array_key_exists("small", $context) ? $context["small"] : (function () { throw new RuntimeError('Variable "small" does not exist.', 23, $this->source); })())) ? ("small") : ("")), 5 => (((        // line 24
(isset($context["toggle"]) || array_key_exists("toggle", $context) ? $context["toggle"] : (function () { throw new RuntimeError('Variable "toggle" does not exist.', 24, $this->source); })()) || (isset($context["reverseToggle"]) || array_key_exists("reverseToggle", $context) ? $context["reverseToggle"] : (function () { throw new RuntimeError('Variable "reverseToggle" does not exist.', 24, $this->source); })()))) ? ("fieldtoggle") : ("")), 6 => ((        // line 25
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 25, $this->source); })())) ? ("disabled") : (""))]), "tabindex" => "0", "data" => ["value" => (((        // line 29
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 29, $this->source); })()) != "1")) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 29, $this->source); })())) : (false)), "indeterminate-value" => (((        // line 30
(isset($context["indeterminateValue"]) || array_key_exists("indeterminateValue", $context) ? $context["indeterminateValue"] : (function () { throw new RuntimeError('Variable "indeterminateValue" does not exist.', 30, $this->source); })()) != "-")) ? ((isset($context["indeterminateValue"]) || array_key_exists("indeterminateValue", $context) ? $context["indeterminateValue"] : (function () { throw new RuntimeError('Variable "indeterminateValue" does not exist.', 30, $this->source); })())) : (false)), "target" => ((        // line 31
(isset($context["toggle"]) || array_key_exists("toggle", $context) ? $context["toggle"] : (function () { throw new RuntimeError('Variable "toggle" does not exist.', 31, $this->source); })())) ? ((isset($context["toggle"]) || array_key_exists("toggle", $context) ? $context["toggle"] : (function () { throw new RuntimeError('Variable "toggle" does not exist.', 31, $this->source); })())) : (false)), "reverse-target" => ((        // line 32
(isset($context["reverseToggle"]) || array_key_exists("reverseToggle", $context) ? $context["reverseToggle"] : (function () { throw new RuntimeError('Variable "reverseToggle" does not exist.', 32, $this->source); })())) ? ((isset($context["reverseToggle"]) || array_key_exists("reverseToggle", $context) ? $context["reverseToggle"] : (function () { throw new RuntimeError('Variable "reverseToggle" does not exist.', 32, $this->source); })())) : (false))], "role" => "switch", "aria" => ["checked" => ((        // line 36
(isset($context["on"]) || array_key_exists("on", $context) ? $context["on"] : (function () { throw new RuntimeError('Variable "on" does not exist.', 36, $this->source); })())) ? ("true") : ((((isset($context["indeterminate"]) || array_key_exists("indeterminate", $context) ? $context["indeterminate"] : (function () { throw new RuntimeError('Variable "indeterminate" does not exist.', 36, $this->source); })())) ? ("mixed") : ("false")))), "labelledby" => ((        // line 37
$context["labelId"]) ?? (null))]], ((        // line 39
$context["containerAttributes"]) ?? ([])), true);
        // line 41
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 42
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 42, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 44
        echo "
";
        // line 45
        ob_start();
        // line 46
        echo "    <div ";
        echo craft\helpers\Html::renderTagAttributes((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 46, $this->source); })()));
        echo ">
        <div class=\"lightswitch-container\">
            <div class=\"handle\"></div>
        </div>
        ";
        // line 50
        if ((isset($context["name"]) || array_key_exists("name", $context))) {
            // line 51
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 51, $this->source); })()), (((isset($context["on"]) || array_key_exists("on", $context) ? $context["on"] : (function () { throw new RuntimeError('Variable "on" does not exist.', 51, $this->source); })())) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 51, $this->source); })())) : ((((isset($context["indeterminate"]) || array_key_exists("indeterminate", $context) ? $context["indeterminate"] : (function () { throw new RuntimeError('Variable "indeterminate" does not exist.', 51, $this->source); })())) ? ((isset($context["indeterminateValue"]) || array_key_exists("indeterminateValue", $context) ? $context["indeterminateValue"] : (function () { throw new RuntimeError('Variable "indeterminateValue" does not exist.', 51, $this->source); })())) : ("")))), ["disabled" => (isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 51, $this->source); })())]);
        }
        // line 53
        echo "    </div>
";
        $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 55
        echo "
";
        // line 56
        if ((isset($context["hasLabels"]) || array_key_exists("hasLabels", $context) ? $context["hasLabels"] : (function () { throw new RuntimeError('Variable "hasLabels" does not exist.', 56, $this->source); })())) {
            // line 57
            echo "<div class=\"lightswitch-outer-container\">
        <div class=\"lightswitch-inner-container\">
            ";
            // line 59
            if ((isset($context["hasOffLabel"]) || array_key_exists("hasOffLabel", $context) ? $context["hasOffLabel"] : (function () { throw new RuntimeError('Variable "hasOffLabel" does not exist.', 59, $this->source); })())) {
                // line 60
                echo "                <label for=\"";
                echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 60, $this->source); })()), "html", null, true);
                echo "\" data-toggle=\"off\">";
                echo twig_escape_filter($this->env, (isset($context["offLabel"]) || array_key_exists("offLabel", $context) ? $context["offLabel"] : (function () { throw new RuntimeError('Variable "offLabel" does not exist.', 60, $this->source); })()), "html", null, true);
                echo "</label>
            ";
            }
            // line 62
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 62, $this->source); })()), "html", null, true);
            echo "
            ";
            // line 63
            if ((isset($context["hasOnLabel"]) || array_key_exists("hasOnLabel", $context) ? $context["hasOnLabel"] : (function () { throw new RuntimeError('Variable "hasOnLabel" does not exist.', 63, $this->source); })())) {
                // line 64
                echo "                <label for=\"";
                echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 64, $this->source); })()), "html", null, true);
                echo "\" data-toggle=\"on\">";
                echo twig_escape_filter($this->env, (isset($context["onLabel"]) || array_key_exists("onLabel", $context) ? $context["onLabel"] : (function () { throw new RuntimeError('Variable "onLabel" does not exist.', 64, $this->source); })()), "html", null, true);
                echo "</label>
            ";
            }
            // line 66
            echo "        </div>
    </div>
";
        } else {
            // line 69
            echo "    ";
            echo twig_escape_filter($this->env, (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 69, $this->source); })()), "html", null, true);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/lightswitch");
    }

    public function getTemplateName()
    {
        return "_includes/forms/lightswitch";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  148 => 69,  143 => 66,  135 => 64,  133 => 63,  128 => 62,  120 => 60,  118 => 59,  114 => 57,  112 => 56,  109 => 55,  105 => 53,  102 => 51,  100 => 50,  92 => 46,  90 => 45,  87 => 44,  84 => 42,  82 => 41,  80 => 39,  79 => 37,  78 => 36,  77 => 32,  76 => 31,  75 => 30,  74 => 29,  73 => 25,  72 => 24,  71 => 23,  70 => 22,  69 => 21,  68 => 20,  67 => 17,  66 => 16,  64 => 14,  62 => 13,  60 => 12,  58 => 11,  56 => 10,  54 => 9,  52 => 8,  50 => 7,  48 => 6,  46 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set id = id ?? ('lightswitch'~random()) %}
{%- set on = on ?? false %}
{%- set indeterminate = not on and (indeterminate ?? false) %}
{%- set value = value ?? '1' %}
{%- set indeterminateValue = indeterminateValue ?? '-' %}
{%- set small = small ?? false %}
{%- set toggle = toggle ?? null %}
{%- set reverseToggle = reverseToggle ?? null %}
{%- set disabled = (disabled ?? false) ? true : false %}
{%- set onLabel = onLabel ?? label ?? false %}
{%- set offLabel = offLabel ?? false %}
{%- set hasOnLabel = onLabel is not same as(false) %}
{%- set hasOffLabel = offLabel is not same as(false) %}
{%- set hasLabels = hasOnLabel or hasOffLabel %}

{%- set containerAttributes = {
    id: id,
    class: [
        'lightswitch',
        on ? 'on',
        hasLabels ? 'has-labels',
        indeterminate ? 'indeterminate',
        small ? 'small',
        toggle or reverseToggle ? 'fieldtoggle',
        disabled ? 'disabled',
    ]|filter,
    tabindex: '0',
    data: {
        'value': value != '1' ? value : false,
        'indeterminate-value': indeterminateValue != '-' ? indeterminateValue : false,
        'target': toggle ?: false,
        'reverse-target': reverseToggle ?: false,
    },
    role: 'switch',
    aria: {
        checked: on ? 'true' : (indeterminate ? 'mixed' : 'false'),
        labelledby: labelId ?? null,
    },
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% set input %}
    <div {{ attr(containerAttributes) }}>
        <div class=\"lightswitch-container\">
            <div class=\"handle\"></div>
        </div>
        {% if name is defined -%}
            {{ hiddenInput(name, on ? value : (indeterminate ? indeterminateValue : ''), {disabled: disabled}) }}
        {%- endif %}
    </div>
{% endset %}

{% if hasLabels -%}
    <div class=\"lightswitch-outer-container\">
        <div class=\"lightswitch-inner-container\">
            {% if hasOffLabel %}
                <label for=\"{{ id }}\" data-toggle=\"off\">{{ offLabel }}</label>
            {% endif %}
            {{ input }}
            {% if hasOnLabel %}
                <label for=\"{{ id }}\" data-toggle=\"on\">{{ onLabel }}</label>
            {% endif %}
        </div>
    </div>
{% else %}
    {{ input }}
{%- endif %}
", "_includes/forms/lightswitch", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/forms/lightswitch.html");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/checkbox */
class __TwigTemplate_5f1eb72a01a63756609269fc4ed2e2b7de7b2ba526a6c23253f25a201ce1d77f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/checkbox");
        // line 1
        ob_start();
        // line 2
        echo "
";
        // line 3
        $context["id"] = ((((isset($context["id"]) || array_key_exists("id", $context)) && (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 3, $this->source); })()))) ? ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 3, $this->source); })())) : (("checkbox" . twig_random($this->env))));
        // line 4
        $context["label"] = (((isset($context["label"]) || array_key_exists("label", $context))) ? ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 4, $this->source); })())) : (""));
        // line 5
        echo "
";
        // line 6
        $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>         // line 7
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 7, $this->source); })()), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass(((        // line 8
$context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((((        // line 9
$context["toggle"]) ?? ((($context["reverseToggle"]) ?? (false))))) ? ("fieldtoggle") : ("")), 1 => "checkbox"])), "checked" => (((        // line 12
$context["checked"]) ?? (false)) && (isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 12, $this->source); })())), "autofocus" => (((        // line 13
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 13, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method")), "disabled" => ((((        // line 14
$context["disabled"]) ?? (false))) ? (true) : (false)), "data" => ["target" => ((        // line 16
$context["toggle"]) ?? (false)), "reverse-target" => ((        // line 17
$context["reverseToggle"]) ?? (false))]], ((        // line 19
$context["inputAttributes"]) ?? ([])), true);
        // line 20
        echo "
";
        // line 21
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 22
            $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 22, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 24
        echo "
";
        // line 25
        if (((isset($context["name"]) || array_key_exists("name", $context)) && ((twig_length_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 25, $this->source); })())) < 3) || (twig_slice($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 25, $this->source); })()),  -2) != "[]")))) {
            // line 26
            echo "    ";
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 26, $this->source); })()), "");
            echo "
";
        }
        // line 28
        echo "
";
        // line 29
        echo craft\helpers\Html::input("checkbox", (($context["name"]) ?? (null)), (($context["value"]) ?? (1)), (isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 29, $this->source); })()));
        echo "

<label for=\"";
        // line 31
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 31, $this->source); })()), "html", null, true);
        echo "\">
    ";
        // line 32
        echo twig_escape_filter($this->env, (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 32, $this->source); })()), "html", null, true);
        echo "
    ";
        // line 33
        if ((($context["info"]) ?? (null))) {
            // line 34
            echo "        <span class=\"info\">";
            echo $this->extensions['craft\web\twig\Extension']->markdownFilter((isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new RuntimeError('Variable "info" does not exist.', 34, $this->source); })()));
            echo "</span>
    ";
        }
        // line 36
        echo "</label>

";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        craft\helpers\Template::endProfile("template", "_includes/forms/checkbox");
    }

    public function getTemplateName()
    {
        return "_includes/forms/checkbox";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 36,  98 => 34,  96 => 33,  92 => 32,  88 => 31,  83 => 29,  80 => 28,  74 => 26,  72 => 25,  69 => 24,  66 => 22,  64 => 21,  61 => 20,  59 => 19,  58 => 17,  57 => 16,  56 => 14,  55 => 13,  54 => 12,  53 => 9,  52 => 8,  51 => 7,  50 => 6,  47 => 5,  45 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- spaceless %}

{% set id = (id is defined and id ? id : 'checkbox'~random()) %}
{% set label = (label is defined ? label) %}

{% set inputAttributes = {
    'id': id,
    'class': (class ?? [])|explodeClass|merge([
        (toggle ?? reverseToggle ?? false) ? 'fieldtoggle',
        'checkbox'
    ]|filter),
    'checked': (checked ?? false) and checked,
    'autofocus': (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
    'disabled': (disabled ?? false) ? true : false,
    'data': {
        'target': toggle ?? false,
        'reverse-target': reverseToggle ?? false,
    }
}|merge(inputAttributes ?? [], recursive=true) %}

{% if block('attr') is defined %}
    {%- set inputAttributes = inputAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% if name is defined and (name|length < 3 or name|slice(-2) != '[]') %}
    {{ hiddenInput(name, '') }}
{% endif %}

{{ input('checkbox', name ?? null, value ?? 1, inputAttributes) }}

<label for=\"{{ id }}\">
    {{ label }}
    {% if info ?? null %}
        <span class=\"info\">{{ info|md|raw }}</span>
    {% endif %}
</label>

{% endspaceless -%}
", "_includes/forms/checkbox", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/forms/checkbox.html");
    }
}

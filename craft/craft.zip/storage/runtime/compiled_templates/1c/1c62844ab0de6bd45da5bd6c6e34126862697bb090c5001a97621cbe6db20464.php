<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* logbook/_entry */
class __TwigTemplate_eda288eb29173e9e4b4dadf5766eff3d9cbc41a524d55b69083f698a4717e7df extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "logbook/_entry");
        $this->parent = $this->loadTemplate("_layout", "logbook/_entry", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "logbook/_entry");
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 4
        echo "
<main>
\t<section id=\"logbook\">
\t\t<div class=\"wrapper\">
\t\t\t<div class=\"interaction-container active main\">
\t\t\t\t";
        // line 9
        $context["logbookEntry"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 9, $this->source); })()), "entries", []), "section", [0 => "logbookEntries"], "method"), "first", [], "method");
        // line 10
        echo "
\t\t\t\t<div class=\"interaction-header\">
\t\t\t\t\t<h4 class=\"interaction-date\">Interaction ";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logbookEntry"]) || array_key_exists("logbookEntry", $context) ? $context["logbookEntry"] : (function () { throw new RuntimeError('Variable "logbookEntry" does not exist.', 12, $this->source); })()), "entryDate", []), "short"), "html", null, true);
        echo "</h4>
\t\t\t\t\t<h3 class=\"interaction-prompt\"> ";
        // line 13
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logbookEntry"]) || array_key_exists("logbookEntry", $context) ? $context["logbookEntry"] : (function () { throw new RuntimeError('Variable "logbookEntry" does not exist.', 13, $this->source); })()), "title", []), "html", null, true);
        echo "</h3>
\t\t\t\t</div>

\t\t\t\t<div class=\"answers-list\">

\t\t\t\t\t";
        // line 18
        if (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logbookEntry"]) || array_key_exists("logbookEntry", $context) ? $context["logbookEntry"] : (function () { throw new RuntimeError('Variable "logbookEntry" does not exist.', 18, $this->source); })()), "logbookResponses", []))) {
            // line 19
            echo "\t\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logbookEntry"]) || array_key_exists("logbookEntry", $context) ? $context["logbookEntry"] : (function () { throw new RuntimeError('Variable "logbookEntry" does not exist.', 19, $this->source); })()), "logbookResponses", []));
            foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                // line 20
                echo "\t\t\t\t\t\t\t<div class=\"answer-container active\">
\t\t\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t\t\t<p class=\"answer-name\">";
                // line 23
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "responseName", []), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t\t\t<p class=\"answer-title\">";
                // line 24
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "responseTitle", []), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t\t\t";
                // line 27
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "type", []) == "photo")) {
                    // line 28
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"answer-photo\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                    // line 29
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "photo", []), "first", [], "method"), "url", []), "html", null, true);
                    echo "\" />
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 32
                echo "
\t\t\t\t\t\t\t\t\t";
                // line 33
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "type", []) == "video")) {
                    // line 34
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"answer-video\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "video", []), "html", null, true);
                    echo "</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 36
                echo "
\t\t\t\t\t\t\t\t\t";
                // line 37
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "type", []) == "audio")) {
                    // line 38
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"answer-audio\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "audio", []), "html", null, true);
                    echo "</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 40
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t";
                // line 41
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "type", []) == "text")) {
                    // line 42
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"answer-text\">
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 43
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "text", []), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 46
                echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 49
            echo "\t\t\t\t\t";
        }
        // line 50
        echo "\t\t</div>
\t</section>

\t";
        // line 54
        echo "
\t<section id=\"archive\">
\t\t<div class=\"wrapper\">
\t\t\t<div class=\"archive-content\">
\t\t\t\t<h3>Logbook Archive</h3>

\t\t\t\t";
        // line 60
        $context["entries"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 60, $this->source); })()), "entries", []), "section", [0 => "logbookEntries"], "method");
        // line 61
        echo "
\t\t\t\t";
        // line 62
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entries"]) || array_key_exists("entries", $context) ? $context["entries"] : (function () { throw new RuntimeError('Variable "entries" does not exist.', 62, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 63
            echo "\t\t\t\t\t<div class=\"interaction-container active\">
\t\t\t\t\t\t<div class=\"interaction-header\">
\t\t\t\t\t\t\t<h4 class=\"interaction-date\">Interaction ";
            // line 65
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "entryDate", []), "short"), "html", null, true);
            echo "</h4>
\t\t\t\t\t\t\t<h3 class=\"interaction-prompt\"> ";
            // line 66
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "title", []), "html", null, true);
            echo "</h3>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"answers-list\">

\t\t\t\t\t\t\t";
            // line 71
            if (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "logbookResponses", []))) {
                // line 72
                echo "\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t";
                // line 73
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "logbookResponses", []));
                foreach ($context['_seq'] as $context["_key"] => $context["responseEntry"]) {
                    // line 74
                    echo "\t\t\t\t\t\t\t\t\t<div class=\"answer-container active\">
\t\t\t\t\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t\t\t\t\t<p class=\"answer-name\">";
                    // line 77
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "responseName", []), "html", null, true);
                    echo "</p>
\t\t\t\t\t\t\t\t\t\t\t<p class=\"answer-title\">";
                    // line 78
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "responseTitle", []), "html", null, true);
                    echo "</p>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 81
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "type", []) == "photo")) {
                        // line 82
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"answer-photo\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                        // line 83
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "photo", []), "first", [], "method"), "url", []), "html", null, true);
                        echo "\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 86
                    echo "
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 87
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "type", []) == "video")) {
                        // line 88
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"answer-video\">";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "video", []), "html", null, true);
                        echo "</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 90
                    echo "
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 91
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "type", []) == "audio")) {
                        // line 92
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"answer-audio\">";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "audio", []), "html", null, true);
                        echo "</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 94
                    echo "\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 95
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "type", []) == "text")) {
                        // line 96
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"answer-text\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 97
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["responseEntry"], "text", []), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 100
                    echo "\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['responseEntry'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 103
                echo "
\t\t\t\t\t\t\t";
            }
            // line 105
            echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 108
        echo "
\t</section>
\t
";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "logbook/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  287 => 108,  279 => 105,  275 => 103,  267 => 100,  261 => 97,  258 => 96,  256 => 95,  253 => 94,  247 => 92,  245 => 91,  242 => 90,  236 => 88,  234 => 87,  231 => 86,  225 => 83,  222 => 82,  220 => 81,  214 => 78,  210 => 77,  205 => 74,  201 => 73,  198 => 72,  196 => 71,  188 => 66,  184 => 65,  180 => 63,  176 => 62,  173 => 61,  171 => 60,  163 => 54,  158 => 50,  155 => 49,  147 => 46,  141 => 43,  138 => 42,  136 => 41,  133 => 40,  127 => 38,  125 => 37,  122 => 36,  116 => 34,  114 => 33,  111 => 32,  105 => 29,  102 => 28,  100 => 27,  94 => 24,  90 => 23,  85 => 20,  80 => 19,  78 => 18,  70 => 13,  66 => 12,  62 => 10,  60 => 9,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layout\" %}

{% block content %}

<main>
\t<section id=\"logbook\">
\t\t<div class=\"wrapper\">
\t\t\t<div class=\"interaction-container active main\">
\t\t\t\t{% set logbookEntry = craft.entries.section('logbookEntries').first() %}

\t\t\t\t<div class=\"interaction-header\">
\t\t\t\t\t<h4 class=\"interaction-date\">Interaction {{ logbookEntry.entryDate|date('short') }}</h4>
\t\t\t\t\t<h3 class=\"interaction-prompt\"> {{ logbookEntry.title }}</h3>
\t\t\t\t</div>

\t\t\t\t<div class=\"answers-list\">

\t\t\t\t\t{% if logbookEntry.logbookResponses|length %}
\t\t\t\t\t\t{% for entry in logbookEntry.logbookResponses %}
\t\t\t\t\t\t\t<div class=\"answer-container active\">
\t\t\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t\t\t<p class=\"answer-name\">{{ entry.responseName }}</p>
\t\t\t\t\t\t\t\t\t<p class=\"answer-title\">{{ entry.responseTitle }}</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t\t\t{% if entry.type == 'photo' %}
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-photo\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"{{entry.photo.first().url }}\" />
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t{% if entry.type == 'video' %}
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-video\">{{entry.video}}</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t{% if entry.type == 'audio' %}
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-audio\">{{entry.audio}}</div>
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t{% if entry.type == 'text' %}
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-text\">
\t\t\t\t\t\t\t\t\t\t\t{{entry.text}}
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t{% endif %}
\t\t</div>
\t</section>

\t{# Archive #}

\t<section id=\"archive\">
\t\t<div class=\"wrapper\">
\t\t\t<div class=\"archive-content\">
\t\t\t\t<h3>Logbook Archive</h3>

\t\t\t\t{% set entries = craft.entries.section('logbookEntries') %}

\t\t\t\t{% for entry in entries %}
\t\t\t\t\t<div class=\"interaction-container active\">
\t\t\t\t\t\t<div class=\"interaction-header\">
\t\t\t\t\t\t\t<h4 class=\"interaction-date\">Interaction {{ entry.entryDate|date('short') }}</h4>
\t\t\t\t\t\t\t<h3 class=\"interaction-prompt\"> {{ entry.title }}</h3>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"answers-list\">

\t\t\t\t\t\t\t{% if entry.logbookResponses|length %}
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t{% for responseEntry in entry.logbookResponses %}
\t\t\t\t\t\t\t\t\t<div class=\"answer-container active\">
\t\t\t\t\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t\t\t\t\t<p class=\"answer-name\">{{ responseEntry.responseName }}</p>
\t\t\t\t\t\t\t\t\t\t\t<p class=\"answer-title\">{{ responseEntry.responseTitle }}</p>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t\t\t\t\t{% if responseEntry.type == 'photo' %}
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"answer-photo\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"{{responseEntry.photo.first().url }}\" />
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t\t\t{% if responseEntry.type == 'video' %}
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"answer-video\">{{responseEntry.video}}</div>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t\t\t{% if responseEntry.type == 'audio' %}
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"answer-audio\">{{responseEntry.audio}}</div>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t{% if responseEntry.type == 'text' %}
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"answer-text\">
\t\t\t\t\t\t\t\t\t\t\t\t\t{{responseEntry.text}}
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t{% endfor %}

\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t{% endfor %}

\t</section>
\t
{% endblock %}
", "logbook/_entry", "/home/ubuntu/sites/seekult-nitro/craft/templates/logbook/_entry.twig");
    }
}

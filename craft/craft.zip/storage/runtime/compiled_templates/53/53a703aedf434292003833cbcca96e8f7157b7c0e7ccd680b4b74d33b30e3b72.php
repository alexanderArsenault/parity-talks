<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* program/_entry */
class __TwigTemplate_095868a61d3a4a1c074c33a606a92c997c5acb34b256bbd182636e03345097f6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "program/_entry");
        $this->parent = $this->loadTemplate("_layout", "program/_entry", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "program/_entry");
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 6
        echo "
<section id=\"events\">
\t<div class=\"wrapper\">
\t\t<h3>Interventions</h3>
\t\t<div class=\"interventions-container\">
\t\t\t<div class=\"map-container\"></div>

\t\t\t<div class=\"events-container\">
\t\t\t\t<div class=\"events-categories\">
\t\t\t\t\t<span>Adenaureplatz</span>
\t\t\t\t\t<span>Buchhornplatz</span>
\t\t\t\t\t<span>Moleturm</span>
\t\t\t\t</div>
\t\t\t\t<a href=\"#\" class=\"event-container adenauerplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type \">Adenauerplatz</div>
\t\t\t\t\t\t<h3>Dance with the Wolves</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container buchhornplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Buchhornplatz</div>
\t\t\t\t\t\t<h3>Dance with the Wolves</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container moleturm\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Moleturm</div>
\t\t\t\t\t\t<h3>Dance with the Wolves</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t</div>
\t\t</div>
\t</div>
</section>

<section id=\"artists\">
\t<div class=\"wrapper\">
\t\t<h3>Artists</h3>
\t\t<div class=\"artist-gallery\">
      ";
        // line 52
        $context["categories"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 52, $this->source); })()), "entries", []), "section", [0 => "artists"], "method"), "limit", [0 => 3], "method"), "order", [0 => "RAND()"], "method"), "find", [], "method");
        // line 53
        echo "
        ";
        // line 54
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) || array_key_exists("categories", $context) ? $context["categories"] : (function () { throw new RuntimeError('Variable "categories" does not exist.', 54, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 55
            echo "        ";
            $context["image"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method")) : (null));
            // line 56
            echo "        ";
            $context["url"] = craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "slug", []);
            // line 57
            echo "
          <a href=\"/program/";
            // line 58
            echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 58, $this->source); })()), "html", null, true);
            echo "\" class=\"artist\">
            <article>
              <div class=\"artist-image\" style=\"background-image: url('";
            // line 60
            echo twig_escape_filter($this->env, (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new RuntimeError('Variable "image" does not exist.', 60, $this->source); })()), "html", null, true);
            echo "');\"></div>
              <p class=\"artist-title\">";
            // line 61
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "title", []), "html", null, true);
            echo "</p>
            </article>
          </a>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 65
        echo "\t\t</div>
\t</div>
</section>

";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "program/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 65,  128 => 61,  124 => 60,  119 => 58,  116 => 57,  113 => 56,  110 => 55,  106 => 54,  103 => 53,  101 => 52,  53 => 6,  48 => 5,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layout\" %}

{# https://craftcms.stackexchange.com/questions/1933/how-do-i-create-a-list-of-categories-and-display-the-entries-relating-to-each-of #}
{# That link shows how to show only category related items #}
{% block content %}

<section id=\"events\">
\t<div class=\"wrapper\">
\t\t<h3>Interventions</h3>
\t\t<div class=\"interventions-container\">
\t\t\t<div class=\"map-container\"></div>

\t\t\t<div class=\"events-container\">
\t\t\t\t<div class=\"events-categories\">
\t\t\t\t\t<span>Adenaureplatz</span>
\t\t\t\t\t<span>Buchhornplatz</span>
\t\t\t\t\t<span>Moleturm</span>
\t\t\t\t</div>
\t\t\t\t<a href=\"#\" class=\"event-container adenauerplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type \">Adenauerplatz</div>
\t\t\t\t\t\t<h3>Dance with the Wolves</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container buchhornplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Buchhornplatz</div>
\t\t\t\t\t\t<h3>Dance with the Wolves</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container moleturm\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Moleturm</div>
\t\t\t\t\t\t<h3>Dance with the Wolves</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t</div>
\t\t</div>
\t</div>
</section>

<section id=\"artists\">
\t<div class=\"wrapper\">
\t\t<h3>Artists</h3>
\t\t<div class=\"artist-gallery\">
      {% set categories = craft.entries.section('artists').limit(3).order('RAND()').find() %}

        {% for entry in categories %}
        {% set image = entry.artistImage.one().getUrl() ?? null %}
        {% set url = entry.slug %}

          <a href=\"/program/{{url}}\" class=\"artist\">
            <article>
              <div class=\"artist-image\" style=\"background-image: url('{{ image }}');\"></div>
              <p class=\"artist-title\">{{entry.title}}</p>
            </article>
          </a>
        {% endfor %}
\t\t</div>
\t</div>
</section>

{% endblock %}
", "program/_entry", "/home/ubuntu/sites/seekult-nitro/craft/templates/program/_entry.twig");
    }
}

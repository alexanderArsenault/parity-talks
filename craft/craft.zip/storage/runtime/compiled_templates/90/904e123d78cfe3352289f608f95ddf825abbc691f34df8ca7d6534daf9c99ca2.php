<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/*  */
class __TwigTemplate_cabab9a750280db15f8dc232d2db968f0856d89f40c92a3550f509b70dc79b4a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "");
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
\t<meta charset=\"UTF-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\" />
\t<title>SeeKULT</title>
\t<link rel=\"stylesheet\" href=\"<%=htmlWebpackPlugin.files.chunks.main.css %>\">
\t<link rel=\"icon\" href=\"./favicon.ico\">
\t<link rel=\"apple-touch-icon\" href=\"/apple-touch-icon.png\" />
";
        // line 10
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>
<body>";
        // line 11
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "

<header>
\t\t<nav>
\t\t\t<ul>
\t\t\t\t<li><a href=\"/index.html\">Home</a></li>
\t\t\t\t<li><a href=\"/program.html\">Program</a></li>
\t\t\t\t<li><a href=\"/about.html\">About</a></li>
\t\t\t\t<li><a href=\"/logbook.html\">Logbook</a></li>
\t\t\t\t<li><a href=\"/stream.html\">Stream</a></li>
\t\t\t</ul>
\t\t</nav>
</header>

<main>
\t<section id=\"hero\">
\t\t<div class=\"wrapper\">
\t\t\t<!-- <div class=\"sponsors\">

\t\t\t\t<div class=\"img-container main\"><img src=\"src/assets/img/theme/sponsors/zug.png\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container main\"><img src=\"src/assets/img/theme/sponsors/sws.png\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container\"><img src=\"src/assets/img/theme/sponsors/blumenhaus.png\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container\"><img src=\"src/assets/img/theme/sponsors/gessler.jpg\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container\"><img src=\"src/assets/img/theme/sponsors/rathaus.png\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container\"><img src=\"src/assets/img/theme/sponsors/student.png\" alt=\"\"></div>
\t\t\t
\t\t\t</div> -->
\t\t\t<div class=\"hero-header__content\">
\t\t\t\t<h1 class=\"page-title\">Prasenzen</h1>
\t\t\t\t<h3 class=\"page-subtitle\">Kunstinterventionen im Friedrichshafener Stadtraum</h3>
\t\t\t\t<h3>10.10.2020</h3>
\t\t\t\t<button class=\"primary\"> View Program</button>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"hero-background\">
\t\t\t<div class=\"logo-container\"></div>
\t\t</div>
\t</section>

\t</main>
\t<section id=\"logbook\">
\t\t<div class=\"wrapper\">
\t\t\t<div class=\"interaction-container active main\">
\t\t\t\t<div class=\"interaction-header\">
\t\t\t\t\t<h4 class=\"interaction-date\">Today's Interaction</h4>
\t\t\t\t\t<h3 class=\"interaction-prompt\">How do you feel public presence has changed during the COVID-19 Presence?</h3>
\t\t\t\t</div>
\t\t\t\t<div class=\"answers-list\">

\t\t\t\t\t<div class=\"answer-container active\">
\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t<p class=\"answer-name\">Jeremy Lin</p>
\t\t\t\t\t\t\t<p class=\"answer-title\">3rd Semester Student</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t<div class=\"answer-photo\"></div>
\t\t\t\t\t\t\t<div class=\"answer-audio\"></div>
\t\t\t\t\t\t\t<p class=\"answer-text\">
\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet consectetur adipisicing elit. Similique aut soluta harum quibusdam eos consequatur veniam, nulla dolorum consectetur nihil eum voluptas error natus aspernatur?
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"answer-container inactive\">
\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t<p class=\"answer-name\">Jeremy Lin</p>
\t\t\t\t\t\t\t<p class=\"answer-title\">3rd Semester Student</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t<div class=\"answer-photo\"></div>
\t\t\t\t\t\t\t<div class=\"answer-audio\"></div>
\t\t\t\t\t\t\t<p class=\"answer-text\">
\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet consectetur adipisicing elit. Similique aut soluta harum quibusdam eos consequatur veniam, nulla dolorum consectetur nihil eum voluptas error natus aspernatur?
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<p><a class=\"link\" href=\"/logbook.html\">View more answers</a></p>
\t\t</div>
\t</section>
\t<section id=\"events\">
\t\t<div class=\"wrapper\">
\t\t\t<h3>Locations</h3>
\t\t\t<div class=\"events-container\">
\t\t\t\t<a href=\"#\" class=\"event-container adenauerplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type \">Adenauerplatz</div>
\t\t\t\t\t\t<h3>Adenauerplatz</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t\t<span>Larry Bingo</span>
\t\t\t\t\t\t<span>Oppsie, Daisey</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container buchhornplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Buchhornplatz</div>
\t\t\t\t\t\t<h3>Buchhornplatz</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container moleturm\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Moleturm</div>
\t\t\t\t\t\t<h3>Moleturm</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t</div>
\t\t\t<a href=\"./program.html\"><button class=\"primary\">View All Interventions</button></a>
\t\t</div>
\t</section>
\t<footer>
\t\t<div class=\"footer-contact\">
\t\t\t<p class=\"bold\">Contact</p>
\t\t\t<p class=\"text\"><a href=\"mailto:info@seekult.de\">info@seekult.de</a></p>
\t\t\t<p class=\"text\">Am Seemooser Horn 20</p>
\t\t\t<p class=\"text\">88045 Friedrichshafen, Germany</p>
\t\t</div>
\t\t<div class=\"footer-privacy\">
\t\t\t<p class=\"bold\">Privacy Policy</p>
\t\t\t<p class=\"text\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis tempore itaque nisi. Doloribus reprehenderit earum illo corporis accusamus necessitatibus sequi distinctio, voluptatem aliquam culpa. Voluptatibus, eaque incidunt! Sunt quidem suscipit inventore velit. Mollitia veritatis qui porro consequatur odit voluptate libero architecto sunt nobis labore! Magnam sed ducimus quidem iusto dolorum.</p>
\t\t</div>
\t</footer>
<script defer src=\"<%= htmlWebpackPlugin.files.chunks.main.entry %>\"></script>
</html>";
        craft\helpers\Template::endProfile("template", "");
    }

    public function getTemplateName()
    {
        return "";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 11,  49 => 10,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
\t<meta charset=\"UTF-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\" />
\t<title>SeeKULT</title>
\t<link rel=\"stylesheet\" href=\"<%=htmlWebpackPlugin.files.chunks.main.css %>\">
\t<link rel=\"icon\" href=\"./favicon.ico\">
\t<link rel=\"apple-touch-icon\" href=\"/apple-touch-icon.png\" />
</head>
<body>

<header>
\t\t<nav>
\t\t\t<ul>
\t\t\t\t<li><a href=\"/index.html\">Home</a></li>
\t\t\t\t<li><a href=\"/program.html\">Program</a></li>
\t\t\t\t<li><a href=\"/about.html\">About</a></li>
\t\t\t\t<li><a href=\"/logbook.html\">Logbook</a></li>
\t\t\t\t<li><a href=\"/stream.html\">Stream</a></li>
\t\t\t</ul>
\t\t</nav>
</header>

<main>
\t<section id=\"hero\">
\t\t<div class=\"wrapper\">
\t\t\t<!-- <div class=\"sponsors\">

\t\t\t\t<div class=\"img-container main\"><img src=\"src/assets/img/theme/sponsors/zug.png\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container main\"><img src=\"src/assets/img/theme/sponsors/sws.png\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container\"><img src=\"src/assets/img/theme/sponsors/blumenhaus.png\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container\"><img src=\"src/assets/img/theme/sponsors/gessler.jpg\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container\"><img src=\"src/assets/img/theme/sponsors/rathaus.png\" alt=\"\"></div>
\t\t\t\t<div class=\"img-container\"><img src=\"src/assets/img/theme/sponsors/student.png\" alt=\"\"></div>
\t\t\t
\t\t\t</div> -->
\t\t\t<div class=\"hero-header__content\">
\t\t\t\t<h1 class=\"page-title\">Prasenzen</h1>
\t\t\t\t<h3 class=\"page-subtitle\">Kunstinterventionen im Friedrichshafener Stadtraum</h3>
\t\t\t\t<h3>10.10.2020</h3>
\t\t\t\t<button class=\"primary\"> View Program</button>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"hero-background\">
\t\t\t<div class=\"logo-container\"></div>
\t\t</div>
\t</section>

\t</main>
\t<section id=\"logbook\">
\t\t<div class=\"wrapper\">
\t\t\t<div class=\"interaction-container active main\">
\t\t\t\t<div class=\"interaction-header\">
\t\t\t\t\t<h4 class=\"interaction-date\">Today's Interaction</h4>
\t\t\t\t\t<h3 class=\"interaction-prompt\">How do you feel public presence has changed during the COVID-19 Presence?</h3>
\t\t\t\t</div>
\t\t\t\t<div class=\"answers-list\">

\t\t\t\t\t<div class=\"answer-container active\">
\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t<p class=\"answer-name\">Jeremy Lin</p>
\t\t\t\t\t\t\t<p class=\"answer-title\">3rd Semester Student</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t<div class=\"answer-photo\"></div>
\t\t\t\t\t\t\t<div class=\"answer-audio\"></div>
\t\t\t\t\t\t\t<p class=\"answer-text\">
\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet consectetur adipisicing elit. Similique aut soluta harum quibusdam eos consequatur veniam, nulla dolorum consectetur nihil eum voluptas error natus aspernatur?
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"answer-container inactive\">
\t\t\t\t\t\t<div class=\"toggle-active-overlay\"></div>
\t\t\t\t\t\t<div class=\"answer-header\">
\t\t\t\t\t\t\t<p class=\"answer-name\">Jeremy Lin</p>
\t\t\t\t\t\t\t<p class=\"answer-title\">3rd Semester Student</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"answer-body\">
\t\t\t\t\t\t\t<div class=\"answer-photo\"></div>
\t\t\t\t\t\t\t<div class=\"answer-audio\"></div>
\t\t\t\t\t\t\t<p class=\"answer-text\">
\t\t\t\t\t\t\t\tLorem ipsum dolor sit amet consectetur adipisicing elit. Similique aut soluta harum quibusdam eos consequatur veniam, nulla dolorum consectetur nihil eum voluptas error natus aspernatur?
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<p><a class=\"link\" href=\"/logbook.html\">View more answers</a></p>
\t\t</div>
\t</section>
\t<section id=\"events\">
\t\t<div class=\"wrapper\">
\t\t\t<h3>Locations</h3>
\t\t\t<div class=\"events-container\">
\t\t\t\t<a href=\"#\" class=\"event-container adenauerplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type \">Adenauerplatz</div>
\t\t\t\t\t\t<h3>Adenauerplatz</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t\t<span>Larry Bingo</span>
\t\t\t\t\t\t<span>Oppsie, Daisey</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container buchhornplatz\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Buchhornplatz</div>
\t\t\t\t\t\t<h3>Buchhornplatz</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"#\" class=\"event-container moleturm\">
\t\t\t\t\t<div class=\"event-image\" style=\"background-image: url('src/assets/img/theme/Hintergrund.Raster.png');\"></div>
\t\t\t\t\t<div class=\"event-content\">
\t\t\t\t\t\t<div class=\"event-type\">Moleturm</div>
\t\t\t\t\t\t<h3>Moleturm</h3>
\t\t\t\t\t\t<span>Marcello Buigniano</span>
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t</div>
\t\t\t<a href=\"./program.html\"><button class=\"primary\">View All Interventions</button></a>
\t\t</div>
\t</section>
\t<footer>
\t\t<div class=\"footer-contact\">
\t\t\t<p class=\"bold\">Contact</p>
\t\t\t<p class=\"text\"><a href=\"mailto:info@seekult.de\">info@seekult.de</a></p>
\t\t\t<p class=\"text\">Am Seemooser Horn 20</p>
\t\t\t<p class=\"text\">88045 Friedrichshafen, Germany</p>
\t\t</div>
\t\t<div class=\"footer-privacy\">
\t\t\t<p class=\"bold\">Privacy Policy</p>
\t\t\t<p class=\"text\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis tempore itaque nisi. Doloribus reprehenderit earum illo corporis accusamus necessitatibus sequi distinctio, voluptatem aliquam culpa. Voluptatibus, eaque incidunt! Sunt quidem suscipit inventore velit. Mollitia veritatis qui porro consequatur odit voluptate libero architecto sunt nobis labore! Magnam sed ducimus quidem iusto dolorum.</p>
\t\t</div>
\t</footer>
<script defer src=\"<%= htmlWebpackPlugin.files.chunks.main.entry %>\"></script>
</html>", "", "/home/ubuntu/sites/seekult-nitro/craft/templates/index.html");
    }
}

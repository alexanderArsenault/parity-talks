<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/cp */
class __TwigTemplate_06a50277c02e1089884ec45d20e83a1dc63b300cb73e262cbb842c307873628f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'mainFormAttributes' => [$this, 'block_mainFormAttributes'],
            'header' => [$this, 'block_header'],
            'pageTitle' => [$this, 'block_pageTitle'],
            'contextMenu' => [$this, 'block_contextMenu'],
            'main' => [$this, 'block_main'],
            'tabs' => [$this, 'block_tabs'],
            'content' => [$this, 'block_content'],
            'actionButton' => [$this, 'block_actionButton'],
            'submitButton' => [$this, 'block_submitButton'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 40
        return "_layouts/basecp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/cp");
        // line 43
        $context["queue"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 43, $this->source); })()), "app", []), "queue", []);
        // line 44
        ob_start();
        // line 45
        echo "    ";
        if (call_user_func_array($this->env->getTest('instance of')->getCallable(), [(isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 45, $this->source); })()), "craft\\queue\\QueueInterface"])) {
            // line 46
            echo "        Craft.cp.setJobInfo(";
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 46, $this->source); })()), "getJobInfo", [0 => 100], "method"));
            echo ", false);
        ";
            // line 47
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 47, $this->source); })()), "getHasReservedJobs", [], "method")) {
                // line 48
                echo "            Craft.cp.trackJobProgress(true);
        ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 49
(isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 49, $this->source); })()), "getHasWaitingJobs", [], "method")) {
                // line 50
                echo "            Craft.cp.runQueue();
        ";
            }
            // line 52
            echo "    ";
        } else {
            // line 53
            echo "        Craft.cp.enableQueue = false;
    ";
        }
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 57
        $context["hasSystemIcon"] = (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 57, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 57, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 57, $this->source); })()), "rebrand", []), "isIconUploaded", []));
        // line 58
        $context["fullPageForm"] = ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context)) && (isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 58, $this->source); })()));
        // line 60
        $context["canUpgradeEdition"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 60, $this->source); })()), "app", []), "getCanUpgradeEdition", [], "method");
        // line 61
        $context["licensedEdition"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 61, $this->source); })()), "app", []), "getLicensedEdition", [], "method");
        // line 62
        $context["isTrial"] = ( !((isset($context["licensedEdition"]) || array_key_exists("licensedEdition", $context) ? $context["licensedEdition"] : (function () { throw new RuntimeError('Variable "licensedEdition" does not exist.', 62, $this->source); })()) === null) &&  !((isset($context["licensedEdition"]) || array_key_exists("licensedEdition", $context) ? $context["licensedEdition"] : (function () { throw new RuntimeError('Variable "licensedEdition" does not exist.', 62, $this->source); })()) === (isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 62, $this->source); })())));
        // line 64
        $context["sidebar"] = twig_trim_filter((($context["sidebar"]) ?? (((        $this->hasBlock("sidebar", $context, $blocks)) ? (        $this->renderBlock("sidebar", $context, $blocks)) : ("")))));
        // line 65
        $context["toolbar"] = twig_trim_filter((($context["toolbar"]) ?? (((        $this->hasBlock("toolbar", $context, $blocks)) ? (        $this->renderBlock("toolbar", $context, $blocks)) : ("")))));
        // line 66
        $context["actionButton"] = twig_trim_filter(((        $this->hasBlock("actionButton", $context, $blocks)) ? (        $this->renderBlock("actionButton", $context, $blocks)) : ("")));
        // line 67
        $context["details"] = twig_trim_filter((($context["details"]) ?? (((        $this->hasBlock("details", $context, $blocks)) ? (        $this->renderBlock("details", $context, $blocks)) : ("")))));
        // line 68
        $context["footer"] = twig_trim_filter((($context["footer"]) ?? (((        $this->hasBlock("footer", $context, $blocks)) ? (        $this->renderBlock("footer", $context, $blocks)) : ("")))));
        // line 69
        $context["crumbs"] = (($context["crumbs"]) ?? (null));
        // line 70
        $context["tabs"] = ((((isset($context["tabs"]) || array_key_exists("tabs", $context)) && (twig_length_filter($this->env, (isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 70, $this->source); })())) != 1))) ? ((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 70, $this->source); })())) : (null));
        // line 72
        $context["mainContentClasses"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((        // line 73
(isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 73, $this->source); })())) ? ("has-sidebar") : ("")), 1 => ((        // line 74
(isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 74, $this->source); })())) ? ("has-details") : ("")), 2 => ((        // line 75
(isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 75, $this->source); })())) ? ("has-tabs") : (""))]);
        // line 78
        $context["showHeader"] = (($context["showHeader"]) ?? (true));
        // line 79
        if ( !(isset($context["showHeader"]) || array_key_exists("showHeader", $context) ? $context["showHeader"] : (function () { throw new RuntimeError('Variable "showHeader" does not exist.', 79, $this->source); })())) {
            // line 80
            $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->pushFilter(craft\helpers\Html::explodeClass((($context["bodyClass"]) ?? ([]))), "no-header");
        }
        // line 83
        $context["mainAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => "main", "role" => "main"], ((        // line 86
$context["mainAttributes"]) ?? ([])));
        // line 88
        $context["mainFormAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => "main-form", "method" => "post", "accept-charset" => "UTF-8", "novalidate" => true, "data" => ["saveshortcut" => ((        // line 94
$context["saveShortcut"]) ?? (true)), "saveshortcut-redirect" => ((((        // line 95
$context["saveShortcutRedirect"]) ?? (false))) ? (call_user_func_array($this->env->getFilter('hash')->getCallable(), [(isset($context["saveShortcutRedirect"]) || array_key_exists("saveShortcutRedirect", $context) ? $context["saveShortcutRedirect"] : (function () { throw new RuntimeError('Variable "saveShortcutRedirect" does not exist.', 95, $this->source); })())])) : (false)), "saveshortcut-scroll" => ((        // line 96
$context["retainScrollOnSaveShortcut"]) ?? (false)), "actions" => ((        // line 97
$context["formActions"]) ?? (false)), "confirm-unload" => true, "delta" => craft\helpers\Template::attribute($this->env, $this->source,         // line 99
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 99, $this->source); })()), "getIsDeltaRegistrationActive", [], "method")]], ((        // line 101
$context["mainFormAttributes"]) ?? ([])), true);
        // line 103
        ob_start();
        // line 104
        echo "    <div class=\"header-photo\">
        ";
        // line 105
        echo $this->extensions['craft\web\twig\Extension']->tagFunction("img", ["width" => 30, "height" => 30, "sizes" => "30px", "srcset" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 109
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 109, $this->source); })()), "getThumbUrl", [0 => 30], "method") . " 30w, ") . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 109, $this->source); })()), "getThumbUrl", [0 => 60], "method")) . " 60w"), "alt" => craft\helpers\Template::attribute($this->env, $this->source,         // line 110
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 110, $this->source); })()), "getName", [], "method")]);
        // line 111
        echo "
    </div>
";
        $context["userPhoto"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 260
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 260, $this->source); })()), "can", [0 => "performUpdates"], "method") &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 260, $this->source); })()), "app", []), "updates", []), "getIsUpdateInfoCached", [], "method"))) {
            // line 261
            ob_start();
            // line 262
            echo "        Craft.cp.checkForUpdates();
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 40
        $this->parent = $this->loadTemplate("_layouts/basecp", "_layouts/cp", 40);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_layouts/cp");
    }

    // line 115
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 116
        echo "    <div id=\"global-container\">
        ";
        // line 117
        $this->loadTemplate("_layouts/components/global-sidebar", "_layouts/cp", 117)->display($context);
        // line 118
        echo "
        <div id=\"page-container\">
            ";
        // line 120
        $this->loadTemplate("_layouts/components/alerts", "_layouts/cp", 120)->display($context);
        // line 121
        echo "            ";
        $this->loadTemplate("_layouts/components/notifications", "_layouts/cp", 121)->display($context);
        // line 122
        echo "
            <div id=\"global-header\">
                <div class=\"flex\">
                    ";
        // line 125
        $this->loadTemplate("_layouts/components/crumbs", "_layouts/cp", 125)->display($context);
        // line 126
        echo "                    <div class=\"flex-grow\"></div>
                    <button type=\"button\" id=\"user-info\" class=\"btn menubtn\" aria-label=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "\" title=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "\" data-menu-anchor=\".header-photo\">
                        ";
        // line 128
        echo twig_escape_filter($this->env, (isset($context["userPhoto"]) || array_key_exists("userPhoto", $context) ? $context["userPhoto"] : (function () { throw new RuntimeError('Variable "userPhoto" does not exist.', 128, $this->source); })()), "html", null, true);
        echo "
                    </button>
                    <div class=\"menu\" data-align=\"right\">
                        <ul>
                            <li>
                                <a href=\"";
        // line 133
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("myaccount"), "html", null, true);
        echo "\" class=\"flex flex-nowrap\">
                                    ";
        // line 134
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 134, $this->source); })()), "photoId", [])) {
            // line 135
            echo "                                        ";
            echo twig_escape_filter($this->env, (isset($context["userPhoto"]) || array_key_exists("userPhoto", $context) ? $context["userPhoto"] : (function () { throw new RuntimeError('Variable "userPhoto" does not exist.', 135, $this->source); })()), "html", null, true);
            echo "
                                    ";
        }
        // line 137
        echo "                                    <div class=\"flex-grow\">
                                        <div>";
        // line 138
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 138, $this->source); })()), "username", []), "html", null, true);
        echo "</div>
                                        ";
        // line 139
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 139, $this->source); })()), "app", []), "config", []), "general", []), "useEmailAsUsername", [])) {
            // line 140
            echo "                                            <div class=\"light smalltext\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 140, $this->source); })()), "email", []), "html", null, true);
            echo "</div>
                                        ";
        }
        // line 142
        echo "                                    </div>
                                </a>
                            </li>
                        </ul>
                        <hr>
                        <ul>
                            <li><a href=\"";
        // line 148
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("logout"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign out", "app"), "html", null, true);
        echo "</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">
                <main ";
        // line 155
        echo craft\helpers\Html::renderTagAttributes((isset($context["mainAttributes"]) || array_key_exists("mainAttributes", $context) ? $context["mainAttributes"] : (function () { throw new RuntimeError('Variable "mainAttributes" does not exist.', 155, $this->source); })()));
        echo ">

                    ";
        // line 157
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 157, $this->source); })())) {
            // line 158
            echo "<form ";
            $this->displayBlock('mainFormAttributes', $context, $blocks);
            echo ">";
            // line 159
            echo craft\helpers\Html::csrfInput();
        }
        // line 161
        echo "
                    ";
        // line 162
        if ((isset($context["showHeader"]) || array_key_exists("showHeader", $context) ? $context["showHeader"] : (function () { throw new RuntimeError('Variable "showHeader" does not exist.', 162, $this->source); })())) {
            // line 163
            echo "                        <div id=\"header-container\">
                            <header id=\"header\">
                                ";
            // line 165
            $this->displayBlock('header', $context, $blocks);
            // line 185
            echo "                            </header><!-- #header -->
                        </div>
                    ";
        }
        // line 188
        echo "
                    <div id=\"main-content\" class=\"";
        // line 189
        echo twig_escape_filter($this->env, twig_join_filter((isset($context["mainContentClasses"]) || array_key_exists("mainContentClasses", $context) ? $context["mainContentClasses"] : (function () { throw new RuntimeError('Variable "mainContentClasses" does not exist.', 189, $this->source); })()), " "), "html", null, true);
        echo "\">
                        ";
        // line 191
        echo "                        ";
        if ((isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 191, $this->source); })())) {
            // line 192
            echo "                            <div id=\"sidebar-toggle-container\">
                                <button type=\"button\" id=\"sidebar-toggle\" class=\"btn menubtn\"><span id=\"selected-sidebar-item-label\"></span></button>
                            </div>
                            <div id=\"sidebar-container\">
                                <div id=\"sidebar\" class=\"sidebar\">
                                    ";
            // line 197
            echo (isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 197, $this->source); })());
            echo "
                                </div>
                            </div>
                        ";
        }
        // line 201
        echo "
                        ";
        // line 203
        echo "                        <div id=\"content-container\">
                            ";
        // line 204
        $this->displayBlock('main', $context, $blocks);
        // line 224
        echo "                        </div><!-- #content-container -->

                        ";
        // line 226
        if ( !twig_test_empty((isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 226, $this->source); })()))) {
            // line 227
            echo "                            <div id=\"details-container\">
                                <div id=\"details\">
                                    ";
            // line 229
            echo (isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 229, $this->source); })());
            echo "
                                </div>
                            </div>
                        ";
        }
        // line 233
        echo "                    </div><!-- #main-content -->

                    ";
        // line 235
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 235, $this->source); })())) {
            // line 236
            echo "</form><!-- #main-form -->";
        }
        // line 238
        echo "                </main><!-- #main -->
            </div><!-- #main-container -->
        </div><!-- #page-container -->
    </div><!-- #global-container -->
";
        craft\helpers\Template::endProfile("block", "body");
    }

    // line 158
    public function block_mainFormAttributes($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "mainFormAttributes");
        echo craft\helpers\Html::renderTagAttributes((isset($context["mainFormAttributes"]) || array_key_exists("mainFormAttributes", $context) ? $context["mainFormAttributes"] : (function () { throw new RuntimeError('Variable "mainFormAttributes" does not exist.', 158, $this->source); })()));
        craft\helpers\Template::endProfile("block", "mainFormAttributes");
    }

    // line 165
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "header");
        // line 166
        echo "                                    <div id=\"page-title\" class=\"flex flex-nowrap";
        if ((isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 166, $this->source); })())) {
            echo " has-toolbar";
        }
        echo "\">
                                        ";
        // line 167
        $this->displayBlock('pageTitle', $context, $blocks);
        // line 172
        echo "                                        ";
        $this->displayBlock('contextMenu', $context, $blocks);
        // line 173
        echo "                                    </div>
                                    ";
        // line 174
        if ((isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 174, $this->source); })())) {
            // line 175
            echo "                                        <div id=\"toolbar\" class=\"flex flex-nowrap\">
                                            ";
            // line 176
            echo (isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 176, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 179
        echo "                                    ";
        if ((isset($context["actionButton"]) || array_key_exists("actionButton", $context) ? $context["actionButton"] : (function () { throw new RuntimeError('Variable "actionButton" does not exist.', 179, $this->source); })())) {
            // line 180
            echo "                                        <div id=\"action-button\" class=\"flex\">
                                            ";
            // line 181
            echo (isset($context["actionButton"]) || array_key_exists("actionButton", $context) ? $context["actionButton"] : (function () { throw new RuntimeError('Variable "actionButton" does not exist.', 181, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 184
        echo "                                ";
        craft\helpers\Template::endProfile("block", "header");
    }

    // line 167
    public function block_pageTitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "pageTitle");
        // line 168
        echo "                                            ";
        if (((isset($context["title"]) || array_key_exists("title", $context)) && twig_length_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 168, $this->source); })())))) {
            // line 169
            echo "                                                <h1 title=\"";
            echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 169, $this->source); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 169, $this->source); })()), "html", null, true);
            echo "</h1>
                                            ";
        }
        // line 171
        echo "                                        ";
        craft\helpers\Template::endProfile("block", "pageTitle");
    }

    // line 172
    public function block_contextMenu($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "contextMenu");
        craft\helpers\Template::endProfile("block", "contextMenu");
    }

    // line 204
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 205
        echo "                                ";
        $this->displayBlock('tabs', $context, $blocks);
        // line 210
        echo "
                                <div id=\"content\" class=\"content-pane\">
                                    ";
        // line 212
        $this->displayBlock('content', $context, $blocks);
        // line 215
        echo "
                                    ";
        // line 217
        echo "                                    ";
        if ((isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 217, $this->source); })())) {
            // line 218
            echo "                                        <div id=\"footer\" class=\"flex\">
                                            ";
            // line 219
            echo (isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 219, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 222
        echo "                                </div>
                            ";
        craft\helpers\Template::endProfile("block", "main");
    }

    // line 205
    public function block_tabs($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "tabs");
        // line 206
        echo "                                    ";
        if ((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 206, $this->source); })())) {
            // line 207
            echo "                                        ";
            $this->loadTemplate("_includes/tabs", "_layouts/cp", 207)->display($context);
            // line 208
            echo "                                    ";
        }
        // line 209
        echo "                                ";
        craft\helpers\Template::endProfile("block", "tabs");
    }

    // line 212
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 213
        echo "                                        ";
        (((isset($context["content"]) || array_key_exists("content", $context))) ? (print (twig_escape_filter($this->env, (isset($context["content"]) || array_key_exists("content", $context) ? $context["content"] : (function () { throw new RuntimeError('Variable "content" does not exist.', 213, $this->source); })()), "html", null, true))) : (print ("")));
        echo "
                                    ";
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 245
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 246
        echo "    ";
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 246, $this->source); })())) {
            // line 247
            echo "        <div class=\"btngroup\">
            ";
            // line 248
            $this->displayBlock('submitButton', $context, $blocks);
            // line 251
            echo "            ";
            if ((($context["formActions"]) ?? (false))) {
                // line 252
                echo "                <button type=\"button\" class=\"btn submit menubtn\"></button>
                ";
                // line 253
                $this->loadTemplate("_layouts/components/form-action-menu", "_layouts/cp", 253)->display($context);
                // line 254
                echo "            ";
            }
            // line 255
            echo "        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 248
    public function block_submitButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "submitButton");
        // line 249
        echo "                <button type=\"submit\" class=\"btn submit\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
        echo "</button>
            ";
        craft\helpers\Template::endProfile("block", "submitButton");
    }

    public function getTemplateName()
    {
        return "_layouts/cp";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  535 => 249,  530 => 248,  523 => 255,  520 => 254,  518 => 253,  515 => 252,  512 => 251,  510 => 248,  507 => 247,  504 => 246,  499 => 245,  491 => 213,  486 => 212,  481 => 209,  478 => 208,  475 => 207,  472 => 206,  467 => 205,  461 => 222,  455 => 219,  452 => 218,  449 => 217,  446 => 215,  444 => 212,  440 => 210,  437 => 205,  432 => 204,  424 => 172,  419 => 171,  411 => 169,  408 => 168,  403 => 167,  398 => 184,  392 => 181,  389 => 180,  386 => 179,  380 => 176,  377 => 175,  375 => 174,  372 => 173,  369 => 172,  367 => 167,  360 => 166,  355 => 165,  346 => 158,  337 => 238,  334 => 236,  332 => 235,  328 => 233,  321 => 229,  317 => 227,  315 => 226,  311 => 224,  309 => 204,  306 => 203,  303 => 201,  296 => 197,  289 => 192,  286 => 191,  282 => 189,  279 => 188,  274 => 185,  272 => 165,  268 => 163,  266 => 162,  263 => 161,  260 => 159,  256 => 158,  254 => 157,  249 => 155,  237 => 148,  229 => 142,  223 => 140,  221 => 139,  217 => 138,  214 => 137,  208 => 135,  206 => 134,  202 => 133,  194 => 128,  188 => 127,  185 => 126,  183 => 125,  178 => 122,  175 => 121,  173 => 120,  169 => 118,  167 => 117,  164 => 116,  159 => 115,  153 => 40,  148 => 262,  146 => 261,  144 => 260,  139 => 111,  137 => 110,  136 => 109,  135 => 105,  132 => 104,  130 => 103,  128 => 101,  127 => 99,  126 => 97,  125 => 96,  124 => 95,  123 => 94,  122 => 88,  120 => 86,  119 => 83,  116 => 80,  114 => 79,  112 => 78,  110 => 75,  109 => 74,  108 => 73,  107 => 72,  105 => 70,  103 => 69,  101 => 68,  99 => 67,  97 => 66,  95 => 65,  93 => 64,  91 => 62,  89 => 61,  87 => 60,  85 => 58,  83 => 57,  78 => 53,  75 => 52,  71 => 50,  69 => 49,  66 => 48,  64 => 47,  59 => 46,  56 => 45,  54 => 44,  52 => 43,  44 => 40,);
    }

    public function getSourceContext()
    {
        return new Source("{#
┌────────────────────────────────────────────────────────────────────────────────────┐
│                                 #global-container                                  │
│   ┌─────┐   ┌──────────────────────────────────────────────────────────────────┐   │
│   │     │   │                         #page-container                          │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-header                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │                                                                  │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                          #main                           │   │   │
│   │  #  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  g  │   │   │   │                #header-container                 │   │   │   │
│   │  l  │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │  o  │   │   │                                                          │   │   │
│   │  b  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  a  │   │   │   │                  #main-content                   │   │   │   │
│   │  l  │   │   │   │   ┌─────┐   ┌──────────────────────┐   ┌─────┐   │   │   │   │
│   │  -  │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │  s  │   │   │   │   │  #  │   │                      │   │  #  │   │   │   │   │
│   │  i  │   │   │   │   │  s  │   │                      │   │  d  │   │   │   │   │
│   │  d  │   │   │   │   │  i  │   │                      │   │  e  │   │   │   │   │
│   │  e  │   │   │   │   │  d  │   │       #content       │   │  t  │   │   │   │   │
│   │  b  │   │   │   │   │  e  │   │                      │   │  a  │   │   │   │   │
│   │  a  │   │   │   │   │  b  │   │                      │   │  i  │   │   │   │   │
│   │  r  │   │   │   │   │  a  │   │                      │   │  l  │   │   │   │   │
│   │     │   │   │   │   │  r  │   │                      │   │  s  │   │   │   │   │
│   │     │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │     │   │   │   │   └─────┘   └──────────────────────┘   └─────┘   │   │   │   │
│   │     │   │   │   │                                                  │   │   │   │
│   │     │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │     │   │   │                                                          │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │                                                                  │   │
│   └─────┘   └──────────────────────────────────────────────────────────────────┘   │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘
#}

{% extends \"_layouts/basecp\" %}

{# The CP only supports queue components that implement QueueInterface #}
{% set queue = craft.app.queue %}
{% js %}
    {% if queue is instance of(\"craft\\\\queue\\\\QueueInterface\") %}
        Craft.cp.setJobInfo({{ queue.getJobInfo(100)|json_encode|raw }}, false);
        {% if queue.getHasReservedJobs() %}
            Craft.cp.trackJobProgress(true);
        {% elseif queue.getHasWaitingJobs() %}
            Craft.cp.runQueue();
        {% endif %}
    {% else %}
        Craft.cp.enableQueue = false;
    {% endif %}
{% endjs %}

{% set hasSystemIcon = CraftEdition == CraftPro and craft.rebrand.isIconUploaded %}
{% set fullPageForm = (fullPageForm is defined and fullPageForm) %}

{% set canUpgradeEdition = craft.app.getCanUpgradeEdition() %}
{% set licensedEdition = craft.app.getLicensedEdition() %}
{% set isTrial = licensedEdition is not same as(null) and licensedEdition is not same as(CraftEdition) %}

{% set sidebar = (sidebar ?? block('sidebar') ?? '')|trim %}
{% set toolbar = (toolbar ?? block('toolbar') ?? '')|trim %}
{% set actionButton = (block('actionButton') ?? '')|trim %}
{% set details = (details ?? block('details') ?? '')|trim %}
{% set footer = (footer ?? block('footer') ?? '')|trim %}
{% set crumbs = crumbs ?? null %}
{% set tabs = tabs is defined and tabs|length != 1 ? tabs : null %}

{% set mainContentClasses = [
    sidebar ? 'has-sidebar',
    details ? 'has-details',
    tabs ? 'has-tabs',
]|filter %}

{% set showHeader = showHeader ?? true %}
{% if not showHeader %}
    {% set bodyClass = (bodyClass ?? [])|explodeClass|push('no-header') -%}
{% endif %}

{% set mainAttributes = {
    id: 'main',
    role: 'main',
}|merge(mainAttributes ?? []) %}

{% set mainFormAttributes = {
    'id': 'main-form',
    'method': 'post',
    'accept-charset': 'UTF-8',
    'novalidate': true,
    'data': {
        'saveshortcut': saveShortcut ?? true,
        'saveshortcut-redirect': (saveShortcutRedirect ?? false) ? saveShortcutRedirect|hash : false,
        'saveshortcut-scroll': retainScrollOnSaveShortcut ?? false,
        'actions': formActions ?? false,
        'confirm-unload': true,
        'delta': view.getIsDeltaRegistrationActive(),
    },
}|merge(mainFormAttributes ?? [], recursive=true) %}

{% set userPhoto %}
    <div class=\"header-photo\">
        {{ tag('img', {
            width: 30,
            height: 30,
            sizes: '30px',
            srcset: \"#{currentUser.getThumbUrl(30)} 30w, #{currentUser.getThumbUrl(60)} 60w\",
            alt: currentUser.getName(),
        }) }}
    </div>
{% endset %}

{% block body %}
    <div id=\"global-container\">
        {% include '_layouts/components/global-sidebar' %}

        <div id=\"page-container\">
            {% include '_layouts/components/alerts' %}
            {% include '_layouts/components/notifications' %}

            <div id=\"global-header\">
                <div class=\"flex\">
                    {% include '_layouts/components/crumbs' %}
                    <div class=\"flex-grow\"></div>
                    <button type=\"button\" id=\"user-info\" class=\"btn menubtn\" aria-label=\"{{ 'My Account'|t('app') }}\" title=\"{{ 'My Account'|t('app') }}\" data-menu-anchor=\".header-photo\">
                        {{ userPhoto }}
                    </button>
                    <div class=\"menu\" data-align=\"right\">
                        <ul>
                            <li>
                                <a href=\"{{ url('myaccount') }}\" class=\"flex flex-nowrap\">
                                    {% if currentUser.photoId %}
                                        {{ userPhoto }}
                                    {% endif %}
                                    <div class=\"flex-grow\">
                                        <div>{{ currentUser.username }}</div>
                                        {% if not craft.app.config.general.useEmailAsUsername %}
                                            <div class=\"light smalltext\">{{ currentUser.email }}</div>
                                        {% endif %}
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <hr>
                        <ul>
                            <li><a href=\"{{ url('logout') }}\">{{ \"Sign out\"|t('app') }}</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">
                <main {{ attr(mainAttributes) }}>

                    {% if fullPageForm -%}
                        <form {% block mainFormAttributes %}{{ attr(mainFormAttributes) }}{% endblock %}>
                            {{- csrfInput() }}
                    {%- endif %}

                    {% if showHeader %}
                        <div id=\"header-container\">
                            <header id=\"header\">
                                {% block header %}
                                    <div id=\"page-title\" class=\"flex flex-nowrap{% if toolbar %} has-toolbar{% endif %}\">
                                        {% block pageTitle %}
                                            {% if title is defined and title|length %}
                                                <h1 title=\"{{ title }}\">{{ title }}</h1>
                                            {% endif %}
                                        {% endblock %}
                                        {% block contextMenu %}{% endblock %}
                                    </div>
                                    {% if toolbar %}
                                        <div id=\"toolbar\" class=\"flex flex-nowrap\">
                                            {{ toolbar|raw }}
                                        </div>
                                    {% endif %}
                                    {% if actionButton %}
                                        <div id=\"action-button\" class=\"flex\">
                                            {{ actionButton|raw }}
                                        </div>
                                    {% endif %}
                                {% endblock %}
                            </header><!-- #header -->
                        </div>
                    {% endif %}

                    <div id=\"main-content\" class=\"{{ mainContentClasses|join(' ') }}\">
                        {# sidebar #}
                        {% if sidebar %}
                            <div id=\"sidebar-toggle-container\">
                                <button type=\"button\" id=\"sidebar-toggle\" class=\"btn menubtn\"><span id=\"selected-sidebar-item-label\"></span></button>
                            </div>
                            <div id=\"sidebar-container\">
                                <div id=\"sidebar\" class=\"sidebar\">
                                    {{ sidebar|raw }}
                                </div>
                            </div>
                        {% endif %}

                        {# content-container #}
                        <div id=\"content-container\">
                            {% block main %}
                                {% block tabs %}
                                    {% if tabs %}
                                        {% include \"_includes/tabs\" %}
                                    {% endif %}
                                {% endblock %}

                                <div id=\"content\" class=\"content-pane\">
                                    {% block content %}
                                        {{ content is defined ? content }}
                                    {% endblock %}

                                    {# footer #}
                                    {% if footer %}
                                        <div id=\"footer\" class=\"flex\">
                                            {{ footer|raw }}
                                        </div>
                                    {% endif %}
                                </div>
                            {% endblock %}
                        </div><!-- #content-container -->

                        {% if details is not empty %}
                            <div id=\"details-container\">
                                <div id=\"details\">
                                    {{ details|raw }}
                                </div>
                            </div>
                        {% endif %}
                    </div><!-- #main-content -->

                    {% if fullPageForm -%}
                        </form><!-- #main-form -->
                    {%- endif %}
                </main><!-- #main -->
            </div><!-- #main-container -->
        </div><!-- #page-container -->
    </div><!-- #global-container -->
{% endblock %}


{% block actionButton %}
    {% if fullPageForm %}
        <div class=\"btngroup\">
            {% block submitButton %}
                <button type=\"submit\" class=\"btn submit\">{{ 'Save'|t('app') }}</button>
            {% endblock %}
            {% if formActions ?? false %}
                <button type=\"button\" class=\"btn submit menubtn\"></button>
                {% include '_layouts/components/form-action-menu' %}
            {% endif %}
        </div>
    {% endif %}
{% endblock %}


{% if currentUser.can('performUpdates') and not craft.app.updates.getIsUpdateInfoCached() %}
    {% js %}
        Craft.cp.checkForUpdates();
    {% endjs %}
{% endif %}
", "_layouts/cp", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_layouts/cp.html");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/sources */
class __TwigTemplate_f3772e1434706f7d81a2965c5f13d76a2894decb21539842b23d679c0c55113f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/sources");
        // line 1
        ob_start();
        // line 2
        $context["keyPrefix"] = (($context["keyPrefix"]) ?? (""));
        // line 3
        echo "
";
        // line 25
        echo "
";
        // line 43
        echo "
";
        // line 44
        $macros["__internal_f25ee555dea796671deb9cc91d343fe166330f2459170bc01a3cc2247ec88b36"] = $this->macros["__internal_f25ee555dea796671deb9cc91d343fe166330f2459170bc01a3cc2247ec88b36"] = $this;
        // line 45
        echo "
<ul>
    ";
        // line 47
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 47, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["source"]) {
            // line 48
            echo "        ";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", [], "any", true, true)) {
                // line 49
                echo "            <li class=\"heading\"><span>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", []), "site"), "html", null, true);
                echo "</span></li>
        ";
            } else {
                // line 51
                echo "            ";
                $context["key"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [])) : (((isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 51, $this->source); })()) . craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "key", []))));
                // line 52
                echo "            <li>
                ";
                // line 53
                echo twig_call_macro($macros["__internal_f25ee555dea796671deb9cc91d343fe166330f2459170bc01a3cc2247ec88b36"], "macro_sourceLink", [(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 53, $this->source); })()), $context["source"],  !(isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 53, $this->source); })()), (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 53, $this->source); })())], 53, $context, $this->getSourceContext());
                echo "
                ";
                // line 54
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", true, true) &&  !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [])))) {
                    // line 55
                    echo "                    <div class=\"toggle\"></div>
                    ";
                    // line 56
                    $this->loadTemplate("_elements/sources", "_elements/sources", 56)->display(twig_array_merge($context, ["keyPrefix" => (                    // line 57
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 57, $this->source); })()) . "/"), "sources" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 58
$context["source"], "nested", [])]));
                    // line 60
                    echo "                ";
                }
                // line 61
                echo "            </li>
        ";
            }
            // line 63
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['source'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 64
        echo "</ul>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        craft\helpers\Template::endProfile("template", "_elements/sources");
    }

    // line 4
    public function macro_sourceLink($__key__ = null, $__source__ = null, $__isTopLevel__ = null, $__elementType__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "key" => $__key__,
            "source" => $__source__,
            "isTopLevel" => $__isTopLevel__,
            "elementType" => $__elementType__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "sourceLink");
            // line 5
            echo "    ";
            $macros["__internal_08824086fd9f53d0427b52e4625227d6d7fef12bece28bde3951eba9891d60e1"] = $this;
            // line 6
            echo "    ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["data" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["key" =>             // line 8
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 8, $this->source); })()), "has-thumbs" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 9
($context["source"] ?? null), "hasThumbs", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "hasThumbs", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "hasThumbs", [])) : (false))) ? (true) : (false)), "has-structure" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 10
($context["source"] ?? null), "structureId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "structureId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "structureId", [])) : (false))) ? (true) : (false)), "default-sort" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 11
($context["source"] ?? null), "defaultSort", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSort", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSort", [])) : (false))) ? (((twig_test_iterable(craft\helpers\Template::attribute($this->env, $this->source,             // line 12
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 12, $this->source); })()), "defaultSort", []))) ? (twig_join_filter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 12, $this->source); })()), "defaultSort", []), ":")) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 12, $this->source); })()), "defaultSort", [])))) : (false)), "sort-options" => ((            // line 14
(isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 14, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(twig_array_map(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 15
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 15, $this->source); })()), "app", []), "elementIndexes", []), "getSourceSortOptions", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 15, $this->source); })()), 1 => (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 15, $this->source); })())], "method"),             // line 16
function ($__o__) use ($context, $macros) { $context["o"] = $__o__; return [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 16, $this->source); })()), "label", []), 1 => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["o"] ?? null), "attribute", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["o"] ?? null), "attribute", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["o"] ?? null), "attribute", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 16, $this->source); })()), "orderBy", [])))]; }))) : (false)), "sites" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 19
($context["source"] ?? null), "sites", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "sites", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "sites", [])) : (false))) ? (twig_join_filter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 19, $this->source); })()), "sites", []), ",")) : (false)), "override-status" => (((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 20
($context["source"] ?? null), "criteria", [], "any", false, true), "status", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "criteria", [], "any", false, true), "status", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "criteria", [], "any", false, true), "status", [])) : (false))) ? (true) : (false))], (((craft\helpers\Template::attribute($this->env, $this->source,             // line 21
($context["source"] ?? null), "data", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "data", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "data", [])) : ([]))), "html" => twig_call_macro($macros["__internal_08824086fd9f53d0427b52e4625227d6d7fef12bece28bde3951eba9891d60e1"], "macro_sourceInnerHtml", [            // line 22
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 22, $this->source); })())], 22, $context, $this->getSourceContext())]);
            // line 23
            echo "
";
            craft\helpers\Template::endProfile("macro", "sourceLink");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 26
    public function macro_sourceInnerHtml($__source__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "source" => $__source__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "sourceInnerHtml");
            // line 27
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "status", [], "any", true, true)) {
                // line 28
                echo "        <span class=\"status ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 28, $this->source); })()), "status", []), "html", null, true);
                echo "\"></span>
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 29
($context["source"] ?? null), "icon", [], "any", true, true)) {
                // line 30
                echo "        <span class=\"icon\">
            ";
                // line 31
                echo (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 31, $this->source); })()), "icon", []), true, true)) ? ($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 31, $this->source); })()), "icon", []), true, true)) : ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 31, $this->source); })()), "icon", [])) . "'></span>")));
                echo "
        </span>
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 33
($context["source"] ?? null), "iconMask", [], "any", true, true)) {
                // line 34
                echo "        <span class=\"icon icon-mask\">
            ";
                // line 35
                echo (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 35, $this->source); })()), "iconMask", []), true, true)) ? ($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 35, $this->source); })()), "iconMask", []), true, true)) : ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 35, $this->source); })()), "iconMask", [])) . "'></span>")));
                echo "
        </span>
    ";
            }
            // line 38
            echo "    <span class=\"label\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 38, $this->source); })()), "label", []), "html", null, true);
            echo "</span>
    ";
            // line 39
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "badgeCount", [], "any", true, true)) {
                // line 40
                echo "        <span class=\"badge\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('number')->getCallable(), [craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 40, $this->source); })()), "badgeCount", []), 0]), "html", null, true);
                echo "</span>
    ";
            }
            craft\helpers\Template::endProfile("macro", "sourceInnerHtml");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_elements/sources";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 40,  224 => 39,  219 => 38,  213 => 35,  210 => 34,  208 => 33,  203 => 31,  200 => 30,  198 => 29,  193 => 28,  190 => 27,  176 => 26,  165 => 23,  163 => 22,  162 => 21,  161 => 20,  160 => 19,  159 => 16,  158 => 15,  157 => 14,  156 => 12,  155 => 11,  154 => 10,  153 => 9,  152 => 8,  150 => 6,  147 => 5,  130 => 4,  123 => 64,  109 => 63,  105 => 61,  102 => 60,  100 => 58,  99 => 57,  98 => 56,  95 => 55,  93 => 54,  89 => 53,  86 => 52,  83 => 51,  77 => 49,  74 => 48,  57 => 47,  53 => 45,  51 => 44,  48 => 43,  45 => 25,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% spaceless %}
{% set keyPrefix = keyPrefix ?? '' %}

{% macro sourceLink(key, source, isTopLevel, elementType) %}
    {% from _self import sourceInnerHtml %}
    {{ tag('a', {
        data: {
            key: key,
            'has-thumbs': (source.hasThumbs ?? false) ? true : false,
            'has-structure': (source.structureId ?? false) ? true : false,
            'default-sort': (source.defaultSort ?? false)
                ? (source.defaultSort is iterable ? source.defaultSort|join(':') : source.defaultSort)
                : false,
            'sort-options': isTopLevel
                ? craft.app.elementIndexes.getSourceSortOptions(elementType, key)
                    |map(o => [o.label, o.attribute ?? o.orderBy])
                    |json_encode
                : false,
            sites: (source.sites ?? false) ? source.sites|join(',') : false,
            'override-status': (source.criteria.status ?? false) ? true : false,
        }|merge(source.data ?? {}),
        html: sourceInnerHtml(source)
    }) }}
{% endmacro %}

{% macro sourceInnerHtml(source) %}
    {% if source.status is defined %}
        <span class=\"status {{ source.status }}\"></span>
    {% elseif source.icon is defined %}
        <span class=\"icon\">
            {{ (svg(source.icon, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.icon}'></span>\")|raw }}
        </span>
    {% elseif source.iconMask is defined %}
        <span class=\"icon icon-mask\">
            {{ (svg(source.iconMask, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.iconMask}'></span>\")|raw }}
        </span>
    {% endif %}
    <span class=\"label\">{{ source.label }}</span>
    {% if source.badgeCount is defined %}
        <span class=\"badge\">{{ source.badgeCount|number(decimals=0) }}</span>
    {% endif %}
{% endmacro %}

{% from _self import sourceLink %}

<ul>
    {% for source in sources %}
        {% if source.heading is defined %}
            <li class=\"heading\"><span>{{ source.heading|t('site') }}</span></li>
        {% else %}
            {% set key = source.keyPath ?? (keyPrefix ~ source.key) %}
            <li>
                {{ sourceLink(key, source, not keyPrefix, elementType) }}
                {% if source.nested is defined and source.nested is not empty %}
                    <div class=\"toggle\"></div>
                    {% include \"_elements/sources\" with {
                        keyPrefix: key ~ '/',
                        sources: source.nested
                    } %}
                {% endif %}
            </li>
        {% endif %}
    {% endfor %}
</ul>
{% endspaceless %}
", "_elements/sources", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_elements/sources.html");
    }
}

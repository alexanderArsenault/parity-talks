<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sections/_entrytypes/edit */
class __TwigTemplate_ae3b04907f9196a7ddbae9573b19ef946803c8e3292db26fba78fbb4b689969e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/sections/_entrytypes/edit");
        // line 2
        $context["fullPageForm"] = true;
        // line 4
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/sections/_entrytypes/edit", 4)->unwrap();
        // line 110
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 110, $this->source); })()), "handle", [])) {
            // line 111
            craft\helpers\Template::js("new Craft.HandleGenerator('#name', '#handle');", ['position' => 3]);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sections/_entrytypes/edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/sections/_entrytypes/edit");
    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 8
        echo "    ";
        echo craft\helpers\Html::actionInput("sections/save-entry-type");
        echo "

    ";
        // line 10
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 10, $this->source); })()), "type", []) == "single")) {
            // line 11
            echo "        ";
            echo craft\helpers\Html::redirectInput("settings/sections");
            echo "
    ";
        } else {
            // line 13
            echo "        ";
            echo craft\helpers\Html::redirectInput((("settings/sections/" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 13, $this->source); })()), "id", [])) . "/entrytypes"));
            echo "
    ";
        }
        // line 15
        echo "    ";
        echo craft\helpers\Html::hiddenInput("sectionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 15, $this->source); })()), "id", []));
        echo "
    ";
        // line 16
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 16, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("entryTypeId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 16, $this->source); })()), "id", []));
        }
        // line 17
        echo "
    ";
        // line 18
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 18, $this->source); })()), "type", []) != "single")) {
            // line 19
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this entry type will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 25
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 25, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 26
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 26, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 19, $context, $this->getSourceContext());
            // line 29
            echo "

        ";
            // line 31
            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this entry type in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 39
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 39, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 40
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 40, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 31, $context, $this->getSourceContext());
            // line 42
            echo "

        <hr>

    ";
        }
        // line 47
        echo "
    ";
        // line 48
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["first" => (craft\helpers\Template::attribute($this->env, $this->source,         // line 49
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 49, $this->source); })()), "type", []) == "single"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show the Title field", "app"), "name" => "hasTitleField", "toggle" => "title-container", "reverseToggle" => "#titleFormat-container, .fld-title-field-icon", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 54, $this->source); })()), "hasTitleField", [])]], 48, $context, $this->getSourceContext());
        // line 55
        echo "

    ";
        // line 57
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 57, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 58
            echo "        <div id=\"title-container\"";
            if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 58, $this->source); })()), "hasTitleField", [])) {
                echo " class=\"hidden\"";
            }
            echo ">
            ";
            // line 59
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title Translation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How should entry titles be translated?", "app"), "id" => "translation-method", "name" => "titleTranslationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")], 1 => ["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")], 2 => ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")], 3 => ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")], 4 => ["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]]), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 71
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 71, $this->source); })()), "titleTranslationMethod", []), "toggle" => true, "targetPrefix" => "translation-method-"]], 59, $context, $this->getSourceContext());
            // line 74
            echo "

            <div id=\"translation-method-custom\" ";
            // line 76
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 76, $this->source); })()), "titleTranslationMethod", []) != "custom")) {
                echo "class=\"hidden\"";
            }
            echo ">
                ";
            // line 77
            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title Translation Key Format", "app"), "instructions" => "Template that defines the Title field’s custom “translation key” format. Entry titles will be copied to all sites that produce the same key. For example, to make titles translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.", "id" => "translation-key-format", "name" => "titleTranslationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 82
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 82, $this->source); })()), "titleTranslationKeyFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 83
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 83, $this->source); })()), "getErrors", [0 => "titleTranslationKeyFormat"], "method")]], 77, $context, $this->getSourceContext());
            // line 84
            echo "
            </div>
        </div>
    ";
        }
        // line 88
        echo "
    <div id=\"titleFormat-container\"";
        // line 89
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 89, $this->source); })()), "hasTitleField", [])) {
            echo " class=\"hidden\"";
        }
        echo ">
        ";
        // line 90
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title Format", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What the auto-generated entry titles should look like. You can include tags that output entry properties, such as {ex}.", "app", ["ex" => "<code>{myCustomField}</code>"]), "id" => "titleFormat", "name" => "titleFormat", "class" => "code", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 96
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 96, $this->source); })()), "titleFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 97
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 97, $this->source); })()), "getErrors", [0 => "titleFormat"], "method"), "required" => true]], 90, $context, $this->getSourceContext());
        // line 99
        echo "
    </div>

    <hr>

    ";
        // line 104
        echo twig_call_macro($macros["forms"], "macro_fieldLayoutDesignerField", [["fieldLayout" => craft\helpers\Template::attribute($this->env, $this->source,         // line 105
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 105, $this->source); })()), "getFieldLayout", [], "method")]], 104, $context, $this->getSourceContext());
        // line 106
        echo "
";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/sections/_entrytypes/edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  183 => 106,  181 => 105,  180 => 104,  173 => 99,  171 => 97,  170 => 96,  169 => 90,  163 => 89,  160 => 88,  154 => 84,  152 => 83,  151 => 82,  150 => 77,  144 => 76,  140 => 74,  138 => 71,  137 => 59,  130 => 58,  128 => 57,  124 => 55,  122 => 54,  121 => 49,  120 => 48,  117 => 47,  110 => 42,  108 => 40,  107 => 39,  106 => 31,  102 => 29,  100 => 26,  99 => 25,  97 => 19,  95 => 18,  92 => 17,  88 => 16,  83 => 15,  77 => 13,  71 => 11,  69 => 10,  63 => 8,  58 => 7,  52 => 1,  49 => 111,  47 => 110,  45 => 4,  43 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
    {{ actionInput('sections/save-entry-type') }}

    {% if section.type == 'single' %}
        {{ redirectInput('settings/sections') }}
    {% else %}
        {{ redirectInput('settings/sections/'~section.id~'/entrytypes') }}
    {% endif %}
    {{ hiddenInput('sectionId', section.id) }}
    {% if entryType.id %}{{ hiddenInput('entryTypeId', entryType.id) }}{% endif %}

    {% if section.type != 'single' %}
        {{ forms.textField({
            first: true,
            label: \"Name\"|t('app'),
            instructions: \"What this entry type will be called in the control panel.\"|t('app'),
            id: 'name',
            name: 'name',
            value: entryType.name,
            errors: entryType.getErrors('name'),
            autofocus: true,
            required: true
        }) }}

        {{ forms.textField({
            label: \"Handle\"|t('app'),
            instructions: \"How you’ll refer to this entry type in the templates.\"|t('app'),
            id: 'handle',
            name: 'handle',
            class: 'code',
            autocorrect: false,
            autocapitalize: false,
            value: entryType.handle,
            errors: entryType.getErrors('handle'),
            required: true
        }) }}

        <hr>

    {% endif %}

    {{ forms.checkboxField({
        first: (section.type == 'single'),
        label: \"Show the Title field\"|t('app'),
        name: 'hasTitleField',
        toggle: 'title-container',
        reverseToggle: '#titleFormat-container, .fld-title-field-icon',
        checked: entryType.hasTitleField
    }) }}

    {% if craft.app.getIsMultiSite() %}
        <div id=\"title-container\"{% if not entryType.hasTitleField %} class=\"hidden\"{% endif %}>
            {{ forms.selectField({
                label: 'Title Translation Method'|t('app'),
                instructions: 'How should entry titles be translated?'|t('app'),
                id: 'translation-method',
                name: 'titleTranslationMethod',
                options: [
                    { value: 'none', label: 'Not translatable'|t('app') },
                    { value: 'site', label: 'Translate for each site'|t('app') },
                    { value: 'siteGroup', label: 'Translate for each site group'|t('app') },
                    { value: 'language', label: 'Translate for each language'|t('app') },
                    { value: 'custom', label: 'Custom…'|t('app') },
                ]|filter,
                value: entryType.titleTranslationMethod,
                toggle: true,
                targetPrefix: 'translation-method-'
            }) }}

            <div id=\"translation-method-custom\" {% if entryType.titleTranslationMethod != 'custom' %}class=\"hidden\"{% endif %}>
                {{ forms.textField({
                    label: 'Title Translation Key Format'|t('app'),
                    instructions: 'Template that defines the Title field’s custom “translation key” format. Entry titles will be copied to all sites that produce the same key. For example, to make titles translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.',
                    id: 'translation-key-format',
                    name: 'titleTranslationKeyFormat',
                    value: entryType.titleTranslationKeyFormat,
                    errors: entryType.getErrors('titleTranslationKeyFormat')
                }) }}
            </div>
        </div>
    {% endif %}

    <div id=\"titleFormat-container\"{% if entryType.hasTitleField %} class=\"hidden\"{% endif %}>
        {{ forms.textField({
            label: \"Title Format\"|t('app'),
            instructions: \"What the auto-generated entry titles should look like. You can include tags that output entry properties, such as {ex}.\"|t('app', { ex: '<code>{myCustomField}</code>' }),
            id: 'titleFormat',
            name: 'titleFormat',
            class: 'code',
            value: entryType.titleFormat,
            errors: entryType.getErrors('titleFormat'),
            required: true
        }) }}
    </div>

    <hr>

    {{ forms.fieldLayoutDesignerField({
        fieldLayout: entryType.getFieldLayout(),
    }) }}
{% endblock %}


{% if not entryType.handle %}
    {% js \"new Craft.HandleGenerator('#name', '#handle');\" %}
{% endif %}
", "settings/sections/_entrytypes/edit", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/settings/sections/_entrytypes/edit.html");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/tabs */
class __TwigTemplate_65742cf40ac9e96ccf969013b56faff3ae49b4d8496218334323c1d526d44867 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/tabs");
        // line 1
        echo "<nav id=\"tabs\">
    <ul>
        ";
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, (isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 3, $this->source); })())));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["tabId"] => $context["tab"]) {
            // line 4
            echo "            ";
            $context["tabIsSelected"] = (( !(isset($context["selectedTab"]) || array_key_exists("selectedTab", $context)) && craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) || ((isset($context["selectedTab"]) || array_key_exists("selectedTab", $context)) && ((isset($context["selectedTab"]) || array_key_exists("selectedTab", $context) ? $context["selectedTab"] : (function () { throw new RuntimeError('Variable "selectedTab" does not exist.', 4, $this->source); })()) == $context["tabId"])));
            // line 5
            $context["class"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "class", [])) : (""));
            // line 6
            echo "<li data-id=\"";
            echo twig_escape_filter($this->env, $context["tabId"], "html", null, true);
            echo "\">
                ";
            // line 7
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["id" => ("tab-" .             // line 8
$context["tabId"]), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "tab", 1 => ((            // line 9
(isset($context["tabIsSelected"]) || array_key_exists("tabIsSelected", $context) ? $context["tabIsSelected"] : (function () { throw new RuntimeError('Variable "tabIsSelected" does not exist.', 9, $this->source); })())) ? ("sel") : ("")), 2 => (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 9, $this->source); })())]), "href" => craft\helpers\Template::attribute($this->env, $this->source,             // line 10
$context["tab"], "url", []), "title" => craft\helpers\Template::attribute($this->env, $this->source,             // line 11
$context["tab"], "label", []), "html" => (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source,             // line 12
$context["tab"], "label", [])) . ((((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 12, $this->source); })()) == "error")) ? (" <span data-icon=\"alert\"></span>") : ("")))]);
            // line 13
            echo "
            </li>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['tabId'], $context['tab'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "    </ul>
    <button type=\"button\" id=\"overflow-tab-btn\" data-icon=\"ellipsis\" class=\"btn menubtn hidden\"></button>
    <div id=\"overflow-tab-menu\" class=\"menu\">
        <ul role=\"listbox\"></ul>
    </div>
</nav>
";
        craft\helpers\Template::endProfile("template", "_includes/tabs");
    }

    public function getTemplateName()
    {
        return "_includes/tabs";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 16,  76 => 13,  74 => 12,  73 => 11,  72 => 10,  71 => 9,  70 => 8,  69 => 7,  64 => 6,  62 => 5,  59 => 4,  42 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav id=\"tabs\">
    <ul>
        {% for tabId, tab in tabs|filter %}
            {% set tabIsSelected = ((selectedTab is not defined and loop.first) or (selectedTab is defined and selectedTab == tabId)) -%}
            {% set class = tab.class ?? '' -%}
            <li data-id=\"{{ tabId }}\">
                {{ tag('a', {
                    id: \"tab-#{tabId}\",
                    class: ['tab', tabIsSelected ? 'sel', class]|filter,
                    href: tab.url,
                    title: tab.label,
                    html: tab.label|e ~ (class == 'error' ? ' <span data-icon=\"alert\"></span>'),
                }) }}
            </li>
        {% endfor %}
    </ul>
    <button type=\"button\" id=\"overflow-tab-btn\" data-icon=\"ellipsis\" class=\"btn menubtn hidden\"></button>
    <div id=\"overflow-tab-menu\" class=\"menu\">
        <ul role=\"listbox\"></ul>
    </div>
</nav>
", "_includes/tabs", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/tabs.html");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/element */
class __TwigTemplate_a7b279a14eb3c1cb0de1a1928b812d39ae688ab4887639e9f08995f865b86f5a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/element");
        // line 1
        echo \Craft::$app->getView()->invokeHook("cp.elements.element", $context);

        craft\helpers\Template::endProfile("template", "_elements/element");
    }

    public function getTemplateName()
    {
        return "_elements/element";
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% hook \"cp.elements.element\" %}
", "_elements/element", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_elements/element.html");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/radioGroup */
class __TwigTemplate_5dba6609c7e2d4b7f98d65082dd874cfcf2c155131752c703ba2a867a14b4c27 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/radioGroup");
        // line 1
        $context["options"] = (((isset($context["options"]) || array_key_exists("options", $context))) ? ((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 1, $this->source); })())) : ([]));
        // line 2
        $context["value"] = (((isset($context["value"]) || array_key_exists("value", $context))) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 2, $this->source); })())) : (null));
        // line 4
        $context["class"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "radio-group", 1 => ((((        // line 6
$context["toggle"]) ?? (false))) ? ("fieldtoggle") : ("")), 2 => ((((        // line 7
$context["disabled"]) ?? (false))) ? ("disabled") : (""))]));
        // line 10
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 11
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 11, $this->source); })()), "data" => ["target-prefix" => ((        // line 13
$context["targetPrefix"]) ?? (false))]], ((        // line 15
$context["containerAttributes"]) ?? ([])), true);
        // line 17
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 18
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 18, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 20
        echo "
<fieldset ";
        // line 21
        echo craft\helpers\Html::renderTagAttributes((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 21, $this->source); })()));
        echo ">";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 22, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["option"]) {
            // line 23
            if ( !twig_test_iterable($context["option"])) {
                // line 24
                $context["option"] = ["label" => $context["option"], "value" => $context["key"]];
            }
            // line 26
            echo "        <div>
            ";
            // line 27
            $this->loadTemplate("_includes/forms/radio", "_includes/forms/radioGroup", 27)->display(twig_to_array($this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => (((            // line 28
(isset($context["id"]) || array_key_exists("id", $context)) && craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", []))) ? ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 28, $this->source); })())) : (null)), "name" => ((            // line 29
(isset($context["name"]) || array_key_exists("name", $context))) ? ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 29, $this->source); })())) : (null)), "checked" => (craft\helpers\Template::attribute($this->env, $this->source,             // line 30
$context["option"], "value", [], "any", true, true) && (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", []) == (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 30, $this->source); })()))), "autofocus" => (((            // line 31
(isset($context["autofocus"]) || array_key_exists("autofocus", $context)) && (isset($context["autofocus"]) || array_key_exists("autofocus", $context) ? $context["autofocus"] : (function () { throw new RuntimeError('Variable "autofocus" does not exist.', 31, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 31, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method"))],             // line 32
$context["option"])));
            // line 33
            echo "        </div>
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "</fieldset>
";
        craft\helpers\Template::endProfile("template", "_includes/forms/radioGroup");
    }

    public function getTemplateName()
    {
        return "_includes/forms/radioGroup";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 35,  94 => 33,  92 => 32,  91 => 31,  90 => 30,  89 => 29,  88 => 28,  87 => 27,  84 => 26,  81 => 24,  79 => 23,  62 => 22,  59 => 21,  56 => 20,  53 => 18,  51 => 17,  49 => 15,  48 => 13,  47 => 11,  46 => 10,  44 => 7,  43 => 6,  42 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set options = (options is defined ? options : []) %}
{%- set value = (value is defined ? value : null) %}

{%- set class = (class ?? [])|explodeClass|merge([
    'radio-group',
    (toggle ?? false) ? 'fieldtoggle',
    (disabled ?? false) ? 'disabled',
]|filter) %}

{%- set containerAttributes = {
    class: class,
    data: {
        'target-prefix': targetPrefix ?? false,
    },
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

<fieldset {{ attr(containerAttributes) }}>
    {%- for key, option in options %}
        {%- if option is not iterable %}
            {%- set option = {label: option, value: key} %}
        {%- endif %}
        <div>
            {% include \"_includes/forms/radio\" with {
                id:        (id is defined and loop.first ? id : null),
                name:      (name is defined ? name : null),
                checked:   (option.value is defined and option.value == value),
                autofocus: (autofocus is defined and autofocus and loop.first and not craft.app.request.isMobileBrowser(true))
            }|merge(option) only %}
        </div>
    {% endfor %}
</fieldset>
", "_includes/forms/radioGroup", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/forms/radioGroup.html");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sections/_edit */
class __TwigTemplate_bc29f373a61c4673c2faf75ecbf0d5f7472da31bea87c721891ab28535f2c450 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'submitButton' => [$this, 'block_submitButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "settings/sections/_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/sections/_edit");
        // line 2
        $context["selectedTab"] = "settings";
        // line 3
        $context["fullPageForm"] = true;
        // line 5
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/sections/_edit", 5)->unwrap();
        // line 7
        $context["headlessMode"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "app", []), "config", []), "general", []), "headlessMode", []);
        // line 238
        if ((isset($context["brandNewSection"]) || array_key_exists("brandNewSection", $context) ? $context["brandNewSection"] : (function () { throw new RuntimeError('Variable "brandNewSection" does not exist.', 238, $this->source); })())) {
            // line 239
            ob_start();
            // line 240
            echo "        new Craft.HandleGenerator('#name', '#handle');

        ";
            // line 242
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 242, $this->source); })()), "app", []), "sites", []), "getAllSites", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                // line 243
                echo "            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[singleUri]\"]');
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                // line 244
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[uriFormat]\"]', { suffix: '/{slug}' });
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                // line 245
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[template]\"]', { suffix: '/_entry' });
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 247
            echo "    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 1
        $this->parent = $this->loadTemplate("settings/sections/_layout", "settings/sections/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/sections/_edit");
    }

    // line 10
    public function block_submitButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "submitButton");
        // line 11
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 11, $this->source); })()), "id", [])) {
            // line 12
            echo "        ";
            $this->displayParentBlock("submitButton", $context, $blocks);
            echo "
    ";
        } else {
            // line 14
            echo "        <button type=\"submit\" class=\"btn submit\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save and edit entry types", "app"), "html", null, true);
            echo "</button>
    ";
        }
        craft\helpers\Template::endProfile("block", "submitButton");
    }

    // line 19
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 20
        echo "    ";
        echo craft\helpers\Html::actionInput("sections/save-section");
        echo "
    ";
        // line 21
        echo craft\helpers\Html::redirectInput(((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 21, $this->source); })()), "id", [])) ? ("settings/sections") : ("settings/sections/{id}/entrytypes")));
        echo "

    ";
        // line 23
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 23, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("sectionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 23, $this->source); })()), "id", []));
        }
        // line 24
        echo "
    ";
        // line 25
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this section will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 31
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 31, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 32
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 32, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 25, $context, $this->getSourceContext());
        // line 35
        echo "

    ";
        // line 37
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this section in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 45
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 45, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 46
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 46, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 37, $context, $this->getSourceContext());
        // line 48
        echo "

    ";
        // line 50
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enable versioning for entries in this section", "app"), "id" => "enableVersioning", "name" => "enableVersioning", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 54, $this->source); })()), "enableVersioning", [])]], 50, $context, $this->getSourceContext());
        // line 55
        echo "

    ";
        // line 57
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Section Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of section is this?", "app"), "warning" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 60
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 60, $this->source); })()), "id", []) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 60, $this->source); })()), "type", []) != "single"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" =>         // line 63
(isset($context["typeOptions"]) || array_key_exists("typeOptions", $context) ? $context["typeOptions"] : (function () { throw new RuntimeError('Variable "typeOptions" does not exist.', 63, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 64
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 64, $this->source); })()), "type", []), "toggle" => true, "targetPrefix" => ".type-", "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 67
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 67, $this->source); })()), "getErrors", [0 => "type"], "method")]], 57, $context, $this->getSourceContext());
        // line 68
        echo "

    <hr>

    ";
        // line 72
        $context["siteRows"] = [];
        // line 73
        echo "    ";
        $context["siteErrors"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 73, $this->source); })()), "getErrors", [0 => "siteSettings"], "method");
        // line 74
        echo "
    ";
        // line 75
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 75, $this->source); })()), "app", []), "sites", []), "getAllSites", [], "method"));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
            // line 76
            echo "        ";
            $context["siteSettings"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array")) : (null));
            // line 77
            echo "        ";
            if ((isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 77, $this->source); })())) {
                // line 78
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 78, $this->source); })()), "getErrors", [], "method"));
                foreach ($context['_seq'] as $context["attribute"] => $context["errors"]) {
                    // line 79
                    echo "                ";
                    $context["siteErrors"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteErrors"]) || array_key_exists("siteErrors", $context) ? $context["siteErrors"] : (function () { throw new RuntimeError('Variable "siteErrors" does not exist.', 79, $this->source); })()), $context["errors"]);
                    // line 80
                    echo "            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['attribute'], $context['errors'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 81
                echo "        ";
            }
            // line 82
            echo "        ";
            $context["siteRows"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteRows"]) || array_key_exists("siteRows", $context) ? $context["siteRows"] : (function () { throw new RuntimeError('Variable "siteRows" does not exist.', 82, $this->source); })()), [craft\helpers\Template::attribute($this->env, $this->source,             // line 83
$context["site"], "handle", []) => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["heading" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 84
$context["site"], "name", []), "site")), "enabled" => twig_include($this->env, $context, "_includes/forms/lightswitch", ["name" => (("sites[" . craft\helpers\Template::attribute($this->env, $this->source,             // line 86
$context["site"], "handle", [])) . "][enabled]"), "on" => (            // line 87
(isset($context["brandNewSection"]) || array_key_exists("brandNewSection", $context) ? $context["brandNewSection"] : (function () { throw new RuntimeError('Variable "brandNewSection" does not exist.', 87, $this->source); })()) || (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 87, $this->source); })())), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 88
$context["site"], "id", []), "small" => true]), "singleHomepage" => ["value" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 92
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 92, $this->source); })()), "type", []) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 92, $this->source); })())) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 92, $this->source); })()), "uriFormat", []) == "__home__"))], "singleUri" => ["value" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 95
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 95, $this->source); })()), "type", []) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 95, $this->source); })())) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 95, $this->source); })()), "uriFormat", []) != "__home__"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 95, $this->source); })()), "uriFormat", [])) : ("")), "hasErrors" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 96
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 96, $this->source); })()), "type", []) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 96, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 96, $this->source); })()), "hasErrors", [0 => "uriFormat"], "method")) : (""))], "uriFormat" => ["value" => ((            // line 99
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 99, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 99, $this->source); })()), "uriFormat", [])) : ("")), "hasErrors" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 100
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 100, $this->source); })()), "type", []) != "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 100, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 100, $this->source); })()), "hasErrors", [0 => "uriFormat"], "method")) : (""))], "template" => (( !            // line 102
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 102, $this->source); })())) ? (["value" => ((            // line 103
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 103, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 103, $this->source); })()), "template", [])) : ("")), "hasErrors" => ((            // line 104
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 104, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 104, $this->source); })()), "hasErrors", [0 => "template"], "method")) : (""))]) : ("")), "enabledByDefault" => ((            // line 106
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 106, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 106, $this->source); })()), "enabledByDefault", [])) : (true))])]);
            // line 109
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 110
        echo "
    ";
        // line 111
        echo twig_call_macro($macros["forms"], "macro_editableTableField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site Settings", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose which sites this section should be available in, and configure the site-specific settings.", "app"), "id" => "sites", "name" => "sites", "cols" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, ["heading" => ["type" => "heading", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app"), "thin" => true], "enabled" => ["type" => "heading", "thin" => true, "class" => (( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 125
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 125, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) ? ("hidden") : (""))], "singleHomepage" => ["type" => "checkbox", "headingHtml" => $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["data" => ["icon" => "home"], "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Homepage", "app")]), "thin" => true, "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "single-homepage", 1 => "type-single", 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 134
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 134, $this->source); })()), "type", []) != "single")) ? ("hidden") : (""))])], "singleUri" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("URI", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("What the entry URI should be for the site. Leave blank if the entry doesn’t have a URL.", "app"), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Leave blank if the entry doesn’t have a URL", "app"), "code" => true, "width" => ((        // line 142
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 142, $this->source); })())) ? (500) : ("")), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "single-uri", 1 => "type-single", 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 143
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 143, $this->source); })()), "type", []) != "single")) ? ("hidden") : (""))])], "uriFormat" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry URI Format", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("What entry URIs should look like for the site. Leave blank if entries don’t have URLs.", "app"), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Leave blank if entries don’t have URLs", "app"), "code" => true, "width" => ((        // line 151
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 151, $this->source); })())) ? (500) : ("")), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "type-channel", 1 => "type-structure", 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 152
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 152, $this->source); })()), "type", []) == "single")) ? (" hidden") : (""))])], "template" => (( !        // line 154
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 154, $this->source); })())) ? (["type" => "template", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Template", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which template should be loaded when an entry’s URL is requested.", "app"), "code" => true]) : ("")), "enabledByDefault" => ["type" => "lightswitch", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Status", "app"), "thin" => true, "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "type-channel", 1 => "type-structure", 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 164
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 164, $this->source); })()), "type", []) == "single")) ? (" hidden") : (""))])]]), "rows" =>         // line 167
(isset($context["siteRows"]) || array_key_exists("siteRows", $context) ? $context["siteRows"] : (function () { throw new RuntimeError('Variable "siteRows" does not exist.', 167, $this->source); })()), "fullWidth" =>  !        // line 168
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 168, $this->source); })()), "staticRows" => true, "errors" => array_unique(        // line 170
(isset($context["siteErrors"]) || array_key_exists("siteErrors", $context) ? $context["siteErrors"] : (function () { throw new RuntimeError('Variable "siteErrors" does not exist.', 170, $this->source); })()))]], 111, $context, $this->getSourceContext());
        // line 171
        echo "

    ";
        // line 173
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 173, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 174
            echo "        <div class=\"field type-channel type-structure ";
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 174, $this->source); })()), "type", []) == "single")) {
                echo "hidden";
            }
            echo "\">
            ";
            // line 175
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Propagation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Of the enabled sites above, which sites should entries in this section be saved to?", "app"), "warning" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 178
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 178, $this->source); })()), "id", []) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 178, $this->source); })()), "propagationMethod", []) != "none")) && (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 178, $this->source); })()), "siteSettings", [])) > 1))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "propagationMethod", "name" => "propagationMethod", "options" => [0 => ["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Only save entries to the site they were created in", "app")], 1 => ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to other sites in the same site group", "app")], 2 => ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to other sites with the same language", "app")], 3 => ["value" => "all", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to all sites enabled for this section", "app")], 4 => ["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Let each entry choose which sites it should be saved to", "app")]], "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 188
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 188, $this->source); })()), "propagationMethod", [])]], 175, $context, $this->getSourceContext());
            // line 189
            echo "
        </div>
    ";
        }
        // line 192
        echo "
    <div class=\"field type-structure ";
        // line 193
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 193, $this->source); })()), "type", []) != "structure")) {
            echo "hidden";
        }
        echo "\">
        ";
        // line 194
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Levels", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of levels this section can have. Leave blank if you don’t care.", "app"), "id" => "maxLevels", "name" => "maxLevels", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 199
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 199, $this->source); })()), "maxLevels", []), "size" => 5, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 201
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 201, $this->source); })()), "getErrors", [0 => "maxLevels"], "method")]], 194, $context, $this->getSourceContext());
        // line 202
        echo "
    </div>

    ";
        // line 205
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 205, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 205, $this->source); })()))) {
            // line 206
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_editableTableField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Preview Targets", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Locations that should be available for previewing entries in this section.", "app"), "id" => "previewTargets", "name" => "previewTargets", "cols" => ["label" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Label", "app")], "urlFormat" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("URL Format", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("The URL/URI to use for this target.", "app"), "code" => true], "refresh" => ["type" => "checkbox", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Refresh", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether preview frames should be automatically refreshed when content changes.", "app"), "thin" => true]], "defaultValues" => ["refresh" => true], "rows" => craft\helpers\Template::attribute($this->env, $this->source,             // line 232
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 232, $this->source); })()), "previewTargets", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 233
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 233, $this->source); })()), "getErrors", [0 => "previewTargets"], "method")]], 206, $context, $this->getSourceContext());
            // line 234
            echo "
    ";
        }
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/sections/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  313 => 234,  311 => 233,  310 => 232,  308 => 206,  306 => 205,  301 => 202,  299 => 201,  298 => 199,  297 => 194,  291 => 193,  288 => 192,  283 => 189,  281 => 188,  280 => 178,  279 => 175,  272 => 174,  270 => 173,  266 => 171,  264 => 170,  263 => 168,  262 => 167,  261 => 164,  260 => 154,  259 => 152,  258 => 151,  257 => 143,  256 => 142,  255 => 134,  254 => 125,  253 => 111,  250 => 110,  236 => 109,  234 => 106,  233 => 104,  232 => 103,  231 => 102,  230 => 100,  229 => 99,  228 => 96,  227 => 95,  226 => 92,  225 => 88,  224 => 87,  223 => 86,  222 => 84,  221 => 83,  219 => 82,  216 => 81,  210 => 80,  207 => 79,  202 => 78,  199 => 77,  196 => 76,  179 => 75,  176 => 74,  173 => 73,  171 => 72,  165 => 68,  163 => 67,  162 => 64,  161 => 63,  160 => 60,  159 => 57,  155 => 55,  153 => 54,  152 => 50,  148 => 48,  146 => 46,  145 => 45,  144 => 37,  140 => 35,  138 => 32,  137 => 31,  136 => 25,  133 => 24,  129 => 23,  124 => 21,  119 => 20,  114 => 19,  105 => 14,  99 => 12,  96 => 11,  91 => 10,  85 => 1,  81 => 247,  73 => 245,  69 => 244,  64 => 243,  60 => 242,  56 => 240,  54 => 239,  52 => 238,  50 => 7,  48 => 5,  46 => 3,  44 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'settings/sections/_layout' %}
{% set selectedTab = 'settings' %}
{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}

{% set headlessMode = craft.app.config.general.headlessMode %}


{% block submitButton %}
    {% if section.id %}
        {{ parent() }}
    {% else %}
        <button type=\"submit\" class=\"btn submit\">{{ 'Save and edit entry types'|t('app') }}</button>
    {% endif %}
{% endblock %}


{% block content %}
    {{ actionInput('sections/save-section') }}
    {{ redirectInput(section.id ? 'settings/sections' : \"settings/sections/{id}/entrytypes\") }}

    {% if section.id %}{{ hiddenInput('sectionId', section.id) }}{% endif %}

    {{ forms.textField({
        first: true,
        label: \"Name\"|t('app'),
        instructions: \"What this section will be called in the control panel.\"|t('app'),
        id: 'name',
        name: 'name',
        value: section.name,
        errors: section.getErrors('name'),
        autofocus: true,
        required: true,
    }) }}

    {{ forms.textField({
        label: \"Handle\"|t('app'),
        instructions: \"How you’ll refer to this section in the templates.\"|t('app'),
        id: 'handle',
        name: 'handle',
        class: 'code',
        autocorrect: false,
        autocapitalize: false,
        value: section.handle,
        errors: section.getErrors('handle'),
        required: true
    }) }}

    {{ forms.checkboxField({
        label: 'Enable versioning for entries in this section'|t('app'),
        id: 'enableVersioning',
        name: 'enableVersioning',
        checked: section.enableVersioning
    }) }}

    {{ forms.selectField({
        label: \"Section Type\"|t('app'),
        instructions: \"What type of section is this?\"|t('app'),
        warning: section.id and section.type != 'single' ? 'Changing this may result in data loss.'|t('app'),
        id: 'type',
        name: 'type',
        options: typeOptions,
        value: section.type,
        toggle: true,
        targetPrefix: '.type-',
        errors: section.getErrors('type')
    }) }}

    <hr>

    {% set siteRows = [] %}
    {% set siteErrors = section.getErrors('siteSettings') %}

    {% for site in craft.app.sites.getAllSites() %}
        {% set siteSettings = section.siteSettings[site.id] ?? null %}
        {% if siteSettings %}
            {% for attribute, errors in siteSettings.getErrors() %}
                {% set siteErrors = siteErrors|merge(errors) %}
            {% endfor %}
        {% endif %}
        {% set siteRows = siteRows|merge({
            (site.handle): {
                heading: site.name|t('site')|e,
                enabled: include('_includes/forms/lightswitch', {
                    name: 'sites['~site.handle~'][enabled]',
                    on: brandNewSection or siteSettings,
                    value: site.id,
                    small: true
                }),
                singleHomepage: {
                    value: (section.type == 'single' and siteSettings and siteSettings.uriFormat == '__home__')
                },
                singleUri: {
                   value: (section.type == 'single' and siteSettings and siteSettings.uriFormat != '__home__') ? siteSettings.uriFormat,
                   hasErrors: (section.type == 'single' and siteSettings ? siteSettings.hasErrors('uriFormat'))
                },
                uriFormat: {
                    value: siteSettings ? siteSettings.uriFormat,
                    hasErrors: (section.type != 'single' and siteSettings ? siteSettings.hasErrors('uriFormat'))
                },
                template: not headlessMode ? {
                    value: siteSettings ? siteSettings.template,
                    hasErrors: siteSettings ? siteSettings.hasErrors('template'),
                },
                enabledByDefault: siteSettings ? siteSettings.enabledByDefault : true,
            }|filter
        }) %}
    {% endfor %}

    {{ forms.editableTableField({
        label: \"Site Settings\"|t('app'),
        instructions: \"Choose which sites this section should be available in, and configure the site-specific settings.\"|t('app'),
        id: 'sites',
        name: 'sites',
        cols: {
            heading: {
                type: 'heading',
                heading: \"Site\"|t('app'),
                thin: true
            },
            enabled: {
                type: 'heading',
                thin: true,
                class: not craft.app.getIsMultiSite() ? 'hidden'
            },
            singleHomepage: {
                type: 'checkbox',
                headingHtml: tag('div', {
                    data: {icon: 'home'},
                    title: 'Homepage'|t('app')
                }),
                thin: true,
                class: ['single-homepage', 'type-single', section.type != 'single' ? 'hidden']|filter
            },
            singleUri: {
                type: 'singleline',
                heading: \"URI\"|t('app'),
                info: \"What the entry URI should be for the site. Leave blank if the entry doesn’t have a URL.\"|t('app'),
                placeholder: 'Leave blank if the entry doesn’t have a URL'|t('app'),
                code: true,
                width: headlessMode ? 500,
                class: ['single-uri', 'type-single', section.type != 'single' ? 'hidden']|filter
            },
            uriFormat: {
                type: 'singleline',
                heading: \"Entry URI Format\"|t('app'),
                info: \"What entry URIs should look like for the site. Leave blank if entries don’t have URLs.\"|t('app'),
                placeholder: 'Leave blank if entries don’t have URLs'|t('app'),
                code: true,
                width: headlessMode ? 500,
                class: ['type-channel', 'type-structure', section.type == 'single' ? ' hidden']|filter
            },
            template: not headlessMode ? {
                type: 'template',
                heading: \"Template\"|t('app'),
                info: \"Which template should be loaded when an entry’s URL is requested.\"|t('app'),
                code: true
            },
            enabledByDefault: {
                type: 'lightswitch',
                heading: \"Default Status\"|t('app'),
                thin: true,
                class: ['type-channel', 'type-structure', section.type == 'single' ? ' hidden']|filter
            }
        }|filter,
        rows: siteRows,
        fullWidth: not headlessMode,
        staticRows: true,
        errors: siteErrors|unique
    }) }}

    {% if craft.app.getIsMultiSite() %}
        <div class=\"field type-channel type-structure {% if section.type == 'single' %}hidden{% endif %}\">
            {{ forms.selectField({
                label: 'Propagation Method'|t('app'),
                instructions: 'Of the enabled sites above, which sites should entries in this section be saved to?'|t('app'),
                warning: section.id and section.propagationMethod != 'none' and section.siteSettings|length > 1 ? 'Changing this may result in data loss.'|t('app'),
                id: 'propagationMethod',
                name: 'propagationMethod',
                options: [
                    { value: 'none', label: 'Only save entries to the site they were created in'|t('app') },
                    { value: 'siteGroup', label: 'Save entries to other sites in the same site group'|t('app') },
                    { value: 'language', label: 'Save entries to other sites with the same language'|t('app') },
                    { value: 'all', label: 'Save entries to all sites enabled for this section'|t('app') },
                    { value: 'custom', label: 'Let each entry choose which sites it should be saved to'|t('app') },
                ],
                value: section.propagationMethod
            }) }}
        </div>
    {% endif %}

    <div class=\"field type-structure {% if section.type != 'structure' %}hidden{% endif %}\">
        {{ forms.textField({
            label: \"Max Levels\"|t('app'),
            instructions: \"The maximum number of levels this section can have. Leave blank if you don’t care.\"|t('app'),
            id: 'maxLevels',
            name: 'maxLevels',
            value: section.maxLevels,
            size: 5,
            errors: section.getErrors('maxLevels')
        }) }}
    </div>

    {% if CraftEdition == CraftPro %}
        {{ forms.editableTableField({
            label: 'Preview Targets'|t('app'),
            instructions: 'Locations that should be available for previewing entries in this section.'|t('app'),
            id: 'previewTargets',
            name: 'previewTargets',
            cols: {
                label: {
                    type: 'singleline',
                    heading: 'Label'|t('app'),
                },
                urlFormat: {
                    type: 'singleline',
                    heading: 'URL Format'|t('app'),
                    info: 'The URL/URI to use for this target.'|t('app'),
                    code: true,
                },
                refresh: {
                    type: 'checkbox',
                    heading: 'Refresh'|t('app'),
                    info: 'Whether preview frames should be automatically refreshed when content changes.'|t('app'),
                    thin: true,
                }
            },
            defaultValues: {
                refresh: true,
            },
            rows: section.previewTargets,
            errors: section.getErrors('previewTargets')
        }) }}
    {% endif %}
{% endblock %}

{% if brandNewSection %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');

        {% for site in craft.app.sites.getAllSites() %}
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[singleUri]\"]');
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[uriFormat]\"]', { suffix: '/{slug}' });
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[template]\"]', { suffix: '/_entry' });
        {% endfor %}
    {% endjs %}
{% endif %}
", "settings/sections/_edit", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/settings/sections/_edit.html");
    }
}

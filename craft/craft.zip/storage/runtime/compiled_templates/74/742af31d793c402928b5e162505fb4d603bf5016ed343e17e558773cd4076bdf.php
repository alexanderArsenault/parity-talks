<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/date */
class __TwigTemplate_426e839c2bc7df661161cf8acb772299905855341af7f3d974cfcf417052967b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/date");
        // line 1
        $context["id"] = (((($context["id"]) ?? ("date")) . twig_random($this->env)) . "-date");
        // line 2
        $context["name"] = (($context["name"]) ?? (null));
        // line 3
        $context["value"] = (((($context["value"]) ?? (false))) ? (twig_date_converter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 3, $this->source); })()), false)) : (null));
        // line 5
        echo "<div class=\"datewrapper\"";
        // line 6
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">";
        // line 7
        $this->loadTemplate("_includes/forms/text", "_includes/forms/date", 7)->display(twig_array_merge($context, ["name" => ((        // line 8
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 8, $this->source); })())) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 8, $this->source); })()) . "[date]")) : ("")), "autocomplete" => false, "size" => 10, "placeholder" => " ", "value" => ((        // line 12
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 12, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->dateFilter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 12, $this->source); })()), "short")) : (""))]));
        // line 14
        echo "<div data-icon=\"date\"></div>
    ";
        // line 15
        if ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 15, $this->source); })())) {
            // line 16
            echo craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 16, $this->source); })()) . "[timezone]"), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 16, $this->source); })()), "app", []), "getTimeZone", [], "method"));
        }
        // line 18
        echo "</div>";
        // line 20
        ob_start();
        // line 21
        echo "    \$('#";
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 21, $this->source); })())]), "js"), "html", null, true);
        echo "').datepicker(\$.extend({
        defaultDate: new Date(";
        // line 22
        if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 22, $this->source); })())) {
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 22, $this->source); })()), "format", [0 => "Y"], "method"), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 22, $this->source); })()), "format", [0 => "n"], "method") - 1), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 22, $this->source); })()), "format", [0 => "j"], "method"), "html", null, true);
        }
        echo ")
    }, Craft.datepickerOptions));";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_includes/forms/date");
    }

    public function getTemplateName()
    {
        return "_includes/forms/date";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 22,  68 => 21,  66 => 20,  64 => 18,  61 => 16,  59 => 15,  56 => 14,  54 => 12,  53 => 8,  52 => 7,  46 => 6,  44 => 5,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set id = (id ?? 'date'~random())~'-date' -%}
{% set name = name ?? null -%}
{% set value = (value ?? false) ? date(value, false) : null -%}

<div class=\"datewrapper\"
        {%- if block('attr') is defined %} {{ block('attr') }}{% endif %}>
    {%- include \"_includes/forms/text\" with {
        name: (name ? name~'[date]'),
        autocomplete: false,
        size: 10,
        placeholder: ' ',
        value: (value ? value|date('short') : '')
    } -%}
    <div data-icon=\"date\"></div>
    {% if name -%}
        {{ hiddenInput(\"#{name}[timezone]\", craft.app.getTimeZone()) }}
    {%- endif -%}
</div>

{%- js %}
    \$('#{{ id|namespaceInputId|e('js') }}').datepicker(\$.extend({
        defaultDate: new Date({% if value %}{{ value.format('Y') }}, {{ value.format('n')-1 }}, {{ value.format('j') }}{% endif %})
    }, Craft.datepickerOptions));
{%- endjs %}
", "_includes/forms/date", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/forms/date.html");
    }
}

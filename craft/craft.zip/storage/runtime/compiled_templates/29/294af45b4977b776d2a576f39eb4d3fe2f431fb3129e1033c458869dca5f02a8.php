<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Assets/settings */
class __TwigTemplate_57fc66302d21eee6eaa62e6ad3ec238f2f88fa35905102f9d49d946a0a047020 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'fieldSettings' => [$this, 'block_fieldSettings'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_components/fieldtypes/elementfieldsettings";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Assets/settings");
        // line 3
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Assets/settings", 3)->unwrap();
        // line 5
        $context["fileKindOptions"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 5, $this->source); })()), "getFileKindOptions", [], "method");
        // line 6
        $context["isMatrix"] = twig_in_filter("craft\\fields\\Matrix", craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", []), "view", []), "getNamespace", [], "method"));
        // line 31
        $macros["__internal_679a571ce9b0da4fcca490db65cb25d22bdd827d432436582403298cdea835d2"] = $this->macros["__internal_679a571ce9b0da4fcca490db65cb25d22bdd827d432436582403298cdea835d2"] = $this;
        // line 1
        $this->parent = $this->loadTemplate("_components/fieldtypes/elementfieldsettings", "_components/fieldtypes/Assets/settings", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Assets/settings");
    }

    // line 34
    public function block_fieldSettings($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "fieldSettings");
        // line 35
        echo "    ";
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Restrict uploads to a single folder", "app"), "id" => "useSingleFolder-toggle", "name" => "useSingleFolder", "class" => "use-single-folder-cb", "value" => 1, "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 41
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 41, $this->source); })()), "useSingleFolder", []), "toggle" => "single-folder-settings", "reverseToggle" => "multi-folder-settings"]], 35, $context, $this->getSourceContext());
        // line 44
        echo "

    ";
        // line 46
        $context["uploadLocationNote"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Note that the subfolder path can contain variables like <code>{slug}</code> or <code>{author.username}</code>.", "app");
        // line 47
        echo "    ";
        if ((isset($context["isMatrix"]) || array_key_exists("isMatrix", $context) ? $context["isMatrix"] : (function () { throw new RuntimeError('Variable "isMatrix" does not exist.', 47, $this->source); })())) {
            // line 48
            echo "        ";
            $context["uploadLocationNote"] = $this->extensions['craft\web\twig\Extension']->replaceFilter((isset($context["uploadLocationNote"]) || array_key_exists("uploadLocationNote", $context) ? $context["uploadLocationNote"] : (function () { throw new RuntimeError('Variable "uploadLocationNote" does not exist.', 48, $this->source); })()), ["{slug}" => "{owner.slug}", "{author.username}" => "{owner.author.username}"]);
            // line 52
            echo "    ";
        }
        // line 53
        echo "
    <div id=\"multi-folder-settings\"";
        // line 54
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 54, $this->source); })()), "useSingleFolder", [])) {
            echo " class=\"hidden\"";
        }
        echo ">
        ";
        // line 55
        $this->displayBlock("sourcesField", $context, $blocks);
        echo "

        ";
        // line 57
        echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Upload Location", "app"), "instructions" => (($this->extensions['craft\web\twig\Extension']->translateFilter("Where should files be uploaded when they are dragged directly onto the field, or uploaded from the front end?", "app") . " ") .         // line 59
(isset($context["uploadLocationNote"]) || array_key_exists("uploadLocationNote", $context) ? $context["uploadLocationNote"] : (function () { throw new RuntimeError('Variable "uploadLocationNote" does not exist.', 59, $this->source); })())), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 60
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 60, $this->source); })()), "getErrors", [0 => "defaultUploadLocationSubpath"], "method")], twig_call_macro($macros["__internal_679a571ce9b0da4fcca490db65cb25d22bdd827d432436582403298cdea835d2"], "macro_uploadLocationInput", ["defaultUploadLocation",         // line 61
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 61, $this->source); })()), (isset($context["sourceOptions"]) || array_key_exists("sourceOptions", $context) ? $context["sourceOptions"] : (function () { throw new RuntimeError('Variable "sourceOptions" does not exist.', 61, $this->source); })())], 61, $context, $this->getSourceContext())], 57, $context, $this->getSourceContext());
        echo "
    </div>

    <div id=\"single-folder-settings\"";
        // line 64
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 64, $this->source); })()), "useSingleFolder", [])) {
            echo " class=\"hidden\"";
        }
        echo ">
        ";
        // line 65
        echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Upload Location", "app"), "instructions" =>         // line 67
(isset($context["uploadLocationNote"]) || array_key_exists("uploadLocationNote", $context) ? $context["uploadLocationNote"] : (function () { throw new RuntimeError('Variable "uploadLocationNote" does not exist.', 67, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 68
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()), "getErrors", [0 => "singleUploadLocationSubpath"], "method")], twig_call_macro($macros["__internal_679a571ce9b0da4fcca490db65cb25d22bdd827d432436582403298cdea835d2"], "macro_uploadLocationInput", ["singleUploadLocation",         // line 69
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 69, $this->source); })()), (isset($context["sourceOptions"]) || array_key_exists("sourceOptions", $context) ? $context["sourceOptions"] : (function () { throw new RuntimeError('Variable "sourceOptions" does not exist.', 69, $this->source); })())], 69, $context, $this->getSourceContext())], 65, $context, $this->getSourceContext());
        echo "
    </div>

    ";
        // line 72
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show unpermitted volumes", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether to show volumes that the user doesn’t have permission to view.", "app"), "id" => "showUnpermittedVolumes", "name" => "showUnpermittedVolumes", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 77
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 77, $this->source); })()), "showUnpermittedVolumes", [])]], 72, $context, $this->getSourceContext());
        // line 78
        echo "

    ";
        // line 80
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show unpermitted files", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether to show files that the user doesn’t have permission to view, per the “View files uploaded by other users” permission.", "app"), "id" => "showUnpermittedFiles", "name" => "showUnpermittedFiles", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 85
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 85, $this->source); })()), "showUnpermittedFiles", [])]], 80, $context, $this->getSourceContext());
        // line 86
        echo "

    ";
        // line 88
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Restrict allowed file types", "app"), "class" => "restrictFiles", "id" => "restrictFiles", "name" => "restrictFiles", "value" => 1, "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 94
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 94, $this->source); })()), "restrictFiles", []), "toggle" => "restrict-allowed-types"]], 88, $context, $this->getSourceContext());
        // line 96
        echo "

    <fieldset id=\"restrict-allowed-types\"";
        // line 98
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 98, $this->source); })()), "restrictFiles", [])) {
            echo " class=\"hidden indent\"";
        }
        echo ">
        ";
        // line 99
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["fileKindOptions"]) || array_key_exists("fileKindOptions", $context) ? $context["fileKindOptions"] : (function () { throw new RuntimeError('Variable "fileKindOptions" does not exist.', 99, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
            // line 100
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => craft\helpers\Template::attribute($this->env, $this->source,             // line 101
$context["option"], "label", []), "id" => ("allowedKinds-" . craft\helpers\Template::attribute($this->env, $this->source,             // line 102
$context["option"], "value", [])), "name" => "allowedKinds[]", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 104
$context["option"], "value", []), "checked" => twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source,             // line 105
$context["option"], "value", []), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 105, $this->source); })()), "allowedKinds", []))]], 100, $context, $this->getSourceContext());
            // line 106
            echo "
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 108
        echo "        ";
        echo twig_call_macro($macros["forms"], "macro_errorList", [craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 108, $this->source); })()), "getErrors", [0 => "allowedKinds"], "method")], 108, $context, $this->getSourceContext());
        echo "
    </fieldset>

    ";
        // line 111
        $this->displayBlock("limitField", $context, $blocks);
        echo "
    ";
        // line 112
        $this->displayBlock("viewModeField", $context, $blocks);
        echo "
    ";
        // line 113
        $this->displayBlock("selectionLabelField", $context, $blocks);
        echo "
    ";
        // line 114
        $this->displayBlock("validateRelatedElementsField", $context, $blocks);
        echo "

    <hr>

    ";
        // line 118
        echo twig_call_macro($macros["forms"], "macro_selectField", [["id" => "preview-mode", "name" => "previewMode", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Preview Mode", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How the related {type} should be displayed within element indexes.", "app", ["type" =>         // line 123
(isset($context["pluralElementType"]) || array_key_exists("pluralElementType", $context) ? $context["pluralElementType"] : (function () { throw new RuntimeError('Variable "pluralElementType" does not exist.', 123, $this->source); })())]), "options" => [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show thumbnails and titles", "app"), "value" => "full"], 1 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show thumbnails only", "app"), "value" => "thumbs"]], "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 129
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 129, $this->source); })()), "previewMode", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 130
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 130, $this->source); })()), "getErrors", [0 => "previewMode"], "method")]], 118, $context, $this->getSourceContext());
        // line 131
        echo "

    ";
        // line 133
        $this->displayBlock("advancedSettings", $context, $blocks);
        echo "
";
        craft\helpers\Template::endProfile("block", "fieldSettings");
    }

    // line 8
    public function macro_uploadLocationInput($__name__ = null, $__field__ = null, $__inputSourceOptions__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "name" => $__name__,
            "field" => $__field__,
            "inputSourceOptions" => $__inputSourceOptions__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "uploadLocationInput");
            // line 9
            echo "    ";
            $macros["__internal_d62e57263cb280b87b2cfbd80d35401a8ae6efcf6b5158d488260cdac1b0df09"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Assets/settings", 9)->unwrap();
            // line 10
            echo "    <div class=\"flex\">
        <div>
            ";
            // line 12
            echo twig_call_macro($macros["__internal_d62e57263cb280b87b2cfbd80d35401a8ae6efcf6b5158d488260cdac1b0df09"], "macro_select", [["id" => (            // line 13
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 13, $this->source); })()) . "Source"), "name" => (            // line 14
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 14, $this->source); })()) . "Source"), "options" =>             // line 15
(isset($context["inputSourceOptions"]) || array_key_exists("inputSourceOptions", $context) ? $context["inputSourceOptions"] : (function () { throw new RuntimeError('Variable "inputSourceOptions" does not exist.', 15, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 16
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 16, $this->source); })()), ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 16, $this->source); })()) . "Source"), [], "array")]], 12, $context, $this->getSourceContext());
            // line 17
            echo "
        </div>
        <div class=\"flex-grow\">
            ";
            // line 20
            echo twig_call_macro($macros["__internal_d62e57263cb280b87b2cfbd80d35401a8ae6efcf6b5158d488260cdac1b0df09"], "macro_text", [["id" => (            // line 21
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 21, $this->source); })()) . "Subpath"), "class" => "ltr", "name" => (            // line 23
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 23, $this->source); })()) . "Subpath"), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 24
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 24, $this->source); })()), ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 24, $this->source); })()) . "Subpath"), [], "array"), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("path/to/subfolder", "app")]], 20, $context, $this->getSourceContext());
            // line 26
            echo "
        </div>
    </div>
";
            craft\helpers\Template::endProfile("macro", "uploadLocationInput");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Assets/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  245 => 26,  243 => 24,  242 => 23,  241 => 21,  240 => 20,  235 => 17,  233 => 16,  232 => 15,  231 => 14,  230 => 13,  229 => 12,  225 => 10,  222 => 9,  206 => 8,  199 => 133,  195 => 131,  193 => 130,  192 => 129,  191 => 123,  190 => 118,  183 => 114,  179 => 113,  175 => 112,  171 => 111,  164 => 108,  157 => 106,  155 => 105,  154 => 104,  153 => 102,  152 => 101,  150 => 100,  146 => 99,  140 => 98,  136 => 96,  134 => 94,  133 => 88,  129 => 86,  127 => 85,  126 => 80,  122 => 78,  120 => 77,  119 => 72,  113 => 69,  112 => 68,  111 => 67,  110 => 65,  104 => 64,  98 => 61,  97 => 60,  96 => 59,  95 => 57,  90 => 55,  84 => 54,  81 => 53,  78 => 52,  75 => 48,  72 => 47,  70 => 46,  66 => 44,  64 => 41,  62 => 35,  57 => 34,  51 => 1,  49 => 31,  47 => 6,  45 => 5,  43 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_components/fieldtypes/elementfieldsettings\" %}

{% import \"_includes/forms\" as forms %}

{% set fileKindOptions = field.getFileKindOptions() %}
{% set isMatrix = 'craft\\\\fields\\\\Matrix' in craft.app.view.getNamespace() %}

{% macro uploadLocationInput(name, field, inputSourceOptions) %}
    {% from \"_includes/forms\" import select, text %}
    <div class=\"flex\">
        <div>
            {{ select({
                id: name~'Source',
                name: name~'Source',
                options: inputSourceOptions,
                value: field[name~'Source'],
            }) }}
        </div>
        <div class=\"flex-grow\">
            {{ text({
                id: name~'Subpath',
                class: 'ltr',
                name: name~'Subpath',
                value: field[name~'Subpath'],
                placeholder: \"path/to/subfolder\"|t('app')
            }) }}
        </div>
    </div>
{% endmacro %}

{% from _self import uploadLocationInput %}


{% block fieldSettings %}
    {{ forms.checkboxField({
        label: 'Restrict uploads to a single folder'|t('app'),
        id: 'useSingleFolder-toggle',
        name: 'useSingleFolder',
        class: 'use-single-folder-cb',
        value: 1,
        checked: field.useSingleFolder,
        toggle: 'single-folder-settings',
        reverseToggle: 'multi-folder-settings'
    }) }}

    {% set uploadLocationNote = \"Note that the subfolder path can contain variables like <code>{slug}</code> or <code>{author.username}</code>.\"|t('app') %}
    {% if isMatrix %}
        {% set uploadLocationNote = uploadLocationNote|replace({
            '{slug}': '{owner.slug}',
            '{author.username}': '{owner.author.username}'
        }) %}
    {% endif %}

    <div id=\"multi-folder-settings\"{% if field.useSingleFolder %} class=\"hidden\"{% endif %}>
        {{ block('sourcesField') }}

        {{ forms.field({
            label: \"Default Upload Location\"|t('app'),
            instructions: \"Where should files be uploaded when they are dragged directly onto the field, or uploaded from the front end?\"|t('app') ~' '~ uploadLocationNote,
            errors: field.getErrors('defaultUploadLocationSubpath')
        }, uploadLocationInput('defaultUploadLocation', field, sourceOptions)) }}
    </div>

    <div id=\"single-folder-settings\"{% if not field.useSingleFolder %} class=\"hidden\"{% endif %}>
        {{ forms.field({
            label: \"Upload Location\"|t('app'),
            instructions: uploadLocationNote,
            errors: field.getErrors('singleUploadLocationSubpath')
        }, uploadLocationInput('singleUploadLocation', field, sourceOptions)) }}
    </div>

    {{ forms.checkboxField({
        label: 'Show unpermitted volumes'|t('app'),
        instructions: 'Whether to show volumes that the user doesn’t have permission to view.'|t('app'),
        id: 'showUnpermittedVolumes',
        name: 'showUnpermittedVolumes',
        checked: field.showUnpermittedVolumes,
    }) }}

    {{ forms.checkboxField({
        label: 'Show unpermitted files'|t('app'),
        instructions: 'Whether to show files that the user doesn’t have permission to view, per the “View files uploaded by other users” permission.'|t('app'),
        id: 'showUnpermittedFiles',
        name: 'showUnpermittedFiles',
        checked: field.showUnpermittedFiles,
    }) }}

    {{ forms.checkboxField({
        label: 'Restrict allowed file types'|t('app'),
        class: 'restrictFiles',
        id: 'restrictFiles',
        name: 'restrictFiles',
        value: 1,
        checked: field.restrictFiles,
        toggle: 'restrict-allowed-types'
    }) }}

    <fieldset id=\"restrict-allowed-types\"{% if not field.restrictFiles %} class=\"hidden indent\"{% endif %}>
        {% for option in fileKindOptions %}
            {{ forms.checkboxField({
                label: option.label,
                id: 'allowedKinds-'~option.value,
                name: 'allowedKinds[]',
                value: option.value,
                checked: (option.value in field.allowedKinds)
            }) }}
        {% endfor %}
        {{ forms.errorList(field.getErrors('allowedKinds')) }}
    </fieldset>

    {{ block('limitField') }}
    {{ block('viewModeField') }}
    {{ block('selectionLabelField') }}
    {{ block('validateRelatedElementsField') }}

    <hr>

    {{ forms.selectField({
        id: 'preview-mode',
        name: 'previewMode',
        label: 'Preview Mode'|t('app'),
        instructions: 'How the related {type} should be displayed within element indexes.'|t('app', {
            type: pluralElementType,
        }),
        options: [
            {label: 'Show thumbnails and titles'|t('app'), value: 'full'},
            {label: 'Show thumbnails only'|t('app'), value: 'thumbs'},
        ],
        value: field.previewMode,
        errors: field.getErrors('previewMode'),
    }) }}

    {{ block('advancedSettings') }}
{% endblock %}
", "_components/fieldtypes/Assets/settings", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_components/fieldtypes/Assets/settings.html");
    }
}

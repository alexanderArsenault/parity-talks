<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__fa9ffa6aa72f3038ffdb8da72ecdcb26b722d8a94a296d87b16a7a517e9c660e */
class __TwigTemplate_be76796e8ffc034daa0c9f7fef97871361b2f0c62837ecd685b23679804222b3 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__fa9ffa6aa72f3038ffdb8da72ecdcb26b722d8a94a296d87b16a7a517e9c660e");
        // line 1
        echo "logbook-entries/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        craft\helpers\Template::endProfile("template", "__string_template__fa9ffa6aa72f3038ffdb8da72ecdcb26b722d8a94a296d87b16a7a517e9c660e");
    }

    public function getTemplateName()
    {
        return "__string_template__fa9ffa6aa72f3038ffdb8da72ecdcb26b722d8a94a296d87b16a7a517e9c660e";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("logbook-entries/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__fa9ffa6aa72f3038ffdb8da72ecdcb26b722d8a94a296d87b16a7a517e9c660e", "");
    }
}

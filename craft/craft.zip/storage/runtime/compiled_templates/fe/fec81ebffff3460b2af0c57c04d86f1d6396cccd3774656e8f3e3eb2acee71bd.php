<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/components/form-action-menu */
class __TwigTemplate_cb0f48ef331888e628058d248e5e5a365c9be504a379becaa64d81aed0d09162 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $macros["_self"] = $this->macros["_self"] = $this;
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/components/form-action-menu");
        // line 28
        echo "
";
        // line 29
        $context["safeActions"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, (isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 29, $this->source); })()), function ($__a__) use ($context, $macros) { $context["a"] = $__a__; return  !(((craft\helpers\Template::attribute($this->env, $this->source, ($context["a"] ?? null), "destructive", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a"] ?? null), "destructive", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a"] ?? null), "destructive", [])) : (false)); });
        // line 30
        $context["destructiveActions"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, (isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 30, $this->source); })()), function ($__a__) use ($context, $macros) { $context["a"] = $__a__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["a"] ?? null), "destructive", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["a"] ?? null), "destructive", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["a"] ?? null), "destructive", [])) : (false)); });
        // line 31
        echo "
<div class=\"menu\" data-align=\"right\">
    ";
        // line 33
        if ((isset($context["safeActions"]) || array_key_exists("safeActions", $context) ? $context["safeActions"] : (function () { throw new RuntimeError('Variable "safeActions" does not exist.', 33, $this->source); })())) {
            // line 34
            echo "        ";
            echo twig_call_macro($macros["_self"], "macro_actionList", [(isset($context["safeActions"]) || array_key_exists("safeActions", $context) ? $context["safeActions"] : (function () { throw new RuntimeError('Variable "safeActions" does not exist.', 34, $this->source); })()), false], 34, $context, $this->getSourceContext());
            echo "
    ";
        }
        // line 36
        echo "    ";
        if (((isset($context["safeActions"]) || array_key_exists("safeActions", $context) ? $context["safeActions"] : (function () { throw new RuntimeError('Variable "safeActions" does not exist.', 36, $this->source); })()) && (isset($context["destructiveActions"]) || array_key_exists("destructiveActions", $context) ? $context["destructiveActions"] : (function () { throw new RuntimeError('Variable "destructiveActions" does not exist.', 36, $this->source); })()))) {
            // line 37
            echo "        <hr>
    ";
        }
        // line 39
        echo "    ";
        if ((isset($context["destructiveActions"]) || array_key_exists("destructiveActions", $context) ? $context["destructiveActions"] : (function () { throw new RuntimeError('Variable "destructiveActions" does not exist.', 39, $this->source); })())) {
            // line 40
            echo "        ";
            echo twig_call_macro($macros["_self"], "macro_actionList", [(isset($context["destructiveActions"]) || array_key_exists("destructiveActions", $context) ? $context["destructiveActions"] : (function () { throw new RuntimeError('Variable "destructiveActions" does not exist.', 40, $this->source); })()), true], 40, $context, $this->getSourceContext());
            echo "
    ";
        }
        // line 42
        echo "</div>
";
        craft\helpers\Template::endProfile("template", "_layouts/components/form-action-menu");
    }

    // line 1
    public function macro_actionList($__actions__ = null, $__destructive__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "actions" => $__actions__,
            "destructive" => $__destructive__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "actionList");
            // line 2
            echo "    ";
            $macros["forms"] = $this->loadTemplate("_includes/forms", "_layouts/components/form-action-menu", 2)->unwrap();
            // line 3
            echo "    <ul>
        ";
            // line 4
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["actions"]) || array_key_exists("actions", $context) ? $context["actions"] : (function () { throw new RuntimeError('Variable "actions" does not exist.', 4, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["action"]) {
                // line 5
                echo "            <li>
                ";
                // line 6
                $context["linkAttributes"] = ["class" => [0 => "formsubmit", 1 => ((((                // line 9
$context["destructive"]) ?? (false))) ? ("error") : (""))], "data" => ["action" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 12
$context["action"], "action", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "action", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "action", [])) : (false)), "redirect" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 13
$context["action"], "redirect", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "redirect", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "redirect", [])) : (false)), "confirm" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 14
$context["action"], "confirm", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "confirm", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "confirm", [])) : (false)), "params" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 15
$context["action"], "params", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "params", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "params", [])) : (false))]];
                // line 18
                echo "                <a ";
                echo craft\helpers\Html::renderTagAttributes((isset($context["linkAttributes"]) || array_key_exists("linkAttributes", $context) ? $context["linkAttributes"] : (function () { throw new RuntimeError('Variable "linkAttributes" does not exist.', 18, $this->source); })()));
                echo ">
                    ";
                // line 19
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "shortcut", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "shortcut", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "shortcut", [])) : (false))) {
                    // line 20
                    echo "                        ";
                    echo twig_call_macro($macros["forms"], "macro_optionShortcutLabel", ["S", (((craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "shift", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "shift", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "shift", [])) : (false))], 20, $context, $this->getSourceContext());
                    echo "
                    ";
                }
                // line 22
                echo "                    ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "label", []), "html", null, true);
                echo "
                </a>
            </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['action'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "    </ul>
";
            craft\helpers\Template::endProfile("macro", "actionList");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_layouts/components/form-action-menu";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 26,  128 => 22,  122 => 20,  120 => 19,  115 => 18,  113 => 15,  112 => 14,  111 => 13,  110 => 12,  109 => 9,  108 => 6,  105 => 5,  101 => 4,  98 => 3,  95 => 2,  80 => 1,  74 => 42,  68 => 40,  65 => 39,  61 => 37,  58 => 36,  52 => 34,  50 => 33,  46 => 31,  44 => 30,  42 => 29,  39 => 28,);
    }

    public function getSourceContext()
    {
        return new Source("{% macro actionList(actions, destructive) %}
    {% import '_includes/forms' as forms %}
    <ul>
        {% for action in actions %}
            <li>
                {% set linkAttributes = {
                    class: [
                        'formsubmit',
                        (destructive ?? false) ? 'error',
                    ],
                    data: {
                        action: action.action ?? false,
                        redirect: action.redirect ?? false,
                        confirm: action.confirm ?? false,
                        params: action.params ?? false
                    }
                } %}
                <a {{ attr(linkAttributes) }}>
                    {% if action.shortcut ?? false %}
                        {{ forms.optionShortcutLabel('S', action.shift ?? false) }}
                    {% endif %}
                    {{ action.label }}
                </a>
            </li>
        {% endfor %}
    </ul>
{% endmacro %}

{% set safeActions = formActions|filter(a => not (a.destructive ?? false)) %}
{% set destructiveActions = formActions|filter(a => a.destructive ?? false) %}

<div class=\"menu\" data-align=\"right\">
    {% if safeActions %}
        {{ _self.actionList(safeActions, false) }}
    {% endif %}
    {% if safeActions and destructiveActions %}
        <hr>
    {% endif %}
    {% if destructiveActions %}
        {{ _self.actionList(destructiveActions, true) }}
    {% endif %}
</div>
", "_layouts/components/form-action-menu", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_layouts/components/form-action-menu.twig");
    }
}

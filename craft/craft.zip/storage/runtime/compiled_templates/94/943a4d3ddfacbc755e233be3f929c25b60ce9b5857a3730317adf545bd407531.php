<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* entries/_edit */
class __TwigTemplate_335832d83c7031a2b29531fba6d43bd1c9d35c89b88fb70b08c38abdd65056cf extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'settings' => [$this, 'block_settings'],
            'meta' => [$this, 'block_meta'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/element";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "entries/_edit");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "entries/_edit", 2)->unwrap();
        // line 4
        $context["isSingle"] = (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 4, $this->source); })()), "type", []) == "single");
        // line 5
        $context["isDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 5, $this->source); })()), "getIsDraft", [], "method");
        // line 6
        $context["isRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 6, $this->source); })()), "getIsRevision", [], "method");
        // line 8
        $context["element"] = (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 8, $this->source); })());
        // line 9
        $context["hasRevisions"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 9, $this->source); })()), "enableVersioning", []);
        // line 10
        $context["redirectUrl"] = ("entries/" . (((isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 10, $this->source); })())) ? ("singles") : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 10, $this->source); })()), "handle", []))));
        // line 11
        $context["saveSourceAction"] = "entries/save-entry";
        // line 12
        $context["duplicateSourceAction"] = "entries/duplicate-entry";
        // line 13
        $context["deleteSourceAction"] = "entries/delete-entry";
        // line 14
        $context["saveDraftAction"] = "entry-revisions/save-draft";
        // line 15
        $context["deleteDraftAction"] = "entry-revisions/delete-draft";
        // line 16
        $context["applyDraftAction"] = "entry-revisions/publish-draft";
        // line 17
        $context["revertSourceAction"] = "entry-revisions/revert-entry-to-version";
        // line 18
        $context["canUpdateSource"] = (craft\helpers\Template::attribute($this->env, $this->source,         // line 19
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 19, $this->source); })()), "can", [0 => ("publishEntries" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 19, $this->source); })()))], "method") && ((        // line 20
(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 20, $this->source); })()) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 20, $this->source); })()), "authorId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 20, $this->source); })()), "id", []))) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 20, $this->source); })()), "can", [0 => ("publishPeerEntries" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 20, $this->source); })()))], "method")));
        // line 22
        $context["canDuplicateSource"] = ((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 22, $this->source); })()) &&  !(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 22, $this->source); })()));
        // line 23
        $context["canDeleteDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 23, $this->source); })()), "can", [0 => ("deletePeerEntryDrafts" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 23, $this->source); })()))], "method");
        // line 25
        if (( !(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 25, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 25, $this->source); })()))) {
            // line 26
            $context["nextEntryParams"] = [0 => ("siteId=" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 26, $this->source); })()), "siteId", []))];
            // line 27
            if ((isset($context["showEntryTypes"]) || array_key_exists("showEntryTypes", $context) ? $context["showEntryTypes"] : (function () { throw new RuntimeError('Variable "showEntryTypes" does not exist.', 27, $this->source); })())) {
                // line 28
                $context["nextEntryParams"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["nextEntryParams"]) || array_key_exists("nextEntryParams", $context) ? $context["nextEntryParams"] : (function () { throw new RuntimeError('Variable "nextEntryParams" does not exist.', 28, $this->source); })()), [0 => "typeId={type.id}"]);
            }
            // line 30
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 30, $this->source); })()), "type", []) == "structure")) {
                // line 31
                $context["nextEntryParams"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["nextEntryParams"]) || array_key_exists("nextEntryParams", $context) ? $context["nextEntryParams"] : (function () { throw new RuntimeError('Variable "nextEntryParams" does not exist.', 31, $this->source); })()), [0 => "parentId={parent.id}"]);
            }
            // line 33
            $context["canDuplicateSource"] = true;
            // line 34
            $context["canAddAnother"] = true;
            // line 35
            $context["addAnotherRedirectUrl"] = ((("entries/" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 35, $this->source); })()), "handle", [])) . "/new?") . twig_join_filter((isset($context["nextEntryParams"]) || array_key_exists("nextEntryParams", $context) ? $context["nextEntryParams"] : (function () { throw new RuntimeError('Variable "nextEntryParams" does not exist.', 35, $this->source); })()), "&"));
        }
        // line 39
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit", $context);

        // line 148
        if (( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 148, $this->source); })()), "slug", []) || twig_in_filter("__temp_", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 148, $this->source); })()), "slug", [])))) {
            // line 149
            ob_start();
            // line 150
            echo "        window.slugGenerator = new Craft.SlugGenerator('#title', '#slug', {
            charMap: ";
            // line 151
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 151, $this->source); })()), "cp", []), "getAsciiCharMap", [0 => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 151, $this->source); })()), "site", []), "language", [])], "method"));
            echo "
        });
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/element", "entries/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "entries/_edit");
    }

    // line 42
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 43
        echo "    ";
        echo craft\helpers\Html::hiddenInput("sectionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 43, $this->source); })()), "id", []));
        echo "
    ";
        // line 44
        $this->displayParentBlock("content", $context, $blocks);
        echo "

    ";
        // line 47
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit.content", $context);

        craft\helpers\Template::endProfile("block", "content");
    }

    // line 50
    public function block_settings($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "settings");
        // line 51
        echo "    ";
        if ( !(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 51, $this->source); })())) {
            // line 52
            echo "        ";
            if ((isset($context["showEntryTypes"]) || array_key_exists("showEntryTypes", $context) ? $context["showEntryTypes"] : (function () { throw new RuntimeError('Variable "showEntryTypes" does not exist.', 52, $this->source); })())) {
                // line 53
                echo "            ";
                echo twig_call_macro($macros["forms"], "macro_selectField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 54
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 54, $this->source); })()), "getAttributeStatus", [0 => "typeId"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry Type", "app"), "id" => "entryType", "name" => "typeId", "value" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 58
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 58, $this->source); })()), "id", []), "options" =>                 // line 59
(isset($context["entryTypeOptions"]) || array_key_exists("entryTypeOptions", $context) ? $context["entryTypeOptions"] : (function () { throw new RuntimeError('Variable "entryTypeOptions" does not exist.', 59, $this->source); })())]], 53, $context, $this->getSourceContext());
                // line 60
                echo "
        ";
            }
            // line 62
            echo "    ";
        }
        // line 63
        echo "
        ";
        // line 64
        echo twig_call_macro($macros["forms"], "macro_textField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,         // line 65
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 65, $this->source); })()), "getAttributeStatus", [0 => "slug"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Slug", "app"), "siteId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 67
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 67, $this->source); })()), "siteId", []), "translationDescription" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site.", "app"), "id" => "slug", "name" => "slug", "autocorrect" => false, "autocapitalize" => false, "value" => ((twig_in_filter("__temp_", craft\helpers\Template::attribute($this->env, $this->source,         // line 73
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 73, $this->source); })()), "slug", []))) ? ("") : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 73, $this->source); })()), "slug", []))), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enter slug", "app"), "errors" => (( !        // line 75
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 75, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 75, $this->source); })()), "getErrors", [0 => "slug"], "method"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 75, $this->source); })()), "getErrors", [0 => "uri"], "method"))) : ("")), "disabled" =>         // line 76
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 76, $this->source); })())]], 64, $context, $this->getSourceContext());
        // line 77
        echo "

    ";
        // line 79
        if ( !(isset($context["isSingle"]) || array_key_exists("isSingle", $context) ? $context["isSingle"] : (function () { throw new RuntimeError('Variable "isSingle" does not exist.', 79, $this->source); })())) {
            // line 80
            echo "        ";
            if ((isset($context["parentOptionCriteria"]) || array_key_exists("parentOptionCriteria", $context))) {
                // line 81
                echo "            ";
                echo twig_call_macro($macros["forms"], "macro_elementSelectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Parent", "app"), "id" => "parentId", "name" => "parentId", "elementType" =>                 // line 85
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 85, $this->source); })()), "selectionLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"), "sources" => [0 => ("section:" . craft\helpers\Template::attribute($this->env, $this->source,                 // line 87
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 87, $this->source); })()), "uid", []))], "criteria" =>                 // line 88
(isset($context["parentOptionCriteria"]) || array_key_exists("parentOptionCriteria", $context) ? $context["parentOptionCriteria"] : (function () { throw new RuntimeError('Variable "parentOptionCriteria" does not exist.', 88, $this->source); })()), "limit" => 1, "elements" => (((                // line 90
(isset($context["parent"]) || array_key_exists("parent", $context)) && (isset($context["parent"]) || array_key_exists("parent", $context) ? $context["parent"] : (function () { throw new RuntimeError('Variable "parent" does not exist.', 90, $this->source); })()))) ? ([0 => (isset($context["parent"]) || array_key_exists("parent", $context) ? $context["parent"] : (function () { throw new RuntimeError('Variable "parent" does not exist.', 90, $this->source); })())]) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 91
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 91, $this->source); })()), "getErrors", [0 => "parent"], "method")]], 81, $context, $this->getSourceContext());
                // line 92
                echo "
        ";
            }
            // line 94
            echo "
        ";
            // line 95
            if ((((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 95, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 95, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 95, $this->source); })()), "can", [0 => ("editPeerEntries" . (isset($context["permissionSuffix"]) || array_key_exists("permissionSuffix", $context) ? $context["permissionSuffix"] : (function () { throw new RuntimeError('Variable "permissionSuffix" does not exist.', 95, $this->source); })()))], "method"))) {
                // line 96
                echo "            ";
                echo twig_call_macro($macros["forms"], "macro_elementSelectField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 97
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 97, $this->source); })()), "getAttributeStatus", [0 => "authorId"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Author", "app"), "id" => "author", "name" => "author", "elementType" =>                 // line 101
(isset($context["userElementType"]) || array_key_exists("userElementType", $context) ? $context["userElementType"] : (function () { throw new RuntimeError('Variable "userElementType" does not exist.', 101, $this->source); })()), "selectionLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"), "criteria" =>                 // line 103
(isset($context["authorOptionCriteria"]) || array_key_exists("authorOptionCriteria", $context) ? $context["authorOptionCriteria"] : (function () { throw new RuntimeError('Variable "authorOptionCriteria" does not exist.', 103, $this->source); })()), "limit" => 1, "elements" => (((                // line 105
(isset($context["author"]) || array_key_exists("author", $context)) && (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 105, $this->source); })()))) ? ([0 => (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 105, $this->source); })())]) : (""))]], 96, $context, $this->getSourceContext());
                // line 106
                echo "
        ";
            }
            // line 108
            echo "
        ";
            // line 109
            echo twig_call_macro($macros["forms"], "macro_dateTimeField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 110
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 110, $this->source); })()), "getAttributeStatus", [0 => "postDate"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Post Date", "app"), "id" => "postDate", "name" => "postDate", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 114
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 114, $this->source); })()), "postDate", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 114, $this->source); })()), "postDate", [])) : (null)), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 115
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 115, $this->source); })()), "getErrors", [0 => "postDate"], "method"), "disabled" =>             // line 116
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 116, $this->source); })())]], 109, $context, $this->getSourceContext());
            // line 117
            echo "

        ";
            // line 119
            echo twig_call_macro($macros["forms"], "macro_dateTimeField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 120
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 120, $this->source); })()), "getAttributeStatus", [0 => "expiryDate"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Expiry Date", "app"), "id" => "expiryDate", "name" => "expiryDate", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 124
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 124, $this->source); })()), "expiryDate", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 124, $this->source); })()), "expiryDate", [])) : (null)), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 125
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 125, $this->source); })()), "getErrors", [0 => "expiryDate"], "method"), "disabled" =>             // line 126
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 126, $this->source); })())]], 119, $context, $this->getSourceContext());
            // line 127
            echo "
    ";
        }
        // line 129
        echo "
    ";
        // line 130
        $this->displayParentBlock("settings", $context, $blocks);
        echo "
    ";
        // line 132
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit.settings", $context);

        craft\helpers\Template::endProfile("block", "settings");
    }

    // line 135
    public function block_meta($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "meta");
        // line 136
        echo "    ";
        $this->displayParentBlock("meta", $context, $blocks);
        echo "
    ";
        // line 138
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit.meta", $context);

        craft\helpers\Template::endProfile("block", "meta");
    }

    // line 141
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 142
        echo "    ";
        $this->displayParentBlock("details", $context, $blocks);
        echo "
    ";
        // line 144
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.entries.edit.details", $context);

        craft\helpers\Template::endProfile("block", "details");
    }

    public function getTemplateName()
    {
        return "entries/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  283 => 144,  278 => 142,  273 => 141,  266 => 138,  261 => 136,  256 => 135,  249 => 132,  245 => 130,  242 => 129,  238 => 127,  236 => 126,  235 => 125,  234 => 124,  233 => 120,  232 => 119,  228 => 117,  226 => 116,  225 => 115,  224 => 114,  223 => 110,  222 => 109,  219 => 108,  215 => 106,  213 => 105,  212 => 103,  211 => 101,  210 => 97,  208 => 96,  206 => 95,  203 => 94,  199 => 92,  197 => 91,  196 => 90,  195 => 88,  194 => 87,  193 => 85,  191 => 81,  188 => 80,  186 => 79,  182 => 77,  180 => 76,  179 => 75,  178 => 73,  177 => 67,  176 => 65,  175 => 64,  172 => 63,  169 => 62,  165 => 60,  163 => 59,  162 => 58,  161 => 54,  159 => 53,  156 => 52,  153 => 51,  148 => 50,  141 => 47,  136 => 44,  131 => 43,  126 => 42,  120 => 1,  113 => 151,  110 => 150,  108 => 149,  106 => 148,  103 => 39,  100 => 35,  98 => 34,  96 => 33,  93 => 31,  91 => 30,  88 => 28,  86 => 27,  84 => 26,  82 => 25,  80 => 23,  78 => 22,  76 => 20,  75 => 19,  74 => 18,  72 => 17,  70 => 16,  68 => 15,  66 => 14,  64 => 13,  62 => 12,  60 => 11,  58 => 10,  56 => 9,  54 => 8,  52 => 6,  50 => 5,  48 => 4,  46 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/element\" %}
{% import \"_includes/forms\" as forms %}

{% set isSingle = section.type == 'single' %}
{% set isDraft = entry.getIsDraft() %}
{% set isRevision = entry.getIsRevision() %}

{% set element = entry %}
{% set hasRevisions = section.enableVersioning %}
{% set redirectUrl = 'entries/' ~ (isSingle ? 'singles' : section.handle) %}
{% set saveSourceAction = 'entries/save-entry' %}
{% set duplicateSourceAction = 'entries/duplicate-entry' %}
{% set deleteSourceAction = 'entries/delete-entry' %}
{% set saveDraftAction = 'entry-revisions/save-draft' %}
{% set deleteDraftAction = 'entry-revisions/delete-draft' %}
{% set applyDraftAction = 'entry-revisions/publish-draft' %}
{% set revertSourceAction = 'entry-revisions/revert-entry-to-version' %}
{% set canUpdateSource = (
    currentUser.can('publishEntries'~permissionSuffix) and
    (isSingle or entry.authorId == currentUser.id or currentUser.can('publishPeerEntries'~permissionSuffix))
) %}
{% set canDuplicateSource = canUpdateSource and not isSingle %}
{% set canDeleteDraft = currentUser.can('deletePeerEntryDrafts'~permissionSuffix) %}

{% if not isSingle and canUpdateSource %}
    {% set nextEntryParams = [\"siteId=#{entry.siteId}\"] %}
    {% if showEntryTypes %}
        {% set nextEntryParams = nextEntryParams|merge(['typeId={type.id}']) %}
    {% endif %}
    {% if section.type == 'structure' %}
        {% set nextEntryParams = nextEntryParams|merge(['parentId={parent.id}']) %}
    {% endif %}
    {% set canDuplicateSource = true %}
    {% set canAddAnother = true %}
    {% set addAnotherRedirectUrl = \"entries/#{section.handle}/new?\" ~ nextEntryParams|join('&') %}
{% endif %}


{% hook \"cp.entries.edit\" %}


{% block content %}
    {{ hiddenInput('sectionId', section.id) }}
    {{ parent() }}

    {# Give plugins a chance to add other things here #}
    {% hook \"cp.entries.edit.content\" %}
{% endblock %}

{% block settings %}
    {% if not isSingle %}
        {% if showEntryTypes %}
            {{ forms.selectField({
                status: entry.getAttributeStatus('typeId'),
                label: \"Entry Type\"|t('app'),
                id: 'entryType',
                name: 'typeId',
                value: entryType.id,
                options: entryTypeOptions
            }) }}
        {% endif %}
    {% endif %}

        {{ forms.textField({
            status: entry.getAttributeStatus('slug'),
            label: \"Slug\"|t('app'),
            siteId: entry.siteId,
            translationDescription: 'This field is translated for each site.'|t('app'),
            id: 'slug',
            name: 'slug',
            autocorrect: false,
            autocapitalize: false,
            value: '__temp_' in entry.slug ? '' : entry.slug,
            placeholder: \"Enter slug\"|t('app'),
            errors: (not isRevision ? entry.getErrors('slug')|merge(entry.getErrors('uri'))),
            disabled: isRevision
        }) }}

    {% if not isSingle %}
        {% if parentOptionCriteria is defined %}
            {{ forms.elementSelectField({
                label: \"Parent\"|t('app'),
                id: 'parentId',
                name: 'parentId',
                elementType: elementType,
                selectionLabel: \"Choose\"|t('app'),
                sources: ['section:'~section.uid],
                criteria: parentOptionCriteria,
                limit: 1,
                elements: (parent is defined and parent ? [parent]),
                errors: entry.getErrors('parent')
            }) }}
        {% endif %}

        {% if CraftEdition == CraftPro and currentUser.can('editPeerEntries'~permissionSuffix) %}
            {{ forms.elementSelectField({
                status: entry.getAttributeStatus('authorId'),
                label: \"Author\"|t('app'),
                id: 'author',
                name: 'author',
                elementType: userElementType,
                selectionLabel: \"Choose\"|t('app'),
                criteria: authorOptionCriteria,
                limit: 1,
                elements: (author is defined and author ? [author])
            }) }}
        {% endif %}

        {{ forms.dateTimeField({
            status: entry.getAttributeStatus('postDate'),
            label: \"Post Date\"|t('app'),
            id: 'postDate',
            name: 'postDate',
            value: (entry.postDate ? entry.postDate : null),
            errors: entry.getErrors('postDate'),
            disabled: isRevision
        }) }}

        {{ forms.dateTimeField({
            status: entry.getAttributeStatus('expiryDate'),
            label: \"Expiry Date\"|t('app'),
            id: 'expiryDate',
            name: 'expiryDate',
            value: (entry.expiryDate ? entry.expiryDate : null),
            errors: entry.getErrors('expiryDate'),
            disabled: isRevision
        }) }}
    {% endif %}

    {{ parent() }}
    {# Give plugins a chance to add other things here #}
    {% hook \"cp.entries.edit.settings\" %}
{% endblock %}

{% block meta %}
    {{ parent() }}
    {# Give plugins a chance to add other things here #}
    {% hook \"cp.entries.edit.meta\" %}
{% endblock %}

{% block details %}
    {{ parent() }}
    {# Give plugins a chance to add other things here #}
    {% hook \"cp.entries.edit.details\" %}
{% endblock %}


{% if not entry.slug or '__temp_' in entry.slug %}
    {% js %}
        window.slugGenerator = new Craft.SlugGenerator('#title', '#slug', {
            charMap: {{ craft.cp.getAsciiCharMap(entry.site.language)|json_encode|raw }}
        });
    {% endjs %}
{% endif %}
", "entries/_edit", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/entries/_edit.html");
    }
}

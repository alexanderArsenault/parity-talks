<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/select */
class __TwigTemplate_75008d141e9af3cd2791f9410b7b05b5961bc4a2d928596ca69244c81e66d656 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/select");
        // line 1
        $context["class"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "select", 1 => ((((        // line 3
$context["disabled"]) ?? (false))) ? ("disabled") : (""))]));
        // line 6
        $context["options"] = (((isset($context["options"]) || array_key_exists("options", $context))) ? ((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 6, $this->source); })())) : ([]));
        // line 7
        $context["value"] = (((isset($context["value"]) || array_key_exists("value", $context))) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 7, $this->source); })())) : (null));
        // line 8
        $context["hasOptgroups"] = false;
        // line 10
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 11
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 11, $this->source); })())], ((        // line 12
$context["containerAttributes"]) ?? ([])), true);
        // line 14
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 15
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 15, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 17
        echo "
";
        // line 18
        $context["inputAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => ((        // line 19
$context["id"]) ?? (false)), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((((        // line 21
$context["toggle"]) ?? (false))) ? ("fieldtoggle") : (""))]), "name" => ((        // line 23
$context["name"]) ?? (false)), "autofocus" => (((        // line 24
$context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 24, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method")), "disabled" => ((        // line 25
$context["disabled"]) ?? (false)), "data" => ["target-prefix" => ((((        // line 27
$context["toggle"]) ?? (false))) ? ((($context["targetPrefix"]) ?? (""))) : (false))]], ((        // line 29
$context["inputAttributes"]) ?? ([])), true);
        // line 30
        echo "
<div ";
        // line 31
        echo craft\helpers\Html::renderTagAttributes((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 31, $this->source); })()));
        echo ">
    <select ";
        // line 32
        echo craft\helpers\Html::renderTagAttributes((isset($context["inputAttributes"]) || array_key_exists("inputAttributes", $context) ? $context["inputAttributes"] : (function () { throw new RuntimeError('Variable "inputAttributes" does not exist.', 32, $this->source); })()));
        echo ">
        ";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 33, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["option"]) {
            // line 34
            echo "            ";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "optgroup", [], "any", true, true)) {
                // line 35
                echo "                ";
                if ((isset($context["hasOptgroups"]) || array_key_exists("hasOptgroups", $context) ? $context["hasOptgroups"] : (function () { throw new RuntimeError('Variable "hasOptgroups" does not exist.', 35, $this->source); })())) {
                    // line 36
                    echo "                    </optgroup>
                ";
                } else {
                    // line 38
                    echo "                    ";
                    $context["hasOptgroups"] = true;
                    // line 39
                    echo "                ";
                }
                // line 40
                echo "                <optgroup label=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "optgroup", []), "html", null, true);
                echo "\">
            ";
            } else {
                // line 42
                echo "                ";
                $context["optionLabel"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "label", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "label", [])) : ($context["option"]));
                // line 43
                echo "                ";
                $context["optionValue"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", [])) : ($context["key"]));
                // line 44
                echo "                ";
                $context["optionDisabled"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "disabled", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "disabled", [])) : (false));
                // line 45
                echo "                <option value=\"";
                echo twig_escape_filter($this->env, (isset($context["optionValue"]) || array_key_exists("optionValue", $context) ? $context["optionValue"] : (function () { throw new RuntimeError('Variable "optionValue" does not exist.', 45, $this->source); })()), "html", null, true);
                echo "\"";
                if ((((isset($context["optionValue"]) || array_key_exists("optionValue", $context) ? $context["optionValue"] : (function () { throw new RuntimeError('Variable "optionValue" does not exist.', 45, $this->source); })()) . "") === ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 45, $this->source); })()) . ""))) {
                    echo " selected";
                }
                if ((isset($context["optionDisabled"]) || array_key_exists("optionDisabled", $context) ? $context["optionDisabled"] : (function () { throw new RuntimeError('Variable "optionDisabled" does not exist.', 45, $this->source); })())) {
                    echo " disabled";
                }
                echo ">";
                echo twig_escape_filter($this->env, (isset($context["optionLabel"]) || array_key_exists("optionLabel", $context) ? $context["optionLabel"] : (function () { throw new RuntimeError('Variable "optionLabel" does not exist.', 45, $this->source); })()), "html", null, true);
                echo "</option>
            ";
            }
            // line 47
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "        ";
        if ((isset($context["hasOptgroups"]) || array_key_exists("hasOptgroups", $context) ? $context["hasOptgroups"] : (function () { throw new RuntimeError('Variable "hasOptgroups" does not exist.', 48, $this->source); })())) {
            // line 49
            echo "            </optgroup>
        ";
        }
        // line 51
        echo "    </select>
</div>
";
        craft\helpers\Template::endProfile("template", "_includes/forms/select");
    }

    public function getTemplateName()
    {
        return "_includes/forms/select";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 51,  138 => 49,  135 => 48,  129 => 47,  114 => 45,  111 => 44,  108 => 43,  105 => 42,  99 => 40,  96 => 39,  93 => 38,  89 => 36,  86 => 35,  83 => 34,  79 => 33,  75 => 32,  71 => 31,  68 => 30,  66 => 29,  65 => 27,  64 => 25,  63 => 24,  62 => 23,  61 => 21,  60 => 19,  59 => 18,  56 => 17,  53 => 15,  51 => 14,  49 => 12,  48 => 11,  47 => 10,  45 => 8,  43 => 7,  41 => 6,  39 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set class = (class ?? [])|explodeClass|merge([
    'select',
    (disabled ?? false) ? 'disabled',
]|filter) %}

{%- set options = (options is defined ? options : []) %}
{%- set value = (value is defined ? value : null) %}
{%- set hasOptgroups = false -%}

{%- set containerAttributes = {
  class: class,
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
  {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% set inputAttributes = {
  id: id ?? false,
  class: [
    (toggle ?? false) ? 'fieldtoggle'
  ]|filter,
  name: name ?? false,
  autofocus: (autofocus ?? false) and not craft.app.request.isMobileBrowser(true),
  disabled: disabled ?? false,
  data: {
    'target-prefix': (toggle ?? false) ? (targetPrefix ?? '') : false,
  },
}|merge(inputAttributes ?? [], recursive=true) %}

<div {{ attr(containerAttributes) }}>
    <select {{ attr(inputAttributes) }}>
        {% for key, option in options %}
            {% if option.optgroup is defined %}
                {% if hasOptgroups %}
                    </optgroup>
                {% else %}
                    {% set hasOptgroups = true %}
                {% endif %}
                <optgroup label=\"{{ option.optgroup }}\">
            {% else %}
                {% set optionLabel = (option.label is defined ? option.label : option) %}
                {% set optionValue = (option.value is defined ? option.value : key) %}
                {% set optionDisabled = (option.disabled is defined ? option.disabled : false) %}
                <option value=\"{{ optionValue }}\"{% if (optionValue~'') is same as (value~'') %} selected{% endif %}{% if optionDisabled %} disabled{% endif %}>{{ optionLabel }}</option>
            {% endif %}
        {% endfor %}
        {% if hasOptgroups %}
            </optgroup>
        {% endif %}
    </select>
</div>
", "_includes/forms/select", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/forms/select.html");
    }
}

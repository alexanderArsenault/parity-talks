<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/field */
class __TwigTemplate_33f1f46dd2994a4b5a60b110d288f009e1b33e80746c0ae627c7929c47fb3626 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/field");
        // line 1
        $context["fieldId"] = (($context["fieldId"]) ?? ((((($context["id"]) ?? (false))) ? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 1, $this->source); })()) . "-field")) : (("field" . twig_random($this->env))))));
        // line 2
        $context["labelId"] = (($context["labelId"]) ?? (((isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 2, $this->source); })()) . "-label")));
        // line 3
        $context["instructionsId"] = (($context["instructionsId"]) ?? (((isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 3, $this->source); })()) . "-instructions")));
        // line 4
        $context["status"] = (($context["status"]) ?? (null));
        // line 5
        $context["label"] = ((((isset($context["label"]) || array_key_exists("label", $context)) && ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 5, $this->source); })()) != "__blank__"))) ? ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 5, $this->source); })())) : (((        $this->hasBlock("label", $context, $blocks)) ? (        $this->renderBlock("label", $context, $blocks)) : (null))));
        // line 6
        $context["siteId"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", []), "getIsMultiSite", [], "method") && (isset($context["siteId"]) || array_key_exists("siteId", $context)))) ? ((isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 6, $this->source); })())) : (null));
        // line 7
        $context["site"] = (((isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 7, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "app", []), "sites", []), "getSiteById", [0 => (isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 7, $this->source); })())], "method")) : (null));
        // line 8
        $context["required"] = (($context["required"]) ?? (false));
        // line 9
        $context["instructions"] = (($context["instructions"]) ?? (((        $this->hasBlock("instructions", $context, $blocks)) ? (        $this->renderBlock("instructions", $context, $blocks)) : (null))));
        // line 10
        $context["tip"] = (($context["tip"]) ?? (((        $this->hasBlock("tip", $context, $blocks)) ? (        $this->renderBlock("tip", $context, $blocks)) : (null))));
        // line 11
        $context["warning"] = (($context["warning"]) ?? (((        $this->hasBlock("warning", $context, $blocks)) ? (        $this->renderBlock("warning", $context, $blocks)) : (null))));
        // line 12
        $context["orientation"] = (($context["orientation"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, (((isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 12, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 12, $this->source); })()), "getLocale", [], "method")) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "app", []), "locale", []))), "getOrientation", [], "method")));
        // line 13
        $context["translatable"] = (($context["translatable"]) ?? ( !((isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 13, $this->source); })()) === null)));
        // line 14
        $context["errors"] = (((isset($context["errors"]) || array_key_exists("errors", $context))) ? ((isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 14, $this->source); })())) : (null));
        // line 15
        $context["fieldClass"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["fieldClass"]) ?? ([]))), [0 => "field", 1 => (((        // line 17
(isset($context["first"]) || array_key_exists("first", $context)) && (isset($context["first"]) || array_key_exists("first", $context) ? $context["first"] : (function () { throw new RuntimeError('Variable "first" does not exist.', 17, $this->source); })()))) ? ("first") : (null)), 2 => ((        // line 18
(isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 18, $this->source); })())) ? ("has-errors") : (null))]));
        // line 20
        $context["showAttribute"] = (((($context["attribute"]) ?? (false)) && (((craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "admin", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "admin", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentUser"] ?? null), "admin", [])) : (false))) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 20, $this->source); })()), "getPreference", [0 => "showFieldHandles"], "method"));
        // line 23
        $context["fieldAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 24
(isset($context["fieldClass"]) || array_key_exists("fieldClass", $context) ? $context["fieldClass"] : (function () { throw new RuntimeError('Variable "fieldClass" does not exist.', 24, $this->source); })()), "id" =>         // line 25
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 25, $this->source); })()), "aria" => ["describedby" => ((        // line 27
(isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 27, $this->source); })())) ? ((isset($context["instructionsId"]) || array_key_exists("instructionsId", $context) ? $context["instructionsId"] : (function () { throw new RuntimeError('Variable "instructionsId" does not exist.', 27, $this->source); })())) : (false))]], ((        // line 29
$context["fieldAttributes"]) ?? ([])), true);
        // line 31
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 32
            $context["fieldAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["fieldAttributes"]) || array_key_exists("fieldAttributes", $context) ? $context["fieldAttributes"] : (function () { throw new RuntimeError('Variable "fieldAttributes" does not exist.', 32, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 35
        $context["inputContainerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "input", 1 =>         // line 36
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 36, $this->source); })()), 2 => (((isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 36, $this->source); })())) ? ("errors") : (""))])], ((        // line 37
$context["inputContainerAttributes"]) ?? ([])), true);
        // line 38
        echo "
<div ";
        // line 39
        echo craft\helpers\Html::renderTagAttributes((isset($context["fieldAttributes"]) || array_key_exists("fieldAttributes", $context) ? $context["fieldAttributes"] : (function () { throw new RuntimeError('Variable "fieldAttributes" does not exist.', 39, $this->source); })()));
        echo ">
    ";
        // line 40
        if ((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 40, $this->source); })())) {
            // line 41
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => [0 => "status-badge", 1 => craft\helpers\Template::attribute($this->env, $this->source,             // line 42
(isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 42, $this->source); })()), 0, [], "array")], "text" => twig_upper_filter($this->env, twig_slice($this->env, craft\helpers\Template::attribute($this->env, $this->source,             // line 43
(isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 43, $this->source); })()), 1, [], "array"), 0, 1)), "title" => craft\helpers\Template::attribute($this->env, $this->source,             // line 44
(isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 44, $this->source); })()), 1, [], "array")]);
            // line 45
            echo "
    ";
        }
        // line 47
        echo "    ";
        if (((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 47, $this->source); })()) || (isset($context["showAttribute"]) || array_key_exists("showAttribute", $context) ? $context["showAttribute"] : (function () { throw new RuntimeError('Variable "showAttribute" does not exist.', 47, $this->source); })()))) {
            // line 48
            echo "        <div class=\"heading\">
            ";
            // line 49
            $this->displayBlock('heading', $context, $blocks);
            // line 76
            echo "        </div>
    ";
        }
        // line 78
        echo "    ";
        if ((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 78, $this->source); })())) {
            // line 79
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["id" =>             // line 80
(isset($context["instructionsId"]) || array_key_exists("instructionsId", $context) ? $context["instructionsId"] : (function () { throw new RuntimeError('Variable "instructionsId" does not exist.', 80, $this->source); })()), "class" => [0 => "instructions"], "html" => $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter(            // line 82
(isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 82, $this->source); })()), "gfm-comment"), "/&amp;(\\w+);/", "&\$1;")]);
            // line 83
            echo "
    ";
        }
        // line 85
        echo "    <div ";
        echo craft\helpers\Html::renderTagAttributes((isset($context["inputContainerAttributes"]) || array_key_exists("inputContainerAttributes", $context) ? $context["inputContainerAttributes"] : (function () { throw new RuntimeError('Variable "inputContainerAttributes" does not exist.', 85, $this->source); })()));
        echo ">
        ";
        // line 86
        $this->displayBlock('input', $context, $blocks);
        // line 89
        echo "    </div>
    ";
        // line 90
        if ((isset($context["tip"]) || array_key_exists("tip", $context) ? $context["tip"] : (function () { throw new RuntimeError('Variable "tip" does not exist.', 90, $this->source); })())) {
            // line 91
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("p", ["class" => [0 => "notice", 1 => "with-icon"], "html" => $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter(            // line 93
(isset($context["tip"]) || array_key_exists("tip", $context) ? $context["tip"] : (function () { throw new RuntimeError('Variable "tip" does not exist.', 93, $this->source); })()), null, true), "/&amp;(\\w+);/", "&\$1;")]);
            // line 94
            echo "
    ";
        }
        // line 96
        echo "    ";
        if ((isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 96, $this->source); })())) {
            // line 97
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("p", ["class" => [0 => "warning", 1 => "with-icon"], "html" => $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter(            // line 99
(isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 99, $this->source); })()), null, true), "/&amp;(\\w+);/", "&\$1;")]);
            // line 100
            echo "
    ";
        }
        // line 102
        echo "    ";
        $this->loadTemplate("_includes/forms/errorList", "_includes/forms/field", 102)->display(twig_array_merge($context, ["errors" => (isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 102, $this->source); })())]));
        // line 103
        echo "</div>
";
        craft\helpers\Template::endProfile("template", "_includes/forms/field");
    }

    // line 49
    public function block_heading($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "heading");
        // line 50
        echo "                ";
        if ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 50, $this->source); })())) {
            // line 51
            echo "                    ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("label", $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" =>             // line 52
(isset($context["labelId"]) || array_key_exists("labelId", $context) ? $context["labelId"] : (function () { throw new RuntimeError('Variable "labelId" does not exist.', 52, $this->source); })()), "class" => ((            // line 53
(isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 53, $this->source); })())) ? ([0 => "required"]) : ([])), "for" => ((            // line 54
$context["id"]) ?? (null)), "html" =>             // line 55
(isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 55, $this->source); })())], ((            // line 56
$context["labelAttributes"]) ?? ([])), true));
            // line 57
            if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new RuntimeError('Variable "translatable" does not exist.', 57, $this->source); })())) {
                // line 58
                echo "                        ";
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => "t9n-indicator", "data" => ["icon" => "language"], "title" => ((                // line 63
$context["translationDescription"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("This field is translatable.", "app")))]);
                // line 64
                echo "
                    ";
            }
        }
        // line 67
        echo "                ";
        if ((isset($context["showAttribute"]) || array_key_exists("showAttribute", $context) ? $context["showAttribute"] : (function () { throw new RuntimeError('Variable "showAttribute" does not exist.', 67, $this->source); })())) {
            // line 68
            echo "                    <div class=\"flex-grow\"></div>
                    ";
            // line 69
            $this->loadTemplate("_includes/forms/copytextbtn", "_includes/forms/field", 69)->display(twig_to_array(["id" => (            // line 70
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 70, $this->source); })()) . "-attribute"), "class" => [0 => "code", 1 => "small", 2 => "light"], "value" =>             // line 72
(isset($context["attribute"]) || array_key_exists("attribute", $context) ? $context["attribute"] : (function () { throw new RuntimeError('Variable "attribute" does not exist.', 72, $this->source); })())]));
            // line 74
            echo "                ";
        }
        // line 75
        echo "            ";
        craft\helpers\Template::endProfile("block", "heading");
    }

    // line 86
    public function block_input($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "input");
        // line 87
        echo "            ";
        echo (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 87, $this->source); })());
        echo "
        ";
        craft\helpers\Template::endProfile("block", "input");
    }

    public function getTemplateName()
    {
        return "_includes/forms/field";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  222 => 87,  217 => 86,  212 => 75,  209 => 74,  207 => 72,  206 => 70,  205 => 69,  202 => 68,  199 => 67,  194 => 64,  192 => 63,  190 => 58,  188 => 57,  186 => 56,  185 => 55,  184 => 54,  183 => 53,  182 => 52,  180 => 51,  177 => 50,  172 => 49,  166 => 103,  163 => 102,  159 => 100,  157 => 99,  155 => 97,  152 => 96,  148 => 94,  146 => 93,  144 => 91,  142 => 90,  139 => 89,  137 => 86,  132 => 85,  128 => 83,  126 => 82,  125 => 80,  123 => 79,  120 => 78,  116 => 76,  114 => 49,  111 => 48,  108 => 47,  104 => 45,  102 => 44,  101 => 43,  100 => 42,  98 => 41,  96 => 40,  92 => 39,  89 => 38,  87 => 37,  86 => 36,  85 => 35,  82 => 32,  80 => 31,  78 => 29,  77 => 27,  76 => 25,  75 => 24,  74 => 23,  72 => 20,  70 => 18,  69 => 17,  68 => 15,  66 => 14,  64 => 13,  62 => 12,  60 => 11,  58 => 10,  56 => 9,  54 => 8,  52 => 7,  50 => 6,  48 => 5,  46 => 4,  44 => 3,  42 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set fieldId = fieldId ?? ((id ?? false) ? \"#{id}-field\" : \"field#{random()}\") %}
{%- set labelId = labelId ?? \"#{fieldId}-label\" %}
{%- set instructionsId = instructionsId ?? \"#{fieldId}-instructions\"  %}
{%- set status = status ?? null %}
{%- set label = label is defined and label != '__blank__' ? label : (block('label') ?? null) %}
{%- set siteId = ((craft.app.getIsMultiSite() and siteId is defined) ? siteId : null) %}
{%- set site = (siteId ? craft.app.sites.getSiteById(siteId) : null) %}
{%- set required = required ?? false %}
{%- set instructions = instructions ?? block('instructions') ?? null %}
{%- set tip = tip ?? block('tip') ?? null %}
{%- set warning = warning ?? block('warning') ?? null %}
{%- set orientation = orientation ?? (site ? site.getLocale() : craft.app.locale).getOrientation() %}
{%- set translatable = translatable ?? (site is not same as(null)) %}
{%- set errors = (errors is defined ? errors : null) -%}
{%- set fieldClass = (fieldClass ?? [])|explodeClass|merge([
    'field',
    (first is defined and first ? 'first' : null),
    (errors ? 'has-errors' : null),
])|filter %}
{%- set showAttribute = (attribute ?? false) and (currentUser.admin ?? false) and currentUser.getPreference('showFieldHandles') %}


{%- set fieldAttributes = {
    class: fieldClass,
    id: fieldId,
    aria: {
        describedby: instructions ? instructionsId : false,
    }
}|merge(fieldAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set fieldAttributes = fieldAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{%- set inputContainerAttributes = {
    class: ['input', orientation, errors ? 'errors']|filter,
}|merge(inputContainerAttributes ?? [], recursive=true) %}

<div {{ attr(fieldAttributes) }}>
    {% if status %}
        {{ tag('div', {
            class: ['status-badge', status[0]],
            text: status[1][0:1]|upper,
            title: status[1],
        }) }}
    {% endif %}
    {% if label or showAttribute %}
        <div class=\"heading\">
            {% block heading %}
                {% if label %}
                    {{ tag('label', {
                        id: labelId,
                        class: required ? ['required'] : [],
                        for: id ?? null,
                        html: label,
                    }|merge(labelAttributes ?? [], recursive=true)) }}
                    {%- if translatable %}
                        {{ tag('div', {
                            class: 't9n-indicator',
                            data: {
                                icon: 'language',
                            },
                            title: translationDescription ?? 'This field is translatable.'|t('app'),
                        }) }}
                    {% endif -%}
                {% endif %}
                {% if showAttribute %}
                    <div class=\"flex-grow\"></div>
                    {% include '_includes/forms/copytextbtn' with {
                        id: \"#{fieldId}-attribute\",
                        class: ['code', 'small', 'light'],
                        value: attribute,
                    } only %}
                {% endif %}
            {% endblock %}
        </div>
    {% endif %}
    {% if instructions %}
        {{ tag('div', {
            id: instructionsId,
            class: ['instructions'],
            html: instructions|md('gfm-comment')|replace('/&amp;(\\\\w+);/', '&\$1;'),
        }) }}
    {% endif %}
    <div {{ attr(inputContainerAttributes) }}>
        {% block input %}
            {{ input|raw }}
        {% endblock %}
    </div>
    {% if tip %}
        {{ tag('p', {
            class: ['notice', 'with-icon'],
            html: tip|md(inlineOnly=true)|replace('/&amp;(\\\\w+);/', '&\$1;'),
        }) }}
    {% endif %}
    {% if warning %}
        {{ tag('p', {
            class: ['warning', 'with-icon'],
            html: warning|md(inlineOnly=true)|replace('/&amp;(\\\\w+);/', '&\$1;'),
        }) }}
    {% endif %}
    {% include \"_includes/forms/errorList\" with { errors: errors } %}
</div>
", "_includes/forms/field", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/forms/field.html");
    }
}

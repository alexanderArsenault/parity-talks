<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__8b22e3d0eb5d2aa17c4d3cc24d2481924c1d4b66f79f0f8491e1457506cfabb7 */
class __TwigTemplate_e1ef8ba4a1ffeea1a80765e97e20d315b1eeb4a19102948d92e990499ae92ed1 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__8b22e3d0eb5d2aa17c4d3cc24d2481924c1d4b66f79f0f8491e1457506cfabb7");
        // line 1
        echo "artists/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        craft\helpers\Template::endProfile("template", "__string_template__8b22e3d0eb5d2aa17c4d3cc24d2481924c1d4b66f79f0f8491e1457506cfabb7");
    }

    public function getTemplateName()
    {
        return "__string_template__8b22e3d0eb5d2aa17c4d3cc24d2481924c1d4b66f79f0f8491e1457506cfabb7";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("artists/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__8b22e3d0eb5d2aa17c4d3cc24d2481924c1d4b66f79f0f8491e1457506cfabb7", "");
    }
}

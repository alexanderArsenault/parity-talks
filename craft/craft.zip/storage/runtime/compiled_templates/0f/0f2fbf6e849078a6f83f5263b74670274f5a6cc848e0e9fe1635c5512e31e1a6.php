<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* program/_artist */
class __TwigTemplate_76c75490909a6e7cd8c83acdb6fde033a2ef5a886e94188f7502f26eef7e50b4 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "program/_artist");
        $this->parent = $this->loadTemplate("_layout", "program/_artist", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "program/_artist");
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 4
        echo "
";
        // line 5
        $context["image"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method")) : (null));
        // line 6
        $context["Twitter"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkTwitter", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkTwitter", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkTwitter", [])) : (null));
        // line 7
        $context["website"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkWebsite", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkWebsite", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkWebsite", [])) : (null));
        // line 8
        $context["Instagram"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkInstagram", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkInstagram", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkInstagram", [])) : (null));
        // line 9
        $context["Facebook"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkFacebook", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkFacebook", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkFacebook", [])) : (null));
        // line 10
        $context["Youtube"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkYoutube", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkYoutube", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkYoutube", [])) : (null));
        // line 11
        $context["Vimeo"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkVimeo", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkVimeo", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkVimeo", [])) : (null));
        // line 12
        $context["Soundcloud"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkSoundcloud", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkSoundcloud", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkSoundcloud", [])) : (null));
        // line 13
        $context["Spotify"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkSpotify", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkSpotify", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "artistLinkSpotify", [])) : (null));
        // line 14
        echo "
";
        // line 15
        $context["categories"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 15, $this->source); })()), "categories", []), "relatedTo", [0 => (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 15, $this->source); })())], "method");
        // line 16
        echo "
<section id=\"single-artist\">
\t<div class=\"wrapper\">
\t\t<a class=\"back-link\" href=\"/program\"> <i class=\"fa-lg fa fa-caret-left\"></i>Back to program</a>
\t\t<div class=\"artist-container\">
\t\t\t<div class=\"artist-image\" style=\"background-image: url('";
        // line 21
        echo twig_escape_filter($this->env, (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new RuntimeError('Variable "image" does not exist.', 21, $this->source); })()), "html", null, true);
        echo "');\"></div>
\t\t\t<div class=\"artist-content\">
\t\t\t";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) || array_key_exists("categories", $context) ? $context["categories"] : (function () { throw new RuntimeError('Variable "categories" does not exist.', 23, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 24
            echo "\t\t\t\t<div class=\"event-type\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["category"], "title", []), "html", null, true);
            echo "</div>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "
\t\t\t\t<h3>Please Feed the Dancers</h3>
\t\t\t\t";
        // line 28
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 28, $this->source); })()), "artistText", []), "html", null, true);
        echo "
\t\t\t\t<div class=\"artist-links\">

\t\t\t\t";
        // line 31
        if (((isset($context["Twitter"]) || array_key_exists("Twitter", $context) ? $context["Twitter"] : (function () { throw new RuntimeError('Variable "Twitter" does not exist.', 31, $this->source); })()) != null)) {
            // line 32
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, (isset($context["Twitter"]) || array_key_exists("Twitter", $context) ? $context["Twitter"] : (function () { throw new RuntimeError('Variable "Twitter" does not exist.', 32, $this->source); })()), "html", null, true);
            echo "\">
\t\t\t\t\t\t<i class=\"fab fa-twitter\"></i>
\t\t\t\t\t</a>
\t\t\t\t";
        }
        // line 36
        echo "
\t\t\t\t";
        // line 37
        if (((isset($context["Instagram"]) || array_key_exists("Instagram", $context) ? $context["Instagram"] : (function () { throw new RuntimeError('Variable "Instagram" does not exist.', 37, $this->source); })()) != null)) {
            // line 38
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, (isset($context["Instagram"]) || array_key_exists("Instagram", $context) ? $context["Instagram"] : (function () { throw new RuntimeError('Variable "Instagram" does not exist.', 38, $this->source); })()), "html", null, true);
            echo "\">
\t\t\t\t\t\t<i class=\"fab fa-instagram\"></i>
\t\t\t\t\t</a>
\t\t\t\t";
        }
        // line 42
        echo "\t\t\t\t";
        if (((isset($context["Facebook"]) || array_key_exists("Facebook", $context) ? $context["Facebook"] : (function () { throw new RuntimeError('Variable "Facebook" does not exist.', 42, $this->source); })()) != null)) {
            // line 43
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, (isset($context["Facebook"]) || array_key_exists("Facebook", $context) ? $context["Facebook"] : (function () { throw new RuntimeError('Variable "Facebook" does not exist.', 43, $this->source); })()), "html", null, true);
            echo "\">
\t\t\t\t\t\t<i class=\"fab fa-facebook\"></i>
\t\t\t\t\t</a>
\t\t\t\t";
        }
        // line 47
        echo "\t\t\t\t";
        if (((isset($context["Youtube"]) || array_key_exists("Youtube", $context) ? $context["Youtube"] : (function () { throw new RuntimeError('Variable "Youtube" does not exist.', 47, $this->source); })()) != null)) {
            // line 48
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, (isset($context["Youtube"]) || array_key_exists("Youtube", $context) ? $context["Youtube"] : (function () { throw new RuntimeError('Variable "Youtube" does not exist.', 48, $this->source); })()), "html", null, true);
            echo "\">
\t\t\t\t\t\t<i class=\"fab fa-youtube\"></i>
\t\t\t\t\t</a>
\t\t\t\t";
        }
        // line 52
        echo "\t\t\t\t";
        if (((isset($context["Vimeo"]) || array_key_exists("Vimeo", $context) ? $context["Vimeo"] : (function () { throw new RuntimeError('Variable "Vimeo" does not exist.', 52, $this->source); })()) != null)) {
            // line 53
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, (isset($context["Vimeo"]) || array_key_exists("Vimeo", $context) ? $context["Vimeo"] : (function () { throw new RuntimeError('Variable "Vimeo" does not exist.', 53, $this->source); })()), "html", null, true);
            echo "\">
\t\t\t\t\t\t<i class=\"fab fa-vimeo\"></i>
\t\t\t\t\t</a>
\t\t\t\t";
        }
        // line 57
        echo "\t\t\t\t";
        if (((isset($context["Soundcloud"]) || array_key_exists("Soundcloud", $context) ? $context["Soundcloud"] : (function () { throw new RuntimeError('Variable "Soundcloud" does not exist.', 57, $this->source); })()) != null)) {
            // line 58
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, (isset($context["Soundcloud"]) || array_key_exists("Soundcloud", $context) ? $context["Soundcloud"] : (function () { throw new RuntimeError('Variable "Soundcloud" does not exist.', 58, $this->source); })()), "html", null, true);
            echo "\">
\t\t\t\t\t\t<i class=\"fab fa-soundcloud\"></i>
\t\t\t\t\t</a>
\t\t\t\t";
        }
        // line 62
        echo "\t\t\t\t";
        if (((isset($context["Spotify"]) || array_key_exists("Spotify", $context) ? $context["Spotify"] : (function () { throw new RuntimeError('Variable "Spotify" does not exist.', 62, $this->source); })()) != null)) {
            // line 63
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, (isset($context["Spotify"]) || array_key_exists("Spotify", $context) ? $context["Spotify"] : (function () { throw new RuntimeError('Variable "Spotify" does not exist.', 63, $this->source); })()), "html", null, true);
            echo "\">
\t\t\t\t\t\t<i class=\"fab fa-spotify\"></i>
\t\t\t\t\t</a>
\t\t\t\t";
        }
        // line 67
        echo "\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</section>


<section id=\"more-artists\">
\t<div class=\"wrapper\">
\t\t<h3>More Artists</h3>
\t\t<div class=\"artist-gallery\">
\t\t\t\t";
        // line 78
        $context["categories"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 78, $this->source); })()), "entries", []), "section", [0 => "artists"], "method"), "find", [], "method");
        // line 79
        echo "
        ";
        // line 80
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) || array_key_exists("categories", $context) ? $context["categories"] : (function () { throw new RuntimeError('Variable "categories" does not exist.', 80, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 81
            echo "        ";
            $context["image"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "artistImage", [], "any", false, true), "one", [], "method", false, true), "getUrl", [], "method")) : (null));
            // line 82
            echo "        ";
            $context["url"] = craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "slug", []);
            // line 83
            echo "
          <a href=\"/program/";
            // line 84
            echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 84, $this->source); })()), "html", null, true);
            echo "\" class=\"artist\">
            <article>
              <div class=\"artist-image\" style=\"background-image: url('";
            // line 86
            echo twig_escape_filter($this->env, (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new RuntimeError('Variable "image" does not exist.', 86, $this->source); })()), "html", null, true);
            echo "');\"></div>
              <p class=\"artist-title\">";
            // line 87
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["entry"], "title", []), "html", null, true);
            echo "</p>
            </article>
          </a>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 91
        echo "\t\t</div>
\t</div>
</section>
";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "program/_artist";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  242 => 91,  232 => 87,  228 => 86,  223 => 84,  220 => 83,  217 => 82,  214 => 81,  210 => 80,  207 => 79,  205 => 78,  192 => 67,  184 => 63,  181 => 62,  173 => 58,  170 => 57,  162 => 53,  159 => 52,  151 => 48,  148 => 47,  140 => 43,  137 => 42,  129 => 38,  127 => 37,  124 => 36,  116 => 32,  114 => 31,  108 => 28,  104 => 26,  95 => 24,  91 => 23,  86 => 21,  79 => 16,  77 => 15,  74 => 14,  72 => 13,  70 => 12,  68 => 11,  66 => 10,  64 => 9,  62 => 8,  60 => 7,  58 => 6,  56 => 5,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layout\" %}

{% block content %}

{% set image = entry.artistImage.one().getUrl() ?? null %}
{% set Twitter = entry.artistLinkTwitter ?? null %}
{% set website = entry.artistLinkWebsite ?? null %}
{% set Instagram = entry.artistLinkInstagram ?? null %}
{% set Facebook = entry.artistLinkFacebook ?? null %}
{% set Youtube = entry.artistLinkYoutube ?? null %}
{% set Vimeo = entry.artistLinkVimeo ?? null %}
{% set Soundcloud = entry.artistLinkSoundcloud ?? null %}
{% set Spotify = entry.artistLinkSpotify ?? null %}

{% set categories = craft.categories.relatedTo(entry) %}

<section id=\"single-artist\">
\t<div class=\"wrapper\">
\t\t<a class=\"back-link\" href=\"/program\"> <i class=\"fa-lg fa fa-caret-left\"></i>Back to program</a>
\t\t<div class=\"artist-container\">
\t\t\t<div class=\"artist-image\" style=\"background-image: url('{{image}}');\"></div>
\t\t\t<div class=\"artist-content\">
\t\t\t{% for category in categories %}
\t\t\t\t<div class=\"event-type\">{{ category.title }}</div>
\t\t\t{% endfor %}

\t\t\t\t<h3>Please Feed the Dancers</h3>
\t\t\t\t{{ entry.artistText }}
\t\t\t\t<div class=\"artist-links\">

\t\t\t\t{% if Twitter != null %}
\t\t\t\t\t<a href=\"{{ Twitter }}\">
\t\t\t\t\t\t<i class=\"fab fa-twitter\"></i>
\t\t\t\t\t</a>
\t\t\t\t{% endif %}

\t\t\t\t{% if Instagram != null %}
\t\t\t\t\t<a href=\"{{ Instagram }}\">
\t\t\t\t\t\t<i class=\"fab fa-instagram\"></i>
\t\t\t\t\t</a>
\t\t\t\t{% endif %}
\t\t\t\t{% if Facebook != null %}
\t\t\t\t\t<a href=\"{{ Facebook }}\">
\t\t\t\t\t\t<i class=\"fab fa-facebook\"></i>
\t\t\t\t\t</a>
\t\t\t\t{% endif %}
\t\t\t\t{% if Youtube != null %}
\t\t\t\t\t<a href=\"{{Youtube}}\">
\t\t\t\t\t\t<i class=\"fab fa-youtube\"></i>
\t\t\t\t\t</a>
\t\t\t\t{% endif %}
\t\t\t\t{% if Vimeo != null %}
\t\t\t\t\t<a href=\"{{Vimeo}}\">
\t\t\t\t\t\t<i class=\"fab fa-vimeo\"></i>
\t\t\t\t\t</a>
\t\t\t\t{% endif %}
\t\t\t\t{% if Soundcloud != null %}
\t\t\t\t\t<a href=\"{{Soundcloud}}\">
\t\t\t\t\t\t<i class=\"fab fa-soundcloud\"></i>
\t\t\t\t\t</a>
\t\t\t\t{% endif %}
\t\t\t\t{% if Spotify != null %}
\t\t\t\t\t<a href=\"{{ Spotify }}\">
\t\t\t\t\t\t<i class=\"fab fa-spotify\"></i>
\t\t\t\t\t</a>
\t\t\t\t{% endif %}
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</section>


<section id=\"more-artists\">
\t<div class=\"wrapper\">
\t\t<h3>More Artists</h3>
\t\t<div class=\"artist-gallery\">
\t\t\t\t{% set categories = craft.entries.section('artists').find() %}

        {% for entry in categories %}
        {% set image = entry.artistImage.one().getUrl() ?? null %}
        {% set url = entry.slug %}

          <a href=\"/program/{{url}}\" class=\"artist\">
            <article>
              <div class=\"artist-image\" style=\"background-image: url('{{ image }}');\"></div>
              <p class=\"artist-title\">{{entry.title}}</p>
            </article>
          </a>
        {% endfor %}
\t\t</div>
\t</div>
</section>
{% endblock %}", "program/_artist", "/home/ubuntu/sites/seekult-nitro/craft/templates/program/_artist.twig");
    }
}

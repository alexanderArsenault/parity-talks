<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* login */
class __TwigTemplate_28299c5a5e219527e94757a579377fbe506cc0bdc310963338ad7ef67ae1576f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/basecp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "login");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "login", 2)->unwrap();
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Login", "app");
        // line 4
        $context["bodyClass"] = "login";
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\login\\LoginAsset"], "method");
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Reset Password", 1 => "Check your email for instructions to reset your password."]], "method");
        // line 11
        $context["username"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "app", []), "config", []), "general", []), "rememberUsernameDuration", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "app", []), "user", []), "getRememberedUsername", [], "method")) : (""));
        // line 13
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 13, $this->source); })()), "app", []), "config", []), "general", []), "useEmailAsUsername", [])) {
            // line 14
            $context["usernameLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Email", "app");
            // line 15
            $context["usernameType"] = "email";
        } else {
            // line 17
            $context["usernameLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Username or Email", "app");
            // line 18
            $context["usernameType"] = "text";
        }
        // line 21
        $context["hasLogo"] = (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 21, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 21, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 21, $this->source); })()), "rebrand", []), "isLogoUploaded", []));
        // line 23
        $context["formAttributes"] = ["id" => "login-form", "method" => "post", "accept-charset" => "UTF-8"];
        // line 29
        if ((isset($context["hasLogo"]) || array_key_exists("hasLogo", $context) ? $context["hasLogo"] : (function () { throw new RuntimeError('Variable "hasLogo" does not exist.', 29, $this->source); })())) {
            // line 30
            $context["logo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 30, $this->source); })()), "rebrand", []), "logo", []);
            // line 31
            $context["formAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["formAttributes"]) || array_key_exists("formAttributes", $context) ? $context["formAttributes"] : (function () { throw new RuntimeError('Variable "formAttributes" does not exist.', 31, $this->source); })()), ["class" => "has-logo", "style" => ["background-image" => (("url(" . twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source,             // line 34
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 34, $this->source); })()), "url", []), "css")) . ")"), "background-size" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 35
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 35, $this->source); })()), "width", []) . "px ") . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 35, $this->source); })()), "height", [])) . "px"), "padding-top" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 36
(isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 36, $this->source); })()), "height", []) + 30) . "px")]]);
        }
        // line 41
        ob_start();
        // line 42
        echo "    <form ";
        echo craft\helpers\Html::renderTagAttributes((isset($context["formAttributes"]) || array_key_exists("formAttributes", $context) ? $context["formAttributes"] : (function () { throw new RuntimeError('Variable "formAttributes" does not exist.', 42, $this->source); })()));
        echo ">
        ";
        // line 43
        if ( !(isset($context["hasLogo"]) || array_key_exists("hasLogo", $context) ? $context["hasLogo"] : (function () { throw new RuntimeError('Variable "hasLogo" does not exist.', 43, $this->source); })())) {
            // line 44
            echo "            <h1>";
            echo twig_escape_filter($this->env, (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 44, $this->source); })()), "html", null, true);
            echo "</h1>
        ";
        }
        // line 46
        echo "        <div id=\"login-fields\">
            ";
        // line 47
        echo twig_call_macro($macros["forms"], "macro_textField", [["id" => "loginName", "name" => "username", "placeholder" =>         // line 50
(isset($context["usernameLabel"]) || array_key_exists("usernameLabel", $context) ? $context["usernameLabel"] : (function () { throw new RuntimeError('Variable "usernameLabel" does not exist.', 50, $this->source); })()), "value" =>         // line 51
(isset($context["username"]) || array_key_exists("username", $context) ? $context["username"] : (function () { throw new RuntimeError('Variable "username" does not exist.', 51, $this->source); })()), "autocomplete" => "username", "type" =>         // line 53
(isset($context["usernameType"]) || array_key_exists("usernameType", $context) ? $context["usernameType"] : (function () { throw new RuntimeError('Variable "usernameType" does not exist.', 53, $this->source); })()), "inputAttributes" => ["aria" => ["label" =>         // line 56
(isset($context["usernameLabel"]) || array_key_exists("usernameLabel", $context) ? $context["usernameLabel"] : (function () { throw new RuntimeError('Variable "usernameLabel" does not exist.', 56, $this->source); })())]]]], 47, $context, $this->getSourceContext());
        // line 59
        echo "
            ";
        // line 60
        echo twig_call_macro($macros["forms"], "macro_passwordField", [["id" => "password", "name" => "password", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app"), "autocomplete" => "current-password", "inputAttributes" => ["aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app")]]]], 60, $context, $this->getSourceContext());
        // line 70
        echo "
        </div>
        <div id=\"password-fields\">
            ";
        // line 73
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 73, $this->source); })()), "app", []), "config", []), "general", []), "rememberedUserSessionDuration", [])) {
            // line 74
            echo "                ";
            echo twig_call_macro($macros["forms"], "macro_checkboxField", [["id" => "rememberMe", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Keep me logged in", "app")]], 74, $context, $this->getSourceContext());
            echo "
            ";
        }
        // line 76
        echo "            <a id=\"forgot-password\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Forgot your password?", "app"), "html", null, true);
        echo "</a>
        </div>
        <div class=\"buttons\">
            <button id=\"submit\" class=\"btn submit disabled\" type=\"submit\">";
        // line 79
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Login", "app"), "html", null, true);
        echo "</button>
            <div id=\"spinner\" class=\"spinner hidden\"></div>
        </div>
        <a id=\"poweredby\" href=\"http://craftcms.com/\" title=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Powered by Craft CMS", "app"), "html", null, true);
        echo "\">
            ";
        // line 83
        echo $this->extensions['craft\web\twig\Extension']->svgFunction("@app/web/assets/cp/dist/images/craftcms.svg");
        echo "
        </a>
    </form>
";
        $context["formHtml"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 88
        ob_start();
        // line 89
        echo "    <div class=\"message-container no-access\">
        <div class=\"pane notice\">
            <p>";
        // line 91
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Cookies must be enabled to access the Craft CMS control panel.", "app"), "html", null, true);
        echo "</p>
        </div>
    </div>
";
        $context["noCookiesHtml"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent = $this->loadTemplate("_layouts/basecp", "login", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "login");
    }

    // line 96
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 97
        echo "    <script type=\"text/javascript\">
        var cookieTest = 'CraftCookieTest='+Math.floor(Math.random() * 1000000);
        document.cookie = cookieTest;
        if (document.cookie.search(cookieTest) != -1) {
            document.cookie = cookieTest + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            document.write(";
        // line 102
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["formHtml"]) || array_key_exists("formHtml", $context) ? $context["formHtml"] : (function () { throw new RuntimeError('Variable "formHtml" does not exist.', 102, $this->source); })()));
        echo ");

            ";
        // line 104
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 104, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method")) {
            // line 105
            echo "                document.getElementById(\"";
            echo (((isset($context["username"]) || array_key_exists("username", $context) ? $context["username"] : (function () { throw new RuntimeError('Variable "username" does not exist.', 105, $this->source); })())) ? ("password") : ("loginName"));
            echo "\").focus();
            ";
        }
        // line 107
        echo "        } else {
            document.write(";
        // line 108
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["noCookiesHtml"]) || array_key_exists("noCookiesHtml", $context) ? $context["noCookiesHtml"] : (function () { throw new RuntimeError('Variable "noCookiesHtml" does not exist.', 108, $this->source); })()));
        echo ");
        }
    </script>
";
        craft\helpers\Template::endProfile("block", "body");
    }

    public function getTemplateName()
    {
        return "login";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  194 => 108,  191 => 107,  185 => 105,  183 => 104,  178 => 102,  171 => 97,  166 => 96,  160 => 1,  153 => 91,  149 => 89,  147 => 88,  140 => 83,  136 => 82,  130 => 79,  123 => 76,  117 => 74,  115 => 73,  110 => 70,  108 => 60,  105 => 59,  103 => 56,  102 => 53,  101 => 51,  100 => 50,  99 => 47,  96 => 46,  90 => 44,  88 => 43,  83 => 42,  81 => 41,  78 => 36,  77 => 35,  76 => 34,  75 => 31,  73 => 30,  71 => 29,  69 => 23,  67 => 21,  64 => 18,  62 => 17,  59 => 15,  57 => 14,  55 => 13,  53 => 11,  51 => 6,  49 => 5,  47 => 4,  45 => 3,  43 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/basecp\" %}
{% import \"_includes/forms\" as forms %}
{% set title = \"Login\"|t('app') %}
{% set bodyClass = 'login' %}
{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\login\\\\LoginAsset\") %}
{% do view.registerTranslations('app', [
    \"Reset Password\",
    \"Check your email for instructions to reset your password.\",
]) %}

{% set username = craft.app.config.general.rememberUsernameDuration ? craft.app.user.getRememberedUsername(): '' %}

{% if craft.app.config.general.useEmailAsUsername %}
    {% set usernameLabel = 'Email'|t('app') %}
    {% set usernameType = 'email' %}
{% else %}
    {% set usernameLabel = 'Username or Email'|t('app') %}
    {% set usernameType = 'text' %}
{% endif %}

{% set hasLogo = CraftEdition == CraftPro and craft.rebrand.isLogoUploaded %}

{% set formAttributes = {
    id: 'login-form',
    method: 'post',
    'accept-charset': 'UTF-8',
} %}

{% if hasLogo %}
    {% set logo = craft.rebrand.logo %}
    {% set formAttributes = formAttributes|merge({
        class: 'has-logo',
        style: {
            'background-image': \"url(#{logo.url|e('css')})\",
            'background-size': \"#{logo.width}px #{logo.height}px\",
            'padding-top': \"#{logo.height + 30}px\",
        },
    }) %}
{% endif %}

{% set formHtml %}
    <form {{ attr(formAttributes) }}>
        {% if not hasLogo %}
            <h1>{{ systemName }}</h1>
        {% endif %}
        <div id=\"login-fields\">
            {{ forms.textField({
                id: 'loginName',
                name: 'username',
                placeholder: usernameLabel,
                value: username,
                autocomplete: 'username',
                type: usernameType,
                inputAttributes: {
                    aria: {
                        label: usernameLabel,
                    },
                },
            }) }}
            {{ forms.passwordField({
                id: 'password',
                name: 'password',
                placeholder: 'Password'|t('app'),
                autocomplete: 'current-password',
                inputAttributes: {
                    aria: {
                        label: 'Password'|t('app'),
                    },
                },
            }) }}
        </div>
        <div id=\"password-fields\">
            {% if craft.app.config.general.rememberedUserSessionDuration %}
                {{ forms.checkboxField({ id: 'rememberMe', label: 'Keep me logged in'|t('app') }) }}
            {% endif %}
            <a id=\"forgot-password\">{{ 'Forgot your password?'|t('app') }}</a>
        </div>
        <div class=\"buttons\">
            <button id=\"submit\" class=\"btn submit disabled\" type=\"submit\">{{ 'Login'|t('app') }}</button>
            <div id=\"spinner\" class=\"spinner hidden\"></div>
        </div>
        <a id=\"poweredby\" href=\"http://craftcms.com/\" title=\"{{ 'Powered by Craft CMS'|t('app') }}\">
            {{ svg('@app/web/assets/cp/dist/images/craftcms.svg') }}
        </a>
    </form>
{% endset %}

{% set noCookiesHtml %}
    <div class=\"message-container no-access\">
        <div class=\"pane notice\">
            <p>{{ 'Cookies must be enabled to access the Craft CMS control panel.'|t('app') }}</p>
        </div>
    </div>
{% endset %}

{% block body %}
    <script type=\"text/javascript\">
        var cookieTest = 'CraftCookieTest='+Math.floor(Math.random() * 1000000);
        document.cookie = cookieTest;
        if (document.cookie.search(cookieTest) != -1) {
            document.cookie = cookieTest + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            document.write({{ formHtml|json_encode|raw }});

            {% if not craft.app.request.isMobileBrowser(true) %}
                document.getElementById(\"{{ (username ? 'password' : 'loginName') }}\").focus();
            {% endif %}
        } else {
            document.write({{ noCookiesHtml|json_encode|raw }});
        }
    </script>
{% endblock %}
", "login", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/login.html");
    }
}

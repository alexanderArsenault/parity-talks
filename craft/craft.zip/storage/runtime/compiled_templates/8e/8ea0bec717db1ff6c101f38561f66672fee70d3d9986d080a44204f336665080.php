<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/assets/_layout */
class __TwigTemplate_f29261953801c544500dd0c99e2dc6f3acadc0f6ede9682e8f9978ce63c4b2c0 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'sidebar' => [$this, 'block_sidebar'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "settings/assets/_layout");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Asset Settings", "app");
        // line 4
        $context["crumbs"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 9
        $context["navItems"] = ["volumes" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Volumes", "app"), "url" => craft\helpers\UrlHelper::url("settings/assets")], "transforms" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Image Transforms", "app"), "url" => craft\helpers\UrlHelper::url("settings/assets/transforms")], "settings" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings/assets/settings")]];
        // line 15
        $context["docTitle"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["navItems"]) || array_key_exists("navItems", $context) ? $context["navItems"] : (function () { throw new RuntimeError('Variable "navItems" does not exist.', 15, $this->source); })()), (isset($context["selectedNavItem"]) || array_key_exists("selectedNavItem", $context) ? $context["selectedNavItem"] : (function () { throw new RuntimeError('Variable "selectedNavItem" does not exist.', 15, $this->source); })()), [], "array"), "label", []) . " - ") . (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 15, $this->source); })()));
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/assets/_layout", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "settings/assets/_layout");
    }

    // line 17
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 18
        echo "    ";
        $this->loadTemplate("_includes/nav", "settings/assets/_layout", 18)->display(twig_to_array(["items" => (isset($context["navItems"]) || array_key_exists("navItems", $context) ? $context["navItems"] : (function () { throw new RuntimeError('Variable "navItems" does not exist.', 18, $this->source); })()), "selectedItem" => (isset($context["selectedNavItem"]) || array_key_exists("selectedNavItem", $context) ? $context["selectedNavItem"] : (function () { throw new RuntimeError('Variable "selectedNavItem" does not exist.', 18, $this->source); })())]));
        craft\helpers\Template::endProfile("block", "sidebar");
    }

    public function getTemplateName()
    {
        return "settings/assets/_layout";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 18,  57 => 17,  51 => 1,  49 => 15,  47 => 9,  45 => 4,  43 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"Asset Settings\"|t('app') %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}


{% set navItems = {
    volumes: { label: \"Volumes\"|t('app'), url: url('settings/assets') },
    transforms: { label: \"Image Transforms\"|t('app'), url: url('settings/assets/transforms') },
    settings: { label: \"Settings\"|t('app'), url: url('settings/assets/settings') },
} %}

{% set docTitle = navItems[selectedNavItem].label~' - '~title %}

{% block sidebar %}
    {% include \"_includes/nav\" with { items: navItems, selectedItem: selectedNavItem } only %}
{% endblock %}
", "settings/assets/_layout", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/settings/assets/_layout.html");
    }
}

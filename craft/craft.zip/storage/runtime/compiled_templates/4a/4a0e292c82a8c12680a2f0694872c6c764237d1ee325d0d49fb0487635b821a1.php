<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* about */
class __TwigTemplate_5406967831c8a14d5d36aada2fa6500fe28f533d42caa71e99eaa58919c20cc2 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "about");
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
\t<meta charset=\"UTF-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<title>SeeKULT</title>
\t<link rel=\"stylesheet\" href=\"<%=htmlWebpackPlugin.files.chunks.main.css %>\">
\t<link rel=\"icon\" href=\"./favicon.ico\">
\t<link rel=\"apple-touch-icon\" href=\"/apple-touch-icon.png\" />
";
        // line 10
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>
<body>";
        // line 11
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "

<header>
\t<header>
\t\t<nav>
\t\t\t<ul>
\t\t\t\t<li><a href=\"/index.html\">Home</a></li>
\t\t\t\t<li><a href=\"/program.html\">Program</a></li>
\t\t\t\t<li><a href=\"/about.html\">About</a></li>
\t\t\t\t<li><a href=\"/logbook.html\">Logbook</a></li>
\t\t\t\t<li><a href=\"/stream.html\">Stream</a></li>
\t\t\t</ul>
\t\t</nav>
</header>

</header>

<section>
\t<div class=\"wrapper\">
\t\t<h3>Thanks!</h3>
\t</div>
</section>

<footer>
\t<div class=\"footer-contact\">
\t\t<p class=\"bold\">Contact</p>
\t\t<p class=\"text\"><a href=\"mailto:info@seekult.de\">info@seekult.de</a></p>
\t\t<p class=\"text\">Am Seemooser Horn 20</p>
\t\t<p class=\"text\">88045 Friedrichshafen, Germany</p>
\t</div>
\t<div class=\"footer-privacy\">
\t\t<p class=\"bold\">Privacy Policy</p>
\t\t<p class=\"text\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis tempore itaque nisi. Doloribus reprehenderit earum illo corporis accusamus necessitatibus sequi distinctio, voluptatem aliquam culpa. Voluptatibus, eaque incidunt! Sunt quidem suscipit inventore velit. Mollitia veritatis qui porro consequatur odit voluptate libero architecto sunt nobis labore! Magnam sed ducimus quidem iusto dolorum.</p>
\t</div>
</footer>

<script defer src=\"<%= htmlWebpackPlugin.files.chunks.main.entry %>\"></script>
</html>";
        craft\helpers\Template::endProfile("template", "about");
    }

    public function getTemplateName()
    {
        return "about";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 11,  49 => 10,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
\t<meta charset=\"UTF-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<title>SeeKULT</title>
\t<link rel=\"stylesheet\" href=\"<%=htmlWebpackPlugin.files.chunks.main.css %>\">
\t<link rel=\"icon\" href=\"./favicon.ico\">
\t<link rel=\"apple-touch-icon\" href=\"/apple-touch-icon.png\" />
</head>
<body>

<header>
\t<header>
\t\t<nav>
\t\t\t<ul>
\t\t\t\t<li><a href=\"/index.html\">Home</a></li>
\t\t\t\t<li><a href=\"/program.html\">Program</a></li>
\t\t\t\t<li><a href=\"/about.html\">About</a></li>
\t\t\t\t<li><a href=\"/logbook.html\">Logbook</a></li>
\t\t\t\t<li><a href=\"/stream.html\">Stream</a></li>
\t\t\t</ul>
\t\t</nav>
</header>

</header>

<section>
\t<div class=\"wrapper\">
\t\t<h3>Thanks!</h3>
\t</div>
</section>

<footer>
\t<div class=\"footer-contact\">
\t\t<p class=\"bold\">Contact</p>
\t\t<p class=\"text\"><a href=\"mailto:info@seekult.de\">info@seekult.de</a></p>
\t\t<p class=\"text\">Am Seemooser Horn 20</p>
\t\t<p class=\"text\">88045 Friedrichshafen, Germany</p>
\t</div>
\t<div class=\"footer-privacy\">
\t\t<p class=\"bold\">Privacy Policy</p>
\t\t<p class=\"text\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis tempore itaque nisi. Doloribus reprehenderit earum illo corporis accusamus necessitatibus sequi distinctio, voluptatem aliquam culpa. Voluptatibus, eaque incidunt! Sunt quidem suscipit inventore velit. Mollitia veritatis qui porro consequatur odit voluptate libero architecto sunt nobis labore! Magnam sed ducimus quidem iusto dolorum.</p>
\t</div>
</footer>

<script defer src=\"<%= htmlWebpackPlugin.files.chunks.main.entry %>\"></script>
</html>", "about", "/home/ubuntu/sites/seekult-nitro/craft/templates/about.html");
    }
}

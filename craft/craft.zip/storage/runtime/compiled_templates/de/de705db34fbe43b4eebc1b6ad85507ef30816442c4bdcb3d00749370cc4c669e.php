<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Assets/input */
class __TwigTemplate_01117050e46eda939a06fe36ddf8586a46f0d3dd1b1cd87e09d03c37f7c4bc40 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Assets/input");
        // line 1
        if (((isset($context["name"]) || array_key_exists("name", $context)) && (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 1, $this->source); })()))) {
            // line 2
            echo "    ";
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 2, $this->source); })()), "");
            echo "
";
        }
        // line 5
        $context["elements"] = (((isset($context["elements"]) || array_key_exists("elements", $context))) ? ((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 5, $this->source); })())) : ([]));
        // line 6
        $context["jsClass"] = ((((isset($context["jsClass"]) || array_key_exists("jsClass", $context)) && (isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 6, $this->source); })()))) ? ((isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 6, $this->source); })())) : ("Craft.BaseElementSelectInput"));
        // line 7
        $context["sources"] = ((((isset($context["sources"]) || array_key_exists("sources", $context)) && (isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 7, $this->source); })()))) ? ((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 7, $this->source); })())) : (null));
        // line 8
        $context["criteria"] = ((((isset($context["criteria"]) || array_key_exists("criteria", $context)) && (isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 8, $this->source); })()))) ? ((isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 8, $this->source); })())) : (null));
        // line 9
        $context["storageKey"] = ((((isset($context["storageKey"]) || array_key_exists("storageKey", $context)) && (isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 9, $this->source); })()))) ? ((isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 9, $this->source); })())) : (null));
        // line 11
        echo "<div id=\"";
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 11, $this->source); })()), "html", null, true);
        echo "\" class=\"elementselect\">
    <div class=\"elements\">
        ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 13, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 14
            echo "            ";
            $this->loadTemplate("_elements/element", "_components/fieldtypes/Assets/input", 14)->display(twig_array_merge($context, ["context" => "field", "size" => (((            // line 16
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 16, $this->source); })()) == "large")) ? ("large") : ("small"))]));
            // line 18
            echo "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "    </div>

    ";
        // line 21
        if ((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 21, $this->source); })())) {
            // line 22
            echo "        <button type=\"button\" class=\"btn add icon dashed\">";
            echo twig_escape_filter($this->env, (isset($context["selectionLabel"]) || array_key_exists("selectionLabel", $context) ? $context["selectionLabel"] : (function () { throw new RuntimeError('Variable "selectionLabel" does not exist.', 22, $this->source); })()), "html", null, true);
            echo "</button>
    ";
        }
        // line 24
        echo "</div>

";
        // line 26
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 26, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\prismjs\\PrismJsAsset"], "method");
        // line 27
        echo "
";
        // line 28
        $context["jsSettings"] = ["id" => call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [        // line 29
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 29, $this->source); })())]), "name" => call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), [        // line 30
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 30, $this->source); })())]), "elementType" =>         // line 31
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 31, $this->source); })()), "sources" =>         // line 32
(isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 32, $this->source); })()), "criteria" =>         // line 33
(isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 33, $this->source); })()), "sourceElementId" =>         // line 34
(isset($context["sourceElementId"]) || array_key_exists("sourceElementId", $context) ? $context["sourceElementId"] : (function () { throw new RuntimeError('Variable "sourceElementId" does not exist.', 34, $this->source); })()), "viewMode" =>         // line 35
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 35, $this->source); })()), "limit" =>         // line 36
(isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 36, $this->source); })()), "modalStorageKey" =>         // line 37
(isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 37, $this->source); })()), "fieldId" =>         // line 38
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 38, $this->source); })()), "prevalidate" => ((        // line 39
$context["prevalidate"]) ?? (false)), "defaultFieldLayoutId" =>         // line 40
(isset($context["defaultFieldLayoutId"]) || array_key_exists("defaultFieldLayoutId", $context) ? $context["defaultFieldLayoutId"] : (function () { throw new RuntimeError('Variable "defaultFieldLayoutId" does not exist.', 40, $this->source); })()), "modalSettings" => ["hideSidebar" =>         // line 42
(isset($context["hideSidebar"]) || array_key_exists("hideSidebar", $context) ? $context["hideSidebar"] : (function () { throw new RuntimeError('Variable "hideSidebar" does not exist.', 42, $this->source); })()), "defaultSource" =>         // line 43
(isset($context["defaultUploadLocation"]) || array_key_exists("defaultUploadLocation", $context) ? $context["defaultUploadLocation"] : (function () { throw new RuntimeError('Variable "defaultUploadLocation" does not exist.', 43, $this->source); })())]];
        // line 46
        echo "
";
        // line 47
        ob_start();
        // line 48
        echo "    new ";
        echo twig_escape_filter($this->env, (isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 48, $this->source); })()), "html", null, true);
        echo "(";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["jsSettings"]) || array_key_exists("jsSettings", $context) ? $context["jsSettings"] : (function () { throw new RuntimeError('Variable "jsSettings" does not exist.', 48, $this->source); })()));
        echo ");
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Assets/input");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Assets/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 48,  137 => 47,  134 => 46,  132 => 43,  131 => 42,  130 => 40,  129 => 39,  128 => 38,  127 => 37,  126 => 36,  125 => 35,  124 => 34,  123 => 33,  122 => 32,  121 => 31,  120 => 30,  119 => 29,  118 => 28,  115 => 27,  113 => 26,  109 => 24,  103 => 22,  101 => 21,  97 => 19,  83 => 18,  81 => 16,  79 => 14,  62 => 13,  56 => 11,  54 => 9,  52 => 8,  50 => 7,  48 => 6,  46 => 5,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if name is defined and name %}
    {{ hiddenInput(name, '') }}
{% endif -%}

{% set elements = (elements is defined ? elements : []) -%}
{% set jsClass = (jsClass is defined and jsClass ? jsClass : 'Craft.BaseElementSelectInput') -%}
{% set sources = (sources is defined and sources ? sources : null) -%}
{% set criteria = (criteria is defined and criteria ? criteria : null) -%}
{% set storageKey = (storageKey is defined and storageKey ? storageKey : null) -%}

<div id=\"{{ id }}\" class=\"elementselect\">
    <div class=\"elements\">
        {% for element in elements %}
            {% include \"_elements/element\" with {
                context: 'field',
                size: (viewMode == 'large' ? 'large' : 'small')
            } %}
        {% endfor %}
    </div>

    {% if sources %}
        <button type=\"button\" class=\"btn add icon dashed\">{{ selectionLabel }}</button>
    {% endif %}
</div>

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\prismjs\\\\PrismJsAsset\") %}

{% set jsSettings = {
    id: id|namespaceInputId,
    name: name|namespaceInputName,
    elementType: elementType,
    sources: sources,
    criteria: criteria,
    sourceElementId: sourceElementId,
    viewMode: viewMode,
    limit: limit,
    modalStorageKey: storageKey,
    fieldId: fieldId,
    prevalidate: prevalidate ?? false,
    defaultFieldLayoutId: defaultFieldLayoutId,
    modalSettings: {
        hideSidebar: hideSidebar,
        defaultSource: defaultUploadLocation
    }
} %}

{% js %}
    new {{ jsClass }}({{ jsSettings|json_encode|raw }});
{% endjs %}
", "_components/fieldtypes/Assets/input", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_components/fieldtypes/Assets/input.html");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/PlainText/input */
class __TwigTemplate_593a546d686b10db0edcc2dde8f0b083e10a659db1ed01a49142e6bc9e99d3b9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/PlainText/input");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/PlainText/input", 1)->unwrap();
        // line 3
        $context["class"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "nicetext", 1 => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 5
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 5, $this->source); })()), "code", [])) ? ("code") : ("")), 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 6
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 6, $this->source); })()), "uiMode", []) == "enlarged")) ? ("readable") : (""))]);
        // line 8
        echo "
";
        // line 9
        $context["config"] = ["id" =>         // line 10
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 10, $this->source); })()), "name" =>         // line 11
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 11, $this->source); })()), "value" =>         // line 12
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 12, $this->source); })()), "class" =>         // line 13
(isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 13, $this->source); })()), "maxlength" => craft\helpers\Template::attribute($this->env, $this->source,         // line 14
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 14, $this->source); })()), "charLimit", []), "showCharsLeft" => true, "placeholder" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 16
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 16, $this->source); })()), "placeholder", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 16, $this->source); })()), "placeholder", []), "site")) : ("")), "rows" => craft\helpers\Template::attribute($this->env, $this->source,         // line 17
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 17, $this->source); })()), "initialRows", [])];
        // line 19
        echo "
";
        // line 20
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 20, $this->source); })()), "multiline", [])) {
            // line 21
            echo "    ";
            echo twig_call_macro($macros["forms"], "macro_textarea", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 21, $this->source); })())], 21, $context, $this->getSourceContext());
            echo "
";
        } else {
            // line 23
            echo "    ";
            echo twig_call_macro($macros["forms"], "macro_text", [(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 23, $this->source); })())], 23, $context, $this->getSourceContext());
            echo "
";
        }
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/PlainText/input");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/PlainText/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 23,  61 => 21,  59 => 20,  56 => 19,  54 => 17,  53 => 16,  52 => 14,  51 => 13,  50 => 12,  49 => 11,  48 => 10,  47 => 9,  44 => 8,  42 => 6,  41 => 5,  40 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{%- set class = [
    'nicetext',
    field.code ? 'code',
    field.uiMode == 'enlarged' ? 'readable',
]|filter %}

{% set config = {
    id: name,
    name: name,
    value: value,
    class: class,
    maxlength: field.charLimit,
    showCharsLeft: true,
    placeholder: field.placeholder ? field.placeholder|t('site'),
    rows: field.initialRows
} %}

{% if field.multiline %}
    {{ forms.textarea(config) }}
{% else %}
    {{ forms.text(config) }}
{% endif %}
", "_components/fieldtypes/PlainText/input", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_components/fieldtypes/PlainText/input.html");
    }
}

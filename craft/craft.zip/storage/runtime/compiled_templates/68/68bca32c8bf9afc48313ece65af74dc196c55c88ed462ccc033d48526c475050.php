<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__eb4db3251be824d14d531adb752a5e14a44b3b03f4c4640e1b81ad763a049597 */
class __TwigTemplate_fcdb972f41dfa878507c75568f439a0d9bc054646c903de480e2f3f49afa0fa4 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__eb4db3251be824d14d531adb752a5e14a44b3b03f4c4640e1b81ad763a049597");
        // line 1
        echo "settings/fields/edit/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "id", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "id", [])));
        craft\helpers\Template::endProfile("template", "__string_template__eb4db3251be824d14d531adb752a5e14a44b3b03f4c4640e1b81ad763a049597");
    }

    public function getTemplateName()
    {
        return "__string_template__eb4db3251be824d14d531adb752a5e14a44b3b03f4c4640e1b81ad763a049597";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("settings/fields/edit/{{ (_variables.id ?? object.id)|raw }}", "__string_template__eb4db3251be824d14d531adb752a5e14a44b3b03f4c4640e1b81ad763a049597", "");
    }
}

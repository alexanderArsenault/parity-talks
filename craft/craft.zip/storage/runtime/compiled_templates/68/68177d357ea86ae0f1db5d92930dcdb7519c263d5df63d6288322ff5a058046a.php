<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* categories/_edit */
class __TwigTemplate_29f8c201b0e508980a2a630237738a089cf62fc64c3be7d4a6da29ee30255083 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'contextMenu' => [$this, 'block_contextMenu'],
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "categories/_edit");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "categories/_edit", 2)->unwrap();
        // line 4
        $context["fullPageForm"] = true;
        // line 5
        $context["saveShortcutRedirect"] = (isset($context["continueEditingUrl"]) || array_key_exists("continueEditingUrl", $context) ? $context["continueEditingUrl"] : (function () { throw new RuntimeError('Variable "continueEditingUrl" does not exist.', 5, $this->source); })());
        // line 6
        $context["retainScrollOnSaveShortcut"] = true;
        // line 7
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 7, $this->source); })()), "setIsDeltaRegistrationActive", [0 => true], "method");
        // line 9
        $context["groupHandle"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 9, $this->source); })()), "handle", []);
        // line 10
        $context["isNewCategory"] = ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 10, $this->source); })()), "id", [])) ? (false) : (true));
        // line 12
        $context["formActions"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [        // line 15
(isset($context["continueEditingUrl"]) || array_key_exists("continueEditingUrl", $context) ? $context["continueEditingUrl"] : (function () { throw new RuntimeError('Variable "continueEditingUrl" does not exist.', 15, $this->source); })())]), "shortcut" => true, "retainScroll" => true], 1 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save and add another", "app"), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [        // line 21
(isset($context["nextCategoryUrl"]) || array_key_exists("nextCategoryUrl", $context) ? $context["nextCategoryUrl"] : (function () { throw new RuntimeError('Variable "nextCategoryUrl" does not exist.', 21, $this->source); })())]), "shortcut" => true, "shift" => true], 2 => (( !        // line 25
(isset($context["isNewCategory"]) || array_key_exists("isNewCategory", $context) ? $context["isNewCategory"] : (function () { throw new RuntimeError('Variable "isNewCategory" does not exist.', 25, $this->source); })())) ? (["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a new {type}", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,         // line 27
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 27, $this->source); })()), "lowerDisplayName", [], "method")]), "params" => ["duplicate" => "1"], "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [(        // line 32
(isset($context["continueEditingUrl"]) || array_key_exists("continueEditingUrl", $context) ? $context["continueEditingUrl"] : (function () { throw new RuntimeError('Variable "continueEditingUrl" does not exist.', 32, $this->source); })()) . "#")])]) : ("")), 3 => (( !        // line 34
(isset($context["isNewCategory"]) || array_key_exists("isNewCategory", $context) ? $context["isNewCategory"] : (function () { throw new RuntimeError('Variable "isNewCategory" does not exist.', 34, $this->source); })())) ? (["destructive" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Delete {type}", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,         // line 37
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 37, $this->source); })()), "lowerDisplayName", [], "method")]), "action" => "categories/delete-category", "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), ["categories#"]), "confirm" => $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to delete this {type}?", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,         // line 42
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 42, $this->source); })()), "lowerDisplayName", [], "method")])]) : (""))]);
        // line 47
        echo \Craft::$app->getView()->invokeHook("cp.categories.edit", $context);

        // line 155
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 155, $this->source); })()), "slug", [])) {
            // line 156
            ob_start();
            // line 157
            echo "        window.slugGenerator = new Craft.SlugGenerator('#title', '#slug', {
            charMap: ";
            // line 158
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 158, $this->source); })()), "cp", []), "getAsciiCharMap", [0 => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 158, $this->source); })()), "site", []), "language", [])], "method"));
            echo "
        });
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "categories/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "categories/_edit");
    }

    // line 49
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "header");
        // line 50
        echo "    <div class=\"flex flex-nowrap\">
        ";
        // line 51
        $this->displayBlock("pageTitle", $context, $blocks);
        echo "
        ";
        // line 52
        $this->displayBlock("contextMenu", $context, $blocks);
        echo "
    </div>
    <div class=\"flex\">
        ";
        // line 55
        if (((isset($context["showPreviewBtn"]) || array_key_exists("showPreviewBtn", $context) ? $context["showPreviewBtn"] : (function () { throw new RuntimeError('Variable "showPreviewBtn" does not exist.', 55, $this->source); })()) || (isset($context["shareUrl"]) || array_key_exists("shareUrl", $context)))) {
            // line 56
            echo "            <div class=\"btngroup\">
                ";
            // line 57
            if ((isset($context["showPreviewBtn"]) || array_key_exists("showPreviewBtn", $context) ? $context["showPreviewBtn"] : (function () { throw new RuntimeError('Variable "showPreviewBtn" does not exist.', 57, $this->source); })())) {
                // line 58
                echo "                    <button type=\"button\" class=\"btn livepreviewbtn\" data-icon=\"view\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Preview", "app"), "html", null, true);
                echo "</button>
                ";
            }
            // line 60
            echo "                ";
            if ((isset($context["shareUrl"]) || array_key_exists("shareUrl", $context))) {
                // line 61
                echo "                    <a href=\"";
                echo twig_escape_filter($this->env, (isset($context["shareUrl"]) || array_key_exists("shareUrl", $context) ? $context["shareUrl"] : (function () { throw new RuntimeError('Variable "shareUrl" does not exist.', 61, $this->source); })()), "html", null, true);
                echo "\" class=\"btn sharebtn\" data-icon=\"share\" rel=\"noopener\" target=\"_blank\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Share", "app"), "html", null, true);
                echo "</a>
                ";
            }
            // line 63
            echo "            </div>
        ";
        }
        // line 65
        echo "        ";
        $this->displayBlock("actionButton", $context, $blocks);
        echo "
    </div>
";
        craft\helpers\Template::endProfile("block", "header");
    }

    // line 69
    public function block_contextMenu($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "contextMenu");
        // line 70
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 70, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 71
            echo "        ";
            $context["parentIdParam"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 71, $this->source); })()), "app", []), "request", []), "getParam", [0 => "parentId.0"], "method")) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 71, $this->source); })()), "app", []), "request", []), "getParam", [0 => "parentId.0"], "method")) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 71, $this->source); })()), "app", []), "request", []), "getParam", [0 => "parentId"], "method")));
            // line 72
            echo "        ";
            $context["urlFormat"] = craft\helpers\UrlHelper::url((((("categories/" . (isset($context["groupHandle"]) || array_key_exists("groupHandle", $context) ? $context["groupHandle"] : (function () { throw new RuntimeError('Variable "groupHandle" does not exist.', 72, $this->source); })())) . "/") . craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 72, $this->source); })()), "app", []), "request", []), "getSegment", [0 => 3], "method")) . "/{handle}"), (((isset($context["parentIdParam"]) || array_key_exists("parentIdParam", $context) ? $context["parentIdParam"] : (function () { throw new RuntimeError('Variable "parentIdParam" does not exist.', 72, $this->source); })())) ? (["parentId" => (isset($context["parentIdParam"]) || array_key_exists("parentIdParam", $context) ? $context["parentIdParam"] : (function () { throw new RuntimeError('Variable "parentIdParam" does not exist.', 72, $this->source); })())]) : ("")));
            // line 73
            echo "        ";
            $this->loadTemplate("_elements/sitemenu", "categories/_edit", 73)->display(twig_to_array(["siteIds" =>             // line 74
(isset($context["siteIds"]) || array_key_exists("siteIds", $context) ? $context["siteIds"] : (function () { throw new RuntimeError('Variable "siteIds" does not exist.', 74, $this->source); })()), "selectedSiteId" => craft\helpers\Template::attribute($this->env, $this->source,             // line 75
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 75, $this->source); })()), "siteId", []), "urlFormat" =>             // line 76
(isset($context["urlFormat"]) || array_key_exists("urlFormat", $context) ? $context["urlFormat"] : (function () { throw new RuntimeError('Variable "urlFormat" does not exist.', 76, $this->source); })())]));
            // line 78
            echo "    ";
        }
        craft\helpers\Template::endProfile("block", "contextMenu");
    }

    // line 82
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 83
        echo "    ";
        echo craft\helpers\Html::actionInput("categories/save-category");
        echo "
    ";
        // line 84
        echo craft\helpers\Html::redirectInput(("categories/" . (isset($context["groupHandle"]) || array_key_exists("groupHandle", $context) ? $context["groupHandle"] : (function () { throw new RuntimeError('Variable "groupHandle" does not exist.', 84, $this->source); })())));
        echo "

    ";
        // line 86
        echo craft\helpers\Html::hiddenInput("groupId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 86, $this->source); })()), "id", []));
        echo "
    ";
        // line 87
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 87, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("categoryId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 87, $this->source); })()), "id", []));
        }
        // line 88
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 88, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            echo craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 88, $this->source); })()), "siteId", []));
        }
        // line 89
        echo "
    <div id=\"fields\">
        ";
        // line 91
        echo (isset($context["fieldsHtml"]) || array_key_exists("fieldsHtml", $context) ? $context["fieldsHtml"] : (function () { throw new RuntimeError('Variable "fieldsHtml" does not exist.', 91, $this->source); })());
        echo "
    </div>

    ";
        // line 95
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.categories.edit.content", $context);

        craft\helpers\Template::endProfile("block", "content");
    }

    // line 98
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 99
        echo "    <div id=\"settings\" class=\"meta\">

        ";
        // line 101
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Slug", "app"), "siteId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 103
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 103, $this->source); })()), "siteId", []), "id" => "slug", "name" => "slug", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 108
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 108, $this->source); })()), "slug", []), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enter slug", "app"), "errors" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Template::attribute($this->env, $this->source,         // line 110
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 110, $this->source); })()), "getErrors", [0 => "slug"], "method"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 110, $this->source); })()), "getErrors", [0 => "uri"], "method"))]], 101, $context, $this->getSourceContext());
        // line 111
        echo "

        ";
        // line 113
        if ((isset($context["parentOptionCriteria"]) || array_key_exists("parentOptionCriteria", $context))) {
            // line 114
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_elementSelectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Parent", "app"), "id" => "parentId", "name" => "parentId", "elementType" =>             // line 118
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 118, $this->source); })()), "selectionLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"), "sources" => [0 => ("group:" . craft\helpers\Template::attribute($this->env, $this->source,             // line 120
(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 120, $this->source); })()), "uid", []))], "criteria" =>             // line 121
(isset($context["parentOptionCriteria"]) || array_key_exists("parentOptionCriteria", $context) ? $context["parentOptionCriteria"] : (function () { throw new RuntimeError('Variable "parentOptionCriteria" does not exist.', 121, $this->source); })()), "limit" => 1, "elements" => (((            // line 123
(isset($context["parent"]) || array_key_exists("parent", $context)) && (isset($context["parent"]) || array_key_exists("parent", $context) ? $context["parent"] : (function () { throw new RuntimeError('Variable "parent" does not exist.', 123, $this->source); })()))) ? ([0 => (isset($context["parent"]) || array_key_exists("parent", $context) ? $context["parent"] : (function () { throw new RuntimeError('Variable "parent" does not exist.', 123, $this->source); })())]) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 124
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 124, $this->source); })()), "getErrors", [0 => "parent"], "method")]], 114, $context, $this->getSourceContext());
            // line 125
            echo "
        ";
        }
        // line 127
        echo "
        ";
        // line 128
        echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "id" => "enabled", "name" => "enabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 132
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 132, $this->source); })()), "enabled", [])]], 128, $context, $this->getSourceContext());
        // line 133
        echo "

    </div>

    ";
        // line 137
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 137, $this->source); })()), "id", [])) {
            // line 138
            echo "        <div class=\"meta read-only\">
            <div class=\"data\">
                <h5 class=\"heading\">";
            // line 140
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Date Created", "app"), "html", null, true);
            echo "</h5>
                <div class=\"value\">";
            // line 141
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 141, $this->source); })()), "dateCreated", []), "short"), "html", null, true);
            echo "</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">";
            // line 144
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Date Updated", "app"), "html", null, true);
            echo "</h5>
                <div class=\"value\">";
            // line 145
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 145, $this->source); })()), "dateUpdated", []), "short"), "html", null, true);
            echo "</div>
            </div>
        </div>
    ";
        }
        // line 149
        echo "
    ";
        // line 151
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.categories.edit.details", $context);

        craft\helpers\Template::endProfile("block", "details");
    }

    public function getTemplateName()
    {
        return "categories/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  293 => 151,  290 => 149,  283 => 145,  279 => 144,  273 => 141,  269 => 140,  265 => 138,  263 => 137,  257 => 133,  255 => 132,  254 => 128,  251 => 127,  247 => 125,  245 => 124,  244 => 123,  243 => 121,  242 => 120,  241 => 118,  239 => 114,  237 => 113,  233 => 111,  231 => 110,  230 => 108,  229 => 103,  228 => 101,  224 => 99,  219 => 98,  212 => 95,  206 => 91,  202 => 89,  197 => 88,  193 => 87,  189 => 86,  184 => 84,  179 => 83,  174 => 82,  168 => 78,  166 => 76,  165 => 75,  164 => 74,  162 => 73,  159 => 72,  156 => 71,  153 => 70,  148 => 69,  139 => 65,  135 => 63,  127 => 61,  124 => 60,  118 => 58,  116 => 57,  113 => 56,  111 => 55,  105 => 52,  101 => 51,  98 => 50,  93 => 49,  87 => 1,  80 => 158,  77 => 157,  75 => 156,  73 => 155,  70 => 47,  68 => 42,  67 => 37,  66 => 34,  65 => 32,  64 => 27,  63 => 25,  62 => 21,  61 => 15,  60 => 12,  58 => 10,  56 => 9,  54 => 7,  52 => 6,  50 => 5,  48 => 4,  46 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% import \"_includes/forms\" as forms %}

{% set fullPageForm = true %}
{% set saveShortcutRedirect = continueEditingUrl %}
{% set retainScrollOnSaveShortcut = true %}
{% do view.setIsDeltaRegistrationActive(true) %}

{% set groupHandle = group.handle %}
{% set isNewCategory = category.id ? false : true %}

{% set formActions = [
    {
        label: 'Save and continue editing'|t('app'),
        redirect: continueEditingUrl|hash,
        shortcut: true,
        retainScroll: true,
    },
    {
        label: 'Save and add another'|t('app'),
        redirect: nextCategoryUrl|hash,
        shortcut: true,
        shift: true,
    },
    not isNewCategory ? {
        label: 'Save as a new {type}'|t('app', {
            type: category.lowerDisplayName(),
        }),
        params: {
            duplicate: '1',
        },
        redirect: (continueEditingUrl~'#')|hash,
    },
    not isNewCategory ? {
        destructive: true,
        label: 'Delete {type}'|t('app', {
            type: category.lowerDisplayName()
        }),
        action: 'categories/delete-category',
        redirect: 'categories#'|hash,
        confirm: 'Are you sure you want to delete this {type}?'|t('app', {
            type: category.lowerDisplayName(),
        }),
    }
]|filter %}

{% hook \"cp.categories.edit\" %}

{% block header %}
    <div class=\"flex flex-nowrap\">
        {{ block('pageTitle') }}
        {{ block('contextMenu') }}
    </div>
    <div class=\"flex\">
        {% if showPreviewBtn or shareUrl is defined %}
            <div class=\"btngroup\">
                {% if showPreviewBtn %}
                    <button type=\"button\" class=\"btn livepreviewbtn\" data-icon=\"view\">{{ \"Preview\"|t('app') }}</button>
                {% endif %}
                {% if shareUrl is defined %}
                    <a href=\"{{ shareUrl }}\" class=\"btn sharebtn\" data-icon=\"share\" rel=\"noopener\" target=\"_blank\">{{ 'Share'|t('app') }}</a>
                {% endif %}
            </div>
        {% endif %}
        {{ block('actionButton') }}
    </div>
{% endblock %}

{% block contextMenu %}
    {% if craft.app.getIsMultiSite() %}
        {% set parentIdParam = craft.app.request.getParam('parentId.0') ?: craft.app.request.getParam('parentId') %}
        {% set urlFormat = url(\"categories/#{groupHandle}/#{craft.app.request.getSegment(3)}/{handle}\", (parentIdParam ? { parentId: parentIdParam })) %}
        {% include \"_elements/sitemenu\" with {
            siteIds: siteIds,
            selectedSiteId: category.siteId,
            urlFormat: urlFormat
        } only %}
    {% endif %}
{% endblock %}


{% block content %}
    {{ actionInput('categories/save-category') }}
    {{ redirectInput('categories/'~groupHandle) }}

    {{ hiddenInput('groupId', group.id) }}
    {% if category.id %}{{ hiddenInput('categoryId', category.id) }}{% endif %}
    {% if craft.app.getIsMultiSite() %}{{ hiddenInput('siteId', category.siteId) }}{% endif %}

    <div id=\"fields\">
        {{ fieldsHtml|raw }}
    </div>

    {# Give plugins a chance to add other things here #}
    {% hook \"cp.categories.edit.content\" %}
{% endblock %}

{% block details %}
    <div id=\"settings\" class=\"meta\">

        {{ forms.textField({
            label: \"Slug\"|t('app'),
            siteId: category.siteId,
            id: 'slug',
            name: 'slug',
            autocorrect: false,
            autocapitalize: false,
            value: category.slug,
            placeholder: \"Enter slug\"|t('app'),
            errors: (category.getErrors('slug')|merge(category.getErrors('uri')))
        }) }}

        {% if parentOptionCriteria is defined %}
            {{ forms.elementSelectField({
                label: \"Parent\"|t('app'),
                id: 'parentId',
                name: 'parentId',
                elementType: elementType,
                selectionLabel: \"Choose\"|t('app'),
                sources: ['group:'~group.uid],
                criteria: parentOptionCriteria,
                limit: 1,
                elements: (parent is defined and parent ? [parent]),
                errors: category.getErrors('parent')
            }) }}
        {% endif %}

        {{ forms.lightswitchField({
            label: \"Enabled\"|t('app'),
            id: 'enabled',
            name: 'enabled',
            on: category.enabled
        }) }}

    </div>

    {% if category.id %}
        <div class=\"meta read-only\">
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Date Created\"|t('app') }}</h5>
                <div class=\"value\">{{ category.dateCreated|datetime('short') }}</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Date Updated\"|t('app') }}</h5>
                <div class=\"value\">{{ category.dateUpdated|datetime('short') }}</div>
            </div>
        </div>
    {% endif %}

    {# Give plugins a chance to add other stuff here #}
    {% hook \"cp.categories.edit.details\" %}
{% endblock %}


{% if not category.slug %}
    {% js %}
        window.slugGenerator = new Craft.SlugGenerator('#title', '#slug', {
            charMap: {{ craft.cp.getAsciiCharMap(category.site.language)|json_encode|raw }}
        });
    {% endjs %}
{% endif %}
", "categories/_edit", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/categories/_edit.html");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/radio */
class __TwigTemplate_9b7d20d23f50e061b5b7ada6f3aded560d6d0d724d710e8ca59fac51bcb099fb extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/radio");
        // line 1
        $context["value"] = (((isset($context["value"]) || array_key_exists("value", $context))) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 1, $this->source); })())) : ("1"));
        // line 3
        echo "<label";
        // line 4
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">
    <input type=\"radio\" value=\"";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 5, $this->source); })()), "html", null, true);
        echo "\"";
        // line 6
        if ((($context["id"]) ?? (false))) {
            echo " id=\"";
            echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 6, $this->source); })()), "html", null, true);
            echo "\"";
        }
        // line 7
        if ((($context["class"]) ?? (false))) {
            echo " class=\"";
            echo twig_escape_filter($this->env, (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 7, $this->source); })()), "html", null, true);
            echo "\"";
        }
        // line 8
        if ((($context["name"]) ?? (false))) {
            echo " name=\"";
            echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 8, $this->source); })()), "html", null, true);
            echo "\"";
        }
        // line 9
        if ((($context["checked"]) ?? (false))) {
            echo " checked";
        }
        // line 10
        if (((($context["autofocus"]) ?? (false)) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method"))) {
            echo " autofocus";
        }
        // line 11
        if ((($context["disabled"]) ?? (false))) {
            echo " disabled";
        }
        echo ">
    ";
        // line 12
        if ((isset($context["label"]) || array_key_exists("label", $context))) {
            echo (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 12, $this->source); })());
        }
        // line 13
        echo "</label>
";
        craft\helpers\Template::endProfile("template", "_includes/forms/radio");
    }

    public function getTemplateName()
    {
        return "_includes/forms/radio";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 13,  84 => 12,  78 => 11,  74 => 10,  70 => 9,  64 => 8,  58 => 7,  52 => 6,  49 => 5,  42 => 4,  40 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set value = (value is defined ? value : '1') -%}

<label
        {%- if block('attr') is defined %} {{ block('attr') }}{% endif %}>
    <input type=\"radio\" value=\"{{ value }}\"
        {%- if id ?? false %} id=\"{{ id }}\"{% endif %}
        {%- if class ?? false %} class=\"{{ class }}\"{% endif %}
        {%- if name ?? false %} name=\"{{ name }}\"{% endif %}
        {%- if checked ?? false %} checked{% endif %}
        {%- if (autofocus ?? false) and not craft.app.request.isMobileBrowser(true) %} autofocus{% endif %}
        {%- if disabled ?? false %} disabled{% endif %}>
    {% if label is defined %}{{ label|raw }}{% endif %}
</label>
", "_includes/forms/radio", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_includes/forms/radio.html");
    }
}

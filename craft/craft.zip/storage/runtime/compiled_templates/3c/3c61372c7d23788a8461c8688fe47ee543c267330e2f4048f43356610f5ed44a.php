<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/base */
class __TwigTemplate_45aecedcd3ea790e87fd79fb73b1498715a612b82e51012142528282b9248477 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'body' => [$this, 'block_body'],
            'foot' => [$this, 'block_foot'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/base");
        // line 1
        $context["systemName"] = $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "app", []), "getSystemName", [], "method"), "site");
        // line 2
        $context["docTitle"] = (((isset($context["docTitle"]) || array_key_exists("docTitle", $context))) ? ((isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 2, $this->source); })())) : (strip_tags((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 2, $this->source); })()))));
        // line 3
        $context["orientation"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", []), "locale", []), "getOrientation", [], "method");
        // line 5
        $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass((($context["bodyClass"]) ?? ([]))), [0 =>         // line 6
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 6, $this->source); })()), 1 => (((        // line 7
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 7, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 7, $this->source); })()), "getPreference", [0 => "useShapes"], "method"))) ? ("use-shapes") : ("")), 2 => (((        // line 8
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 8, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 8, $this->source); })()), "getPreference", [0 => "underlineLinks"], "method"))) ? ("underline-links") : (""))]));
        // line 11
        $context["bodyAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" =>         // line 12
(isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 12, $this->source); })()), "dir" =>         // line 13
(isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 13, $this->source); })())], ((        // line 14
$context["bodyAttributes"]) ?? ([])), true);
        // line 16
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 16, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\cp\\CpAsset"], "method");
        // line 17
        $context["cpAssetUrl"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 17, $this->source); })()), "getAssetManager", [], "method"), "getPublishedUrl", [0 => "@app/web/assets/cp/dist", 1 => true], "method");
        // line 19
        echo \Craft::$app->getView()->invokeHook("cp.layouts.base", $context);

        // line 21
        echo "<!DOCTYPE html>
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"";
        // line 22
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 22, $this->source); })()), "app", []), "language", []), "html", null, true);
        echo "\">
<head>
    ";
        // line 24
        $this->displayBlock('head', $context, $blocks);
        // line 51
        echo "</head>
<body ";
        // line 52
        echo craft\helpers\Html::renderTagAttributes((isset($context["bodyAttributes"]) || array_key_exists("bodyAttributes", $context) ? $context["bodyAttributes"] : (function () { throw new RuntimeError('Variable "bodyAttributes" does not exist.', 52, $this->source); })()));
        echo ">
    ";
        // line 53
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "
    ";
        // line 54
        $this->displayBlock('body', $context, $blocks);
        // line 55
        echo "    ";
        $this->displayBlock('foot', $context, $blocks);
        // line 56
        echo "    ";
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), []);
        echo "
</body>
</html>
";
        craft\helpers\Template::endProfile("template", "_layouts/base");
    }

    // line 24
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "head");
        // line 25
        echo "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <title>";
        // line 27
        echo twig_escape_filter($this->env, (((isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 27, $this->source); })()) . (((twig_length_filter($this->env, (isset($context["docTitle"]) || array_key_exists("docTitle", $context) ? $context["docTitle"] : (function () { throw new RuntimeError('Variable "docTitle" does not exist.', 27, $this->source); })())) && twig_length_filter($this->env, (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 27, $this->source); })())))) ? (" - ") : (""))) . (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 27, $this->source); })())), "html", null, true);
        echo "</title>
    ";
        // line 28
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">
    <meta name=\"referrer\" content=\"origin-when-cross-origin\">

    ";
        // line 32
        $context["hasCustomIcon"] = false;
        // line 33
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 33, $this->source); })()), "app", []), "config", []), "general", []), "cpHeadTags", []));
        foreach ($context['_seq'] as $context["_key"] => $context["tag"]) {
            // line 34
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 0, [], "array"), craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array"));
            echo "
        ";
            // line 35
            if (((craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 0, [], "array") == "link") && ((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true), "rel", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true), "rel", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["tag"], 1, [], "array", false, true), "rel", [])) : (null)) == "icon"))) {
                // line 36
                echo "            ";
                $context["hasCustomIcon"] = true;
                // line 37
                echo "        ";
            }
            // line 38
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tag'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "    ";
        if ( !(isset($context["hasCustomIcon"]) || array_key_exists("hasCustomIcon", $context) ? $context["hasCustomIcon"] : (function () { throw new RuntimeError('Variable "hasCustomIcon" does not exist.', 39, $this->source); })())) {
            // line 40
            echo "        <link rel=\"icon\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 40, $this->source); })()), "html", null, true);
            echo "/images/icons/favicon.ico\">
        <link rel=\"icon\" type=\"image/svg+xml\" sizes=\"any\" href=\"";
            // line 41
            echo twig_escape_filter($this->env, (isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 41, $this->source); })()), "html", null, true);
            echo "/images/icons/icon.svg\">
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"";
            // line 42
            echo twig_escape_filter($this->env, (isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 42, $this->source); })()), "html", null, true);
            echo "/images/icons/apple-touch-icon.png\">
        <link rel=\"mask-icon\" href=\"";
            // line 43
            echo twig_escape_filter($this->env, (isset($context["cpAssetUrl"]) || array_key_exists("cpAssetUrl", $context) ? $context["cpAssetUrl"] : (function () { throw new RuntimeError('Variable "cpAssetUrl" does not exist.', 43, $this->source); })()), "html", null, true);
            echo "/images/icons/safari-pinned-tab.svg\" color=\"#e5422b\">
    ";
        }
        // line 45
        echo "
    <script type=\"text/javascript\">
        // Fix for Firefox autofocus CSS bug
        // See: http://stackoverflow.com/questions/18943276/html-5-autofocus-messes-up-css-loading/18945951#18945951
    </script>
    ";
        craft\helpers\Template::endProfile("block", "head");
    }

    // line 54
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        craft\helpers\Template::endProfile("block", "body");
    }

    // line 55
    public function block_foot($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "foot");
        craft\helpers\Template::endProfile("block", "foot");
    }

    public function getTemplateName()
    {
        return "_layouts/base";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  185 => 55,  177 => 54,  167 => 45,  162 => 43,  158 => 42,  154 => 41,  149 => 40,  146 => 39,  140 => 38,  137 => 37,  134 => 36,  132 => 35,  127 => 34,  122 => 33,  120 => 32,  113 => 28,  109 => 27,  105 => 25,  100 => 24,  90 => 56,  87 => 55,  85 => 54,  81 => 53,  77 => 52,  74 => 51,  72 => 24,  67 => 22,  64 => 21,  61 => 19,  59 => 17,  57 => 16,  55 => 14,  54 => 13,  53 => 12,  52 => 11,  50 => 8,  49 => 7,  48 => 6,  47 => 5,  45 => 3,  43 => 2,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set systemName = craft.app.getSystemName()|t('site') -%}
{% set docTitle = docTitle is defined ? docTitle : title|striptags -%}
{% set orientation = craft.app.locale.getOrientation() -%}

{% set bodyClass = (bodyClass ?? [])|explodeClass|merge([
    orientation,
    currentUser and currentUser.getPreference('useShapes') ? 'use-shapes',
    currentUser and currentUser.getPreference('underlineLinks') ? 'underline-links',
])|filter -%}

{% set bodyAttributes = {
    class: bodyClass,
    dir: orientation,
}|merge(bodyAttributes ?? {}, recursive=true) -%}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\cp\\\\CpAsset') -%}
{% set cpAssetUrl = view.getAssetManager().getPublishedUrl('@app/web/assets/cp/dist', true) -%}

{% hook \"cp.layouts.base\" -%}

<!DOCTYPE html>
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"{{ craft.app.language }}\">
<head>
    {% block head %}
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <title>{{ docTitle ~ (docTitle|length and systemName|length ? ' - ') ~ systemName }}</title>
    {{ head() }}
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">
    <meta name=\"referrer\" content=\"origin-when-cross-origin\">

    {% set hasCustomIcon = false %}
    {% for tag in craft.app.config.general.cpHeadTags %}
        {{ tag(tag[0], tag[1]) }}
        {% if tag[0] == 'link' and (tag[1].rel ?? null) == 'icon' %}
            {% set hasCustomIcon = true %}
        {% endif %}
    {% endfor %}
    {% if not hasCustomIcon %}
        <link rel=\"icon\" href=\"{{ cpAssetUrl }}/images/icons/favicon.ico\">
        <link rel=\"icon\" type=\"image/svg+xml\" sizes=\"any\" href=\"{{ cpAssetUrl }}/images/icons/icon.svg\">
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"{{ cpAssetUrl }}/images/icons/apple-touch-icon.png\">
        <link rel=\"mask-icon\" href=\"{{ cpAssetUrl }}/images/icons/safari-pinned-tab.svg\" color=\"#e5422b\">
    {% endif %}

    <script type=\"text/javascript\">
        // Fix for Firefox autofocus CSS bug
        // See: http://stackoverflow.com/questions/18943276/html-5-autofocus-messes-up-css-loading/18945951#18945951
    </script>
    {% endblock %}
</head>
<body {{ attr(bodyAttributes) }}>
    {{ beginBody() }}
    {% block body %}{% endblock %}
    {% block foot %}{% endblock %}
    {{ endBody() }}
</body>
</html>
", "_layouts/base", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_layouts/base.html");
    }
}

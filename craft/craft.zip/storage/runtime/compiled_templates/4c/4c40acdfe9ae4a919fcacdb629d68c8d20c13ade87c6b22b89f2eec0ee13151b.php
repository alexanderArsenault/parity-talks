<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/element */
class __TwigTemplate_fb837c95d7f2b161a8fe64032beabcbf02ac14e06aa08e0ed458010410bcdc64 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'contextMenu' => [$this, 'block_contextMenu'],
            'actionButton' => [$this, 'block_actionButton'],
            'main' => [$this, 'block_main'],
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
            'meta' => [$this, 'block_meta'],
            'settings' => [$this, 'block_settings'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 27
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/element");
        // line 28
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_layouts/element", 28)->unwrap();
        // line 30
        $context["isDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 30, $this->source); })()), "getIsDraft", [], "method");
        // line 31
        $context["isRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 31, $this->source); })()), "getIsRevision", [], "method");
        // line 32
        $context["isCurrent"] = ( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 32, $this->source); })()) &&  !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 32, $this->source); })()));
        // line 33
        $context["allSites"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 33, $this->source); })()), "app", []), "isMultiSite", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 33, $this->source); })()), "getSupportedSites", [], "method")) : ([0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 33, $this->source); })()), "siteId", [])]));
        // line 34
        $context["allEditableSiteIds"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 34, $this->source); })()), "app", []), "sites", []), "getEditableSiteIds", [], "method");
        // line 35
        $context["propSiteIds"] = craft\helpers\ArrayHelper::getColumn($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, (isset($context["allSites"]) || array_key_exists("allSites", $context) ? $context["allSites"] : (function () { throw new RuntimeError('Variable "allSites" does not exist.', 35, $this->source); })()), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "propagate", [])) : (true)); }), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])) : ((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 35, $this->source); })()))); });
        // line 36
        $context["propEditableSiteIds"] = array_intersect((isset($context["propSiteIds"]) || array_key_exists("propSiteIds", $context) ? $context["propSiteIds"] : (function () { throw new RuntimeError('Variable "propSiteIds" does not exist.', 36, $this->source); })()), (isset($context["allEditableSiteIds"]) || array_key_exists("allEditableSiteIds", $context) ? $context["allEditableSiteIds"] : (function () { throw new RuntimeError('Variable "allEditableSiteIds" does not exist.', 36, $this->source); })()));
        // line 37
        $context["isMultiSiteElement"] = (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 37, $this->source); })()), "app", []), "isMultiSite", []) && (twig_length_filter($this->env, (isset($context["allSites"]) || array_key_exists("allSites", $context) ? $context["allSites"] : (function () { throw new RuntimeError('Variable "allSites" does not exist.', 37, $this->source); })())) > 1));
        // line 38
        $context["addlEditableSiteIds"] = array_intersect(array_diff(craft\helpers\ArrayHelper::getColumn((isset($context["allSites"]) || array_key_exists("allSites", $context) ? $context["allSites"] : (function () { throw new RuntimeError('Variable "allSites" does not exist.', 38, $this->source); })()), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])) : ((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 38, $this->source); })()))); }), (isset($context["propSiteIds"]) || array_key_exists("propSiteIds", $context) ? $context["propSiteIds"] : (function () { throw new RuntimeError('Variable "propSiteIds" does not exist.', 38, $this->source); })())), (isset($context["allEditableSiteIds"]) || array_key_exists("allEditableSiteIds", $context) ? $context["allEditableSiteIds"] : (function () { throw new RuntimeError('Variable "allEditableSiteIds" does not exist.', 38, $this->source); })()));
        // line 39
        $context["canEditMultipleSites"] = ((isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 39, $this->source); })()) && ((twig_length_filter($this->env, (isset($context["propEditableSiteIds"]) || array_key_exists("propEditableSiteIds", $context) ? $context["propEditableSiteIds"] : (function () { throw new RuntimeError('Variable "propEditableSiteIds" does not exist.', 39, $this->source); })())) > 1) || twig_length_filter($this->env, (isset($context["addlEditableSiteIds"]) || array_key_exists("addlEditableSiteIds", $context) ? $context["addlEditableSiteIds"] : (function () { throw new RuntimeError('Variable "addlEditableSiteIds" does not exist.', 39, $this->source); })()))));
        // line 40
        $context["isUnsavedDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 40, $this->source); })()), "getIsUnsavedDraft", [], "method");
        // line 42
        $context["previewTargets"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 42, $this->source); })()), "getPreviewTargets", [], "method");
        // line 43
        $context["enablePreview"] = ((isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 43, $this->source); })()) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 43, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method"));
        // line 45
        $context["canDeleteDraft"] = (((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 45, $this->source); })()) &&  !(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 45, $this->source); })())) && ((($context["canDeleteDraft"]) ?? (false)) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 45, $this->source); })()), "creatorId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 45, $this->source); })()), "id", []))));
        // line 46
        $context["canUpdateSource"] = (($context["canUpdateSource"]) ?? (false));
        // line 47
        $context["canDuplicateSource"] = (($context["canDuplicateSource"]) ?? (false));
        // line 48
        $context["canAddAnother"] = (($context["canAddAnother"]) ?? (false));
        // line 49
        $context["canDeleteSource"] = (($context["canDeleteSource"]) ?? (false));
        // line 50
        $context["canEdit"] = (($context["canEdit"]) ?? (((((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 50, $this->source); })()) || (isset($context["canDuplicateSource"]) || array_key_exists("canDuplicateSource", $context) ? $context["canDuplicateSource"] : (function () { throw new RuntimeError('Variable "canDuplicateSource" does not exist.', 50, $this->source); })())) || (isset($context["canAddAnother"]) || array_key_exists("canAddAnother", $context) ? $context["canAddAnother"] : (function () { throw new RuntimeError('Variable "canAddAnother" does not exist.', 50, $this->source); })())) || (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 50, $this->source); })()))));
        // line 52
        $context["redirectUrl"] = (($context["redirectUrl"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 52, $this->source); })()), "cpEditUrl", [])));
        // line 53
        $context["addAnotherRedirectUrl"] = (($context["addAnotherRedirectUrl"]) ?? (null));
        // line 55
        $context["saveSourceAction"] = (($context["saveSourceAction"]) ?? (null));
        // line 56
        $context["duplicateSourceAction"] = (($context["duplicateSourceAction"]) ?? (null));
        // line 57
        $context["deleteSourceAction"] = (($context["deleteSourceAction"]) ?? (null));
        // line 58
        $context["revertSourceAction"] = (($context["revertSourceAction"]) ?? (null));
        // line 59
        $context["saveDraftAction"] = (($context["saveDraftAction"]) ?? (null));
        // line 61
        if ( !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 61, $this->source); })())) {
            // line 62
            $context["fullPageForm"] = true;
        }
        // line 65
        if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 65, $this->source); })())) {
            // line 66
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 66, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewDraft:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 66, $this->source); })()), "draftId", []))], "method");
        } elseif (        // line 67
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 67, $this->source); })())) {
            // line 68
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 68, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewRevision:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 68, $this->source); })()), "revisionId", []))], "method");
        } else {
            // line 70
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 70, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewElement:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 70, $this->source); })()), "id", []))], "method");
        }
        // line 75
        $context["showStatusToggles"] = (((($context["showStatusToggles"]) ?? (true)) && craft\helpers\Template::attribute($this->env, $this->source,         // line 76
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 76, $this->source); })()), "hasStatuses", [], "method")) && ( !        // line 77
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 77, $this->source); })()) || (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 77, $this->source); })())));
        // line 79
        if (( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 79, $this->source); })()) &&  !(isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 79, $this->source); })()))) {
            // line 80
            $context["saveShortcut"] = false;
        } elseif ((        // line 81
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 81, $this->source); })()) || ((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 81, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 81, $this->source); })())))) {
            // line 82
            $context["saveShortcutRedirect"] = "{cpEditUrl}";
        }
        // line 85
        $context["form"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 85, $this->source); })()), "getFieldLayout", [], "method"), "createForm", [0 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 85, $this->source); })()), 1 => ((isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 85, $this->source); })()) ||  !(isset($context["canEdit"]) || array_key_exists("canEdit", $context) ? $context["canEdit"] : (function () { throw new RuntimeError('Variable "canEdit" does not exist.', 85, $this->source); })()))], "method");
        // line 87
        if ( !(isset($context["tabs"]) || array_key_exists("tabs", $context))) {
            // line 88
            $context["tabs"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 88, $this->source); })()), "getTabMenu", [], "method");
        }
        // line 91
        $context["settingsHtml"] = twig_trim_filter(((        $this->hasBlock("settings", $context, $blocks)) ? (        $this->renderBlock("settings", $context, $blocks)) : ("")));
        // line 93
        $context["formActions"] = [];
        // line 94
        if (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 94, $this->source); })()) || ((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 94, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 94, $this->source); })())))) {
            // line 95
            $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 95, $this->source); })()), ["label" => ((            // line 96
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 96, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Create and continue editing", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"))), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), ["{cpEditUrl}"]), "shortcut" => true, "retainScroll" => true]);
            // line 101
            if ((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 101, $this->source); })())) {
                // line 102
                if (((isset($context["canAddAnother"]) || array_key_exists("canAddAnother", $context) ? $context["canAddAnother"] : (function () { throw new RuntimeError('Variable "canAddAnother" does not exist.', 102, $this->source); })()) && (isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 102, $this->source); })()))) {
                    // line 103
                    $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 103, $this->source); })()), ["label" => ((                    // line 104
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 104, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Create and add another", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Save and add another", "app"))), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [                    // line 105
(isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 105, $this->source); })())]), "shortcut" => true, "shift" => true]);
                }
                // line 110
                if ((( !(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 110, $this->source); })()) && (isset($context["canDuplicateSource"]) || array_key_exists("canDuplicateSource", $context) ? $context["canDuplicateSource"] : (function () { throw new RuntimeError('Variable "canDuplicateSource" does not exist.', 110, $this->source); })())) && (isset($context["duplicateSourceAction"]) || array_key_exists("duplicateSourceAction", $context) ? $context["duplicateSourceAction"] : (function () { throw new RuntimeError('Variable "duplicateSourceAction" does not exist.', 110, $this->source); })()))) {
                    // line 111
                    $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 111, $this->source); })()), ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a new {type}", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 113
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 113, $this->source); })()), "lowerDisplayName", [], "method")]), "action" =>                     // line 115
(isset($context["duplicateSourceAction"]) || array_key_exists("duplicateSourceAction", $context) ? $context["duplicateSourceAction"] : (function () { throw new RuntimeError('Variable "duplicateSourceAction" does not exist.', 115, $this->source); })()), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), ["{cpEditUrl}"])]);
                }
            }
            // line 120
            if ((( !(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 120, $this->source); })()) && (isset($context["canDeleteSource"]) || array_key_exists("canDeleteSource", $context) ? $context["canDeleteSource"] : (function () { throw new RuntimeError('Variable "canDeleteSource" does not exist.', 120, $this->source); })())) && (isset($context["deleteSourceAction"]) || array_key_exists("deleteSourceAction", $context) ? $context["deleteSourceAction"] : (function () { throw new RuntimeError('Variable "deleteSourceAction" does not exist.', 120, $this->source); })()))) {
                // line 121
                $context["formActions"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["formActions"]) || array_key_exists("formActions", $context) ? $context["formActions"] : (function () { throw new RuntimeError('Variable "formActions" does not exist.', 121, $this->source); })()), ["destructive" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Delete {type}", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 124
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 124, $this->source); })()), "lowerDisplayName", [], "method")]), "action" =>                 // line 126
(isset($context["deleteSourceAction"]) || array_key_exists("deleteSourceAction", $context) ? $context["deleteSourceAction"] : (function () { throw new RuntimeError('Variable "deleteSourceAction" does not exist.', 126, $this->source); })()), "redirect" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [(                // line 127
(isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 127, $this->source); })()) . "#")]), "confirm" => $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to delete this {type}?", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 129
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 129, $this->source); })()), "lowerDisplayName", [], "method")])]);
            }
        }
        // line 363
        if (((isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 363, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 363, $this->source); })()), "enabled", []))) {
            // line 365
            $context["siteStatusesQuery"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 365, $this->source); })()), "find", [], "method"), "select", [0 => [0 => "elements_sites.siteId", 1 => "elements_sites.enabled"]], "method"), "id", [0 => craft\helpers\Template::attribute($this->env, $this->source,             // line 367
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 367, $this->source); })()), "id", [])], "method"), "siteId", [0 =>             // line 368
(isset($context["propEditableSiteIds"]) || array_key_exists("propEditableSiteIds", $context) ? $context["propEditableSiteIds"] : (function () { throw new RuntimeError('Variable "propEditableSiteIds" does not exist.', 368, $this->source); })())], "method"), "anyStatus", [], "method"), "asArray", [], "method");
            // line 371
            if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 371, $this->source); })())) {
                // line 372
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 372, $this->source); })()), "drafts", [], "method");
            } elseif (            // line 373
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 373, $this->source); })())) {
                // line 374
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 374, $this->source); })()), "revisions", [], "method");
            }
            // line 376
            $context["siteStatuses"] = twig_array_map(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 376, $this->source); })()), "pairs", [], "method"),             // line 377
function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 377, $this->source); })())) ? (true) : (false)); });
        } elseif (        // line 378
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 378, $this->source); })())) {
            // line 379
            $context["siteStatusValues"] = [];
            // line 380
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["propEditableSiteIds"]) || array_key_exists("propEditableSiteIds", $context) ? $context["propEditableSiteIds"] : (function () { throw new RuntimeError('Variable "propEditableSiteIds" does not exist.', 380, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["siteId"]) {
                // line 381
                $context["siteStatusValues"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteStatusValues"]) || array_key_exists("siteStatusValues", $context) ? $context["siteStatusValues"] : (function () { throw new RuntimeError('Variable "siteStatusValues" does not exist.', 381, $this->source); })()), [0 => false]);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['siteId'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 383
            $context["siteStatuses"] = array_combine((isset($context["propEditableSiteIds"]) || array_key_exists("propEditableSiteIds", $context) ? $context["propEditableSiteIds"] : (function () { throw new RuntimeError('Variable "propEditableSiteIds" does not exist.', 383, $this->source); })()), (isset($context["siteStatusValues"]) || array_key_exists("siteStatusValues", $context) ? $context["siteStatusValues"] : (function () { throw new RuntimeError('Variable "siteStatusValues" does not exist.', 383, $this->source); })()));
        } else {
            // line 385
            $context["siteStatuses"] = [craft\helpers\Template::attribute($this->env, $this->source,             // line 386
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 386, $this->source); })()), "siteId", []) => ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 386, $this->source); })()), "enabled", [])) ? (true) : (false))];
        }
        // line 390
        $context["settings"] = ["elementType" => get_class(        // line 391
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 391, $this->source); })())), "elementTypeDisplayName" => craft\helpers\Template::attribute($this->env, $this->source,         // line 392
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 392, $this->source); })()), "displayName", [], "method"), "sourceId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 393
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 393, $this->source); })()), "getSourceId", [], "method"), "siteId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 394
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 394, $this->source); })()), "siteId", []), "siteToken" => (( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 395
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 395, $this->source); })()), "getSite", [], "method"), "enabled", [])) ? (call_user_func_array($this->env->getFilter('hash')->getCallable(), [craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 395, $this->source); })()), "siteId", [])])) : ("")), "isUnsavedDraft" =>         // line 396
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 396, $this->source); })()), "siteStatuses" =>         // line 397
(isset($context["siteStatuses"]) || array_key_exists("siteStatuses", $context) ? $context["siteStatuses"] : (function () { throw new RuntimeError('Variable "siteStatuses" does not exist.', 397, $this->source); })()), "addlSiteIds" => array_values(        // line 398
(isset($context["addlEditableSiteIds"]) || array_key_exists("addlEditableSiteIds", $context) ? $context["addlEditableSiteIds"] : (function () { throw new RuntimeError('Variable "addlEditableSiteIds" does not exist.', 398, $this->source); })())), "enabled" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 399
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 399, $this->source); })()), "enabled", [])) ? (true) : (false)), "enabledForSite" => (craft\helpers\Template::attribute($this->env, $this->source,         // line 400
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 400, $this->source); })()), "enabled", []) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 400, $this->source); })()), "getEnabledForSite", [], "method")), "isLive" => (((        // line 401
(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 401, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 401, $this->source); })()), "enabled", [])) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 401, $this->source); })()), "getEnabledForSite", [], "method")) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 401, $this->source); })()), "getRoute", [], "method")), "cpEditUrl" => craft\helpers\Template::attribute($this->env, $this->source,         // line 402
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 402, $this->source); })()), "cpEditUrl", []), "hashedRedirectUrl" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [((        // line 403
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 403, $this->source); })())) ? ((isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 403, $this->source); })())) : ("{cpEditUrl}"))]), "draftId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 404
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 404, $this->source); })()), "draftId", []), "revisionId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 405
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 405, $this->source); })()), "revisionId", []), "draftName" => ((        // line 406
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 406, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 406, $this->source); })()), "draftName", [])) : (null)), "draftNotes" => ((        // line 407
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 407, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 407, $this->source); })()), "draftNotes", [])) : (null)), "canEditMultipleSites" =>         // line 408
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 408, $this->source); })()), "canDeleteDraft" =>         // line 409
(isset($context["canDeleteDraft"]) || array_key_exists("canDeleteDraft", $context) ? $context["canDeleteDraft"] : (function () { throw new RuntimeError('Variable "canDeleteDraft" does not exist.', 409, $this->source); })()), "canUpdateSource" =>         // line 410
(isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 410, $this->source); })()), "saveDraftAction" =>         // line 411
(isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 411, $this->source); })()), "deleteDraftAction" => ((        // line 412
$context["deleteDraftAction"]) ?? (null)), "applyDraftAction" => ((        // line 413
$context["applyDraftAction"]) ?? (null)), "enablePreview" =>         // line 414
(isset($context["enablePreview"]) || array_key_exists("enablePreview", $context) ? $context["enablePreview"] : (function () { throw new RuntimeError('Variable "enablePreview" does not exist.', 414, $this->source); })()), "previewTargets" =>         // line 415
(isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 415, $this->source); })())];
        // line 417
        ob_start();
        // line 418
        echo "    window.draftEditor = new Craft.DraftEditor(";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 418, $this->source); })()));
        echo ");
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 27
        $this->parent = $this->loadTemplate("_layouts/cp", "_layouts/element", 27);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_layouts/element");
    }

    // line 135
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "header");
        // line 136
        echo "    <div class=\"flex flex-nowrap\">
        ";
        // line 137
        $this->displayBlock("pageTitle", $context, $blocks);
        echo "
        ";
        // line 138
        $this->displayBlock("contextMenu", $context, $blocks);
        echo "
    </div>
    <div class=\"flex\" id=\"action-buttons\">
        ";
        // line 141
        if ((isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 141, $this->source); })())) {
            // line 142
            echo "            <div class=\"btngroup\">
                ";
            // line 143
            if ((isset($context["enablePreview"]) || array_key_exists("enablePreview", $context) ? $context["enablePreview"] : (function () { throw new RuntimeError('Variable "enablePreview" does not exist.', 143, $this->source); })())) {
                // line 144
                echo "                    <button type=\"button\" id=\"preview-btn\" class=\"btn\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Preview", "app"), "html", null, true);
                echo "</button>
                ";
            }
            // line 146
            echo "                <button type=\"button\" id=\"share-btn\" class=\"btn\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Share", "app"), "html", null, true);
            echo "</button>
            </div>
        ";
        }
        // line 149
        echo "
        ";
        // line 150
        if (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 150, $this->source); })()) && (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 150, $this->source); })()))) {
            // line 151
            echo "            <div id=\"save-draft-btn-container\">
                ";
            // line 152
            if (((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 152, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 152, $this->source); })()))) {
                // line 153
                echo "                    <button type=\"button\" id=\"save-draft-btn\" class=\"btn\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a draft", "app"), "html", null, true);
                echo "</button>
                ";
            } else {
                // line 155
                echo "                    <button type=\"submit\" id=\"save-draft-btn\" class=\"btn submit\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a draft", "app"), "html", null, true);
                echo "</button>
                ";
            }
            // line 157
            echo "            </div>
        ";
        }
        // line 159
        echo "
        ";
        // line 160
        $this->displayBlock("actionButton", $context, $blocks);
        echo "
    </div>
";
        craft\helpers\Template::endProfile("block", "header");
    }

    // line 164
    public function block_contextMenu($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "contextMenu");
        // line 165
        echo "    ";
        if ((((isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 165, $this->source); })()) || (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 165, $this->source); })())) || craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 165, $this->source); })()), "find", [], "method"), "revisionOf", [0 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 165, $this->source); })())], "method"), "exists", [], "method"))) {
            // line 166
            echo "        ";
            $this->loadTemplate("_includes/revisionmenu", "_layouts/element", 166)->display(twig_array_merge($context, ["supportedSiteIds" =>             // line 167
(isset($context["propSiteIds"]) || array_key_exists("propSiteIds", $context) ? $context["propSiteIds"] : (function () { throw new RuntimeError('Variable "propSiteIds" does not exist.', 167, $this->source); })()), "canHaveDrafts" =>  !twig_test_empty(            // line 168
(isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 168, $this->source); })()))]));
            // line 170
            echo "    ";
        }
        craft\helpers\Template::endProfile("block", "contextMenu");
    }

    // line 173
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 174
        echo "    ";
        if (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 174, $this->source); })()) || (isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 174, $this->source); })()))) {
            // line 175
            echo "        ";
            // line 176
            echo "        ";
            if (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 176, $this->source); })()) || ((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 176, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 176, $this->source); })())))) {
                // line 177
                echo "            <div id=\"save-btn-container\" class=\"btngroup submit\">
                ";
                // line 178
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "submit", "class" => [0 => "btn", 1 => "submit"], "text" => ((                // line 181
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 181, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Create", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app")))]);
                // line 182
                echo "
                <button type=\"button\" class=\"btn submit menubtn\"></button>
                ";
                // line 184
                $this->loadTemplate("_layouts/components/form-action-menu", "_layouts/element", 184)->display($context);
                // line 185
                echo "            </div>
        ";
            }
            // line 187
            echo "    ";
        } elseif ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 187, $this->source); })())) {
            // line 188
            echo "        ";
            if ((((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 188, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 188, $this->source); })())) && (($context["applyDraftAction"]) ?? (false)))) {
                // line 189
                echo "            <div id=\"publish-changes-btn-container\">
                <button type=\"button\" class=\"btn secondary formsubmit\" data-action=\"";
                // line 190
                echo twig_escape_filter($this->env, (isset($context["applyDraftAction"]) || array_key_exists("applyDraftAction", $context) ? $context["applyDraftAction"] : (function () { throw new RuntimeError('Variable "applyDraftAction" does not exist.', 190, $this->source); })()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Publish changes", "app"), "html", null, true);
                echo "</button>
            </div>
        ";
            }
            // line 193
            echo "        ";
            if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 193, $this->source); })()), "app", []), "config", []), "general", []), "autosaveDrafts", [])) {
                // line 194
                echo "            <div id=\"save-btn-container\">
                <button type=\"submit\" class=\"btn submit\">";
                // line 195
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save draft", "app"), "html", null, true);
                echo "</button>
            </div>
        ";
            }
            // line 198
            echo "    ";
        } elseif ((isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 198, $this->source); })())) {
            // line 199
            echo "        ";
            if (((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 199, $this->source); })()) && (isset($context["revertSourceAction"]) || array_key_exists("revertSourceAction", $context) ? $context["revertSourceAction"] : (function () { throw new RuntimeError('Variable "revertSourceAction" does not exist.', 199, $this->source); })()))) {
                // line 200
                echo "            <form method=\"post\" accept-charset=\"UTF-8\">
                ";
                // line 201
                echo craft\helpers\Html::csrfInput();
                echo "
                ";
                // line 202
                echo craft\helpers\Html::actionInput((isset($context["revertSourceAction"]) || array_key_exists("revertSourceAction", $context) ? $context["revertSourceAction"] : (function () { throw new RuntimeError('Variable "revertSourceAction" does not exist.', 202, $this->source); })()));
                echo "
                ";
                // line 203
                echo craft\helpers\Html::redirectInput("{cpEditUrl}");
                echo "
                ";
                // line 204
                echo craft\helpers\Html::hiddenInput("revisionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 204, $this->source); })()), "revisionId", []));
                echo "
                <div class=\"secondary-buttons\">
                    <button type=\"button\" class=\"btn submit formsubmit\">";
                // line 206
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Revert {type} to this revision", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 206, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
                echo "</button>
                </div>
            </form>
        ";
            }
            // line 210
            echo "    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 213
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 214
        echo "    ";
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 214, $this->source); })())) {
            // line 215
            echo "        ";
            // line 216
            echo "        ";
            if ((( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 216, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 216, $this->source); })())) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 216, $this->source); })()))) {
                // line 217
                echo "            ";
                // line 218
                echo "            ";
                echo craft\helpers\Html::actionInput((isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 218, $this->source); })()));
                echo "
            ";
                // line 219
                echo craft\helpers\Html::redirectInput((isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 219, $this->source); })()));
                echo "
        ";
            }
            // line 221
            echo "
        ";
            // line 223
            echo "        ";
            if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 223, $this->source); })()), "app", []), "isMultiSite", [])) {
                // line 224
                echo "            ";
                echo craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 224, $this->source); })()), "siteId", []));
                echo "
        ";
            }
            // line 226
            echo "
        ";
            // line 228
            echo "        ";
            if (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 228, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 228, $this->source); })()), "app", []), "request", []), "getQueryParam", [0 => "fresh"], "method"))) {
                // line 229
                echo "            ";
                echo craft\helpers\Html::hiddenInput("propagateAll", "1");
                echo "
        ";
            }
            // line 231
            echo "    ";
        }
        // line 232
        echo "    ";
        $this->displayParentBlock("main", $context, $blocks);
        echo "
";
        craft\helpers\Template::endProfile("block", "main");
    }

    // line 235
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 236
        echo "    ";
        if ( !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 236, $this->source); })())) {
            // line 237
            echo "        ";
            echo craft\helpers\Html::hiddenInput("sourceId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 237, $this->source); })()), "getSourceId", [], "method"));
            echo "
    ";
        } else {
            // line 239
            echo "        ";
            echo craft\helpers\Html::hiddenInput("revisionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 239, $this->source); })()), "revisionId", []));
            echo "
    ";
        }
        // line 241
        echo "
    <div id=\"fields\">
        ";
        // line 243
        echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 243, $this->source); })()), "render", [], "method");
        echo "
    </div>
";
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 247
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 248
        echo "    ";
        if ((isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 248, $this->source); })())) {
            // line 249
            echo "        <div id=\"settings\" class=\"meta\">
            ";
            // line 250
            echo (isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 250, $this->source); })());
            echo "
        </div>
    ";
        }
        // line 253
        echo "
    ";
        // line 254
        if (((isset($context["showStatusToggles"]) || array_key_exists("showStatusToggles", $context) ? $context["showStatusToggles"] : (function () { throw new RuntimeError('Variable "showStatusToggles" does not exist.', 254, $this->source); })()) && (isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 254, $this->source); })()))) {
            // line 255
            echo "        <div class=\"meta\">
            ";
            // line 256
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 257
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 257, $this->source); })()), "getAttributeStatus", [0 => "enabled"], "method"), "label" => ($this->extensions['craft\web\twig\Extension']->translateFilter("Enabled for {site}", "app", ["site" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 258
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 258, $this->source); })()), "site", []), "name", []), "site"))]) . ((            // line 259
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 259, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "button", "id" => "expand-status-btn", "class" => [0 => "btn"], "data" => ["icon" => "ellipsis"]])) : (""))), "id" => ("enabledForSite-" . craft\helpers\Template::attribute($this->env, $this->source,             // line 267
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 267, $this->source); })()), "siteId", [])), "name" => (("enabledForSite[" . craft\helpers\Template::attribute($this->env, $this->source,             // line 268
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 268, $this->source); })()), "siteId", [])) . "]"), "on" => (craft\helpers\Template::attribute($this->env, $this->source,             // line 269
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 269, $this->source); })()), "enabled", []) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 269, $this->source); })()), "getEnabledForSite", [], "method")), "disabled" =>             // line 270
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 270, $this->source); })())]], 256, $context, $this->getSourceContext());
            // line 271
            echo "
        </div>
    ";
        }
        // line 274
        echo "
    <div id=\"meta-details\" class=\"meta read-only\">
        ";
        // line 276
        $this->displayBlock('meta', $context, $blocks);
        // line 314
        echo "    </div>

    ";
        // line 316
        if (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 316, $this->source); })()) && (($context["hasRevisions"]) ?? (false)))) {
            // line 317
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_textarea", [["id" => "revision-notes", "class" => [0 => "nicetext"], "name" => "revisionNotes", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Notes about your changes", "app"), "value" => ((            // line 322
$context["revisionNotes"]) ?? (null)), "inputAttributes" => ["aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Notes about your changes", "app")]]]], 317, $context, $this->getSourceContext());
            // line 328
            echo "
    ";
        }
        // line 330
        echo "
    ";
        // line 331
        if (((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 331, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 331, $this->source); })()), "getIsOutdated", [], "method"))) {
            // line 332
            echo "        ";
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 332, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("mergeDraftSourceChanges:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 332, $this->source); })()), "draftId", []))], "method");
            // line 333
            echo "        <div class=\"meta read-only warning\">
            <p>";
            // line 334
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("The source {type} has been updated recently.", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 334, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
            echo "</p>
            <div class=\"flex flex-nowrap\">
                ";
            // line 336
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 336, $this->source); })()), "trackChanges", [])) {
                // line 337
                echo "                    ";
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["type" => "button", "id" => "merge-changes-btn", "class" => [0 => "btn"], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Merge changes into draft", "app")]);
                // line 342
                echo "
                    <div id=\"merge-changes-spinner\" class=\"spinner hidden\"></div>
                ";
            }
            // line 345
            echo "            </div>
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "details");
    }

    // line 276
    public function block_meta($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "meta");
        // line 277
        echo "            ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 277, $this->source); })()), "hasStatuses", [], "method")) {
            // line 278
            echo "                ";
            if ((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 278, $this->source); })())) {
                // line 279
                echo "                    ";
                $context["statusColor"] = "white";
                // line 280
                echo "                    ";
                $context["statusLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Draft", "app");
                // line 281
                echo "                ";
            } else {
                // line 282
                echo "                    ";
                $context["status"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 282, $this->source); })()), "getStatus", [], "method");
                // line 283
                echo "                    ";
                $context["statusDef"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 283, $this->source); })()), [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 283, $this->source); })()), [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 283, $this->source); })()), [], "array")) : (null));
                // line 284
                echo "                    ";
                $context["statusColor"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [])) : ((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 284, $this->source); })())));
                // line 285
                echo "                    ";
                $context["statusLabel"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [])) : ((($context["statusDef"]) ?? ($this->extensions['craft\web\twig\Extension']->ucfirstFilter((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 285, $this->source); })()))))));
                // line 286
                echo "                ";
            }
            // line 287
            echo "                <div class=\"data\">
                    <h5 class=\"heading\">";
            // line 288
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Status", "app"), "html", null, true);
            echo "</h5>
                    <div id=\"status-value\" class=\"value\"><span class=\"status ";
            // line 289
            echo twig_escape_filter($this->env, (isset($context["statusColor"]) || array_key_exists("statusColor", $context) ? $context["statusColor"] : (function () { throw new RuntimeError('Variable "statusColor" does not exist.', 289, $this->source); })()), "html", null, true);
            echo "\"></span>";
            echo twig_escape_filter($this->env, (isset($context["statusLabel"]) || array_key_exists("statusLabel", $context) ? $context["statusLabel"] : (function () { throw new RuntimeError('Variable "statusLabel" does not exist.', 289, $this->source); })()), "html", null, true);
            echo "</div>
                </div>
            ";
        }
        // line 292
        echo "            <div class=\"data\">
                <h5 class=\"heading\">";
        // line 293
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Created at", "app"), "html", null, true);
        echo "</h5>
                <div id=\"date-created-value\" class=\"value\">";
        // line 294
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 294, $this->source); })()), "dateCreated", []), "short"), "html", null, true);
        echo "</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">";
        // line 297
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Updated at", "app"), "html", null, true);
        echo "</h5>
                <div id=\"date-updated-value\" class=\"value\">";
        // line 298
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 298, $this->source); })()), "dateUpdated", []), "short"), "html", null, true);
        echo "</div>
            </div>
            ";
        // line 300
        if ((isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 300, $this->source); })())) {
            // line 301
            echo "                ";
            $context["revisionNotes"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 301, $this->source); })()), "revisionNotes", []);
            // line 302
            echo "            ";
        } elseif (( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 302, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 302, $this->source); })()), "currentRevision", []))) {
            // line 303
            echo "                ";
            $context["revisionNotes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 303, $this->source); })()), "currentRevision", []), "revisionNotes", []);
            // line 304
            echo "            ";
        } else {
            // line 305
            echo "                ";
            $context["revisionNotes"] = null;
            // line 306
            echo "            ";
        }
        // line 307
        echo "            ";
        if ((isset($context["revisionNotes"]) || array_key_exists("revisionNotes", $context) ? $context["revisionNotes"] : (function () { throw new RuntimeError('Variable "revisionNotes" does not exist.', 307, $this->source); })())) {
            // line 308
            echo "                <div class=\"data\">
                    <h5 class=\"heading\">";
            // line 309
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Notes", "app"), "html", null, true);
            echo "</h5>
                    <div class=\"value\">";
            // line 310
            echo twig_escape_filter($this->env, (isset($context["revisionNotes"]) || array_key_exists("revisionNotes", $context) ? $context["revisionNotes"] : (function () { throw new RuntimeError('Variable "revisionNotes" does not exist.', 310, $this->source); })()), "html", null, true);
            echo "</div>
                </div>
            ";
        }
        // line 313
        echo "        ";
        craft\helpers\Template::endProfile("block", "meta");
    }

    // line 350
    public function block_settings($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "settings");
        // line 351
        echo "    ";
        if (((isset($context["showStatusToggles"]) || array_key_exists("showStatusToggles", $context) ? $context["showStatusToggles"] : (function () { throw new RuntimeError('Variable "showStatusToggles" does not exist.', 351, $this->source); })()) &&  !(isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 351, $this->source); })()))) {
            // line 352
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 353
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 353, $this->source); })()), "getAttributeStatus", [0 => "enabled"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "id" => "enabled", "name" => "enabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,             // line 357
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 357, $this->source); })()), "enabled", []), "disabled" =>             // line 358
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 358, $this->source); })())]], 352, $context, $this->getSourceContext());
            // line 359
            echo "
    ";
        }
        craft\helpers\Template::endProfile("block", "settings");
    }

    public function getTemplateName()
    {
        return "_layouts/element";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  760 => 359,  758 => 358,  757 => 357,  756 => 353,  754 => 352,  751 => 351,  746 => 350,  741 => 313,  735 => 310,  731 => 309,  728 => 308,  725 => 307,  722 => 306,  719 => 305,  716 => 304,  713 => 303,  710 => 302,  707 => 301,  705 => 300,  700 => 298,  696 => 297,  690 => 294,  686 => 293,  683 => 292,  675 => 289,  671 => 288,  668 => 287,  665 => 286,  662 => 285,  659 => 284,  656 => 283,  653 => 282,  650 => 281,  647 => 280,  644 => 279,  641 => 278,  638 => 277,  633 => 276,  625 => 345,  620 => 342,  617 => 337,  615 => 336,  610 => 334,  607 => 333,  604 => 332,  602 => 331,  599 => 330,  595 => 328,  593 => 322,  591 => 317,  589 => 316,  585 => 314,  583 => 276,  579 => 274,  574 => 271,  572 => 270,  571 => 269,  570 => 268,  569 => 267,  568 => 259,  567 => 258,  566 => 257,  565 => 256,  562 => 255,  560 => 254,  557 => 253,  551 => 250,  548 => 249,  545 => 248,  540 => 247,  532 => 243,  528 => 241,  522 => 239,  516 => 237,  513 => 236,  508 => 235,  500 => 232,  497 => 231,  491 => 229,  488 => 228,  485 => 226,  479 => 224,  476 => 223,  473 => 221,  468 => 219,  463 => 218,  461 => 217,  458 => 216,  456 => 215,  453 => 214,  448 => 213,  442 => 210,  435 => 206,  430 => 204,  426 => 203,  422 => 202,  418 => 201,  415 => 200,  412 => 199,  409 => 198,  403 => 195,  400 => 194,  397 => 193,  389 => 190,  386 => 189,  383 => 188,  380 => 187,  376 => 185,  374 => 184,  370 => 182,  368 => 181,  367 => 178,  364 => 177,  361 => 176,  359 => 175,  356 => 174,  351 => 173,  345 => 170,  343 => 168,  342 => 167,  340 => 166,  337 => 165,  332 => 164,  324 => 160,  321 => 159,  317 => 157,  311 => 155,  305 => 153,  303 => 152,  300 => 151,  298 => 150,  295 => 149,  288 => 146,  282 => 144,  280 => 143,  277 => 142,  275 => 141,  269 => 138,  265 => 137,  262 => 136,  257 => 135,  251 => 27,  245 => 418,  243 => 417,  241 => 415,  240 => 414,  239 => 413,  238 => 412,  237 => 411,  236 => 410,  235 => 409,  234 => 408,  233 => 407,  232 => 406,  231 => 405,  230 => 404,  229 => 403,  228 => 402,  227 => 401,  226 => 400,  225 => 399,  224 => 398,  223 => 397,  222 => 396,  221 => 395,  220 => 394,  219 => 393,  218 => 392,  217 => 391,  216 => 390,  213 => 386,  212 => 385,  209 => 383,  203 => 381,  199 => 380,  197 => 379,  195 => 378,  193 => 377,  192 => 376,  189 => 374,  187 => 373,  185 => 372,  183 => 371,  181 => 368,  180 => 367,  179 => 365,  177 => 363,  173 => 129,  172 => 127,  171 => 126,  170 => 124,  169 => 121,  167 => 120,  163 => 115,  162 => 113,  161 => 111,  159 => 110,  156 => 105,  155 => 104,  154 => 103,  152 => 102,  150 => 101,  148 => 96,  147 => 95,  145 => 94,  143 => 93,  141 => 91,  138 => 88,  136 => 87,  134 => 85,  131 => 82,  129 => 81,  127 => 80,  125 => 79,  123 => 77,  122 => 76,  121 => 75,  118 => 70,  115 => 68,  113 => 67,  111 => 66,  109 => 65,  106 => 62,  104 => 61,  102 => 59,  100 => 58,  98 => 57,  96 => 56,  94 => 55,  92 => 53,  90 => 52,  88 => 50,  86 => 49,  84 => 48,  82 => 47,  80 => 46,  78 => 45,  76 => 43,  74 => 42,  72 => 40,  70 => 39,  68 => 38,  66 => 37,  64 => 36,  62 => 35,  60 => 34,  58 => 33,  56 => 32,  54 => 31,  52 => 30,  50 => 28,  42 => 27,);
    }

    public function getSourceContext()
    {
        return new Source("{#
    \"Edit Element\" layout template

    The following variables should be defined by the sub-template:

    - element: the source element or one of its drafts/revisions
    - hasRevisions: whether the element has revisions, which will determine whether the revision notes field should be displayed.
    - canDeleteDraft (optional): whether the current user is allowed to delete the draft (if it is one).
      If the current user created the draft, then it will be deletable regardless.
    - canUpdateSource (optional): whether the current user is allowed to update the source element
      (e.g. by publishing a draft or reverting the element to a prior revision)
    - canDuplicateSource: whether the current user is allowed to duplicate the source element
    - canAddAnother: whether the current user is allowed to create another source element after saving the current one
    - canDeleteSource: whether the current user is allowed to delete the source element
    - redirectUrl: the URL that the user should be redirected to after saving the source element
    - addAnotherRedirectUrl: the URL that the user should be redirected to after opting to save and add another
    - saveSourceAction: the controller action that should be used to save the source element
    - duplicateSourceAction: the controller action that should be used to duplicate the source element
    - deleteSourceAction: the controller action that should be used to delete the source element
    - saveDraftAction: the controller action that should be used to save a draft
    - deleteDraftAction: the controller action that should be used to delete a draft
    - applyDraftAction: the controller action that should be used to apply a draft onto the source element
    - revertSourceAction: the controller action that should be used to revert the source element to a revision
    - showStatusToggles: whether the “Enabled” / “Enabled” for <Site>” fields should be added to the details pane
#}

{% extends '_layouts/cp' %}
{% import '_includes/forms' as forms %}

{% set isDraft = element.getIsDraft() %}
{% set isRevision = element.getIsRevision() %}
{% set isCurrent = not isDraft and not isRevision %}
{% set allSites = craft.app.isMultiSite ? element.getSupportedSites() : [element.siteId] %}
{% set allEditableSiteIds = craft.app.sites.getEditableSiteIds() %}
{% set propSiteIds = allSites|filter(s => s.propagate ?? true)|column(s => s.siteId ?? s) %}
{% set propEditableSiteIds = propSiteIds|intersect(allEditableSiteIds) %}
{% set isMultiSiteElement = craft.app.isMultiSite and allSites|length > 1 %}
{% set addlEditableSiteIds = allSites|column(s => s.siteId ?? s)|diff(propSiteIds)|intersect(allEditableSiteIds) %}
{% set canEditMultipleSites = isMultiSiteElement and (propEditableSiteIds|length > 1 or addlEditableSiteIds|length) %}
{% set isUnsavedDraft = element.getIsUnsavedDraft() %}

{% set previewTargets = element.getPreviewTargets() %}
{% set enablePreview = previewTargets and not craft.app.request.isMobileBrowser(true) %}

{% set canDeleteDraft = isDraft and not isUnsavedDraft and ((canDeleteDraft ?? false) or element.creatorId == currentUser.id) %}
{% set canUpdateSource = canUpdateSource ?? false %}
{% set canDuplicateSource = canDuplicateSource ?? false %}
{% set canAddAnother = canAddAnother ?? false %}
{% set canDeleteSource = canDeleteSource ?? false %}
{% set canEdit = canEdit ?? (canUpdateSource or canDuplicateSource or canAddAnother or saveDraftAction) %}

{% set redirectUrl = redirectUrl ?? element.cpEditUrl %}
{% set addAnotherRedirectUrl = addAnotherRedirectUrl ?? null %}

{% set saveSourceAction = saveSourceAction ?? null %}
{% set duplicateSourceAction = duplicateSourceAction ?? null %}
{% set deleteSourceAction = deleteSourceAction ?? null %}
{% set revertSourceAction = revertSourceAction ?? null %}
{% set saveDraftAction = saveDraftAction ?? null %}

{% if not isRevision %}
    {% set fullPageForm = true %}
{% endif %}

{% if isDraft %}
    {% do craft.app.session.authorize('previewDraft:' ~ element.draftId) %}
{% elseif isRevision %}
    {% do craft.app.session.authorize('previewRevision:' ~ element.revisionId) %}
{% else %}
    {% do craft.app.session.authorize('previewElement:' ~ element.id) %}
{% endif %}

{# If this is an unsaved draft, then we should only show status toggles if the
   user actually has permission to publish chanegs #}
{% set showStatusToggles = (showStatusToggles ?? true) and
    element.hasStatuses() and
    (not isUnsavedDraft or canUpdateSource) %}

{% if not isDraft and not canUpdateSource %}
    {% set saveShortcut = false %}
{% elseif isUnsavedDraft or (isCurrent and canUpdateSource) %}
    {% set saveShortcutRedirect = '{cpEditUrl}' %}
{% endif %}

{% set form = element.getFieldLayout().createForm(element, isRevision or not canEdit) %}

{% if tabs is not defined %}
    {% set tabs = form.getTabMenu() %}
{% endif %}

{% set settingsHtml = (block('settings') ?? '')|trim %}

{% set formActions = [] %}
{% if isUnsavedDraft or (canUpdateSource and saveSourceAction) %}
    {% set formActions = formActions|push({
        label: isUnsavedDraft ? 'Create and continue editing'|t('app') : 'Save and continue editing'|t('app'),
        redirect: '{cpEditUrl}'|hash,
        shortcut: true,
        retainScroll: true,
    }) %}
    {% if canUpdateSource %}
        {% if canAddAnother and addAnotherRedirectUrl %}
            {% set formActions = formActions|push({
                label: isUnsavedDraft ? 'Create and add another'|t('app') : 'Save and add another'|t('app'),
                redirect: addAnotherRedirectUrl|hash,
                shortcut: true,
                shift: true,
            }) %}
        {% endif %}
        {% if not isUnsavedDraft and canDuplicateSource and duplicateSourceAction %}
            {% set formActions = formActions|push({
                label: 'Save as a new {type}'|t('app', {
                    type: element.lowerDisplayName(),
                }),
                action: duplicateSourceAction,
                redirect: '{cpEditUrl}'|hash,
            }) %}
        {% endif %}
    {% endif %}
    {% if not isUnsavedDraft and canDeleteSource and deleteSourceAction %}
        {% set formActions = formActions|push({
            destructive: true,
            label: 'Delete {type}'|t('app', {
                type: element.lowerDisplayName()
            }),
            action: deleteSourceAction,
            redirect: (redirectUrl ~ '#')|hash,
            confirm: 'Are you sure you want to delete this {type}?'|t('app', {
                type: element.lowerDisplayName(),
            }),
        }) %}
    {% endif %}
{% endif %}

{% block header %}
    <div class=\"flex flex-nowrap\">
        {{ block('pageTitle') }}
        {{ block('contextMenu') }}
    </div>
    <div class=\"flex\" id=\"action-buttons\">
        {% if previewTargets %}
            <div class=\"btngroup\">
                {% if enablePreview %}
                    <button type=\"button\" id=\"preview-btn\" class=\"btn\">{{ \"Preview\"|t('app') }}</button>
                {% endif %}
                <button type=\"button\" id=\"share-btn\" class=\"btn\">{{ 'Share'|t('app') }}</button>
            </div>
        {% endif %}

        {% if isCurrent and saveDraftAction %}
            <div id=\"save-draft-btn-container\">
                {% if canUpdateSource and saveSourceAction %}
                    <button type=\"button\" id=\"save-draft-btn\" class=\"btn\">{{ 'Save as a draft'|t('app') }}</button>
                {% else %}
                    <button type=\"submit\" id=\"save-draft-btn\" class=\"btn submit\">{{ 'Save as a draft'|t('app') }}</button>
                {% endif %}
            </div>
        {% endif %}

        {{ block('actionButton') }}
    </div>
{% endblock %}

{% block contextMenu %}
    {% if isMultiSiteElement or saveDraftAction or element.find().revisionOf(element).exists() %}
        {% include \"_includes/revisionmenu\" with {
            supportedSiteIds: propSiteIds,
            canHaveDrafts: saveDraftAction is not empty,
        } %}
    {% endif %}
{% endblock %}

{% block actionButton %}
    {% if isUnsavedDraft or isCurrent %}
        {# Can they save the source element, and do we know how to save it? #}
        {% if isUnsavedDraft or (canUpdateSource and saveSourceAction) %}
            <div id=\"save-btn-container\" class=\"btngroup submit\">
                {{ tag('button', {
                    type: 'submit',
                    class: ['btn', 'submit'],
                    text: isUnsavedDraft ? 'Create'|t('app') : 'Save'|t('app'),
                }) }}
                <button type=\"button\" class=\"btn submit menubtn\"></button>
                {% include '_layouts/components/form-action-menu' %}
            </div>
        {% endif %}
    {% elseif isDraft %}
        {% if canUpdateSource and saveSourceAction and (applyDraftAction ?? false) %}
            <div id=\"publish-changes-btn-container\">
                <button type=\"button\" class=\"btn secondary formsubmit\" data-action=\"{{ applyDraftAction }}\">{{ 'Publish changes'|t('app') }}</button>
            </div>
        {% endif %}
        {% if not craft.app.config.general.autosaveDrafts %}
            <div id=\"save-btn-container\">
                <button type=\"submit\" class=\"btn submit\">{{ 'Save draft'|t('app') }}</button>
            </div>
        {% endif %}
    {% elseif isRevision %}
        {% if canUpdateSource and revertSourceAction %}
            <form method=\"post\" accept-charset=\"UTF-8\">
                {{ csrfInput() }}
                {{ actionInput(revertSourceAction) }}
                {{ redirectInput('{cpEditUrl}') }}
                {{ hiddenInput('revisionId', element.revisionId) }}
                <div class=\"secondary-buttons\">
                    <button type=\"button\" class=\"btn submit formsubmit\">{{ 'Revert {type} to this revision'|t('app', { type: element.lowerDisplayName() }) }}</button>
                </div>
            </form>
        {% endif %}
    {% endif %}
{% endblock %}

{% block main %}
    {% if fullPageForm %}
        {# action and redirect params #}
        {% if not isDraft and canUpdateSource and saveSourceAction %}
            {# current revision -- user can update source #}
            {{ actionInput(saveSourceAction) }}
            {{ redirectInput(redirectUrl) }}
        {% endif %}

        {# siteId param #}
        {% if craft.app.isMultiSite %}
            {{ hiddenInput('siteId', element.siteId) }}
        {% endif %}

        {# propagateAll param #}
        {% if isUnsavedDraft and craft.app.request.getQueryParam('fresh') %}
            {{ hiddenInput('propagateAll', '1') }}
        {% endif %}
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block content %}
    {% if not isRevision %}
        {{ hiddenInput('sourceId', element.getSourceId()) }}
    {% else %}
        {{ hiddenInput('revisionId', entry.revisionId) }}
    {% endif %}

    <div id=\"fields\">
        {{ form.render()|raw }}
    </div>
{% endblock %}

{% block details %}
    {% if settingsHtml %}
        <div id=\"settings\" class=\"meta\">
            {{ settingsHtml|raw }}
        </div>
    {% endif %}

    {% if showStatusToggles and isMultiSiteElement %}
        <div class=\"meta\">
            {{ forms.lightswitchField({
                status: element.getAttributeStatus('enabled'),
                label: 'Enabled for {site}'|t('app', { site: element.site.name|t('site')|e }) ~
                    (canEditMultipleSites ? tag('button', {
                        type: 'button',
                        id: 'expand-status-btn',
                        class: ['btn'],
                        data: {
                            icon: 'ellipsis',
                        },
                    })),
                id: \"enabledForSite-#{element.siteId}\",
                name: \"enabledForSite[#{element.siteId}]\",
                on: element.enabled and element.getEnabledForSite(),
                disabled: isRevision,
            }) }}
        </div>
    {% endif %}

    <div id=\"meta-details\" class=\"meta read-only\">
        {% block meta %}
            {% if element.hasStatuses() %}
                {% if isUnsavedDraft %}
                    {% set statusColor = 'white' %}
                    {% set statusLabel = 'Draft'|t('app') %}
                {% else %}
                    {% set status = element.getStatus() %}
                    {% set statusDef = element.statuses()[status] ?? null %}
                    {% set statusColor = statusDef.color ?? status %}
                    {% set statusLabel = statusDef.label ?? statusDef ?? status|ucfirst %}
                {% endif %}
                <div class=\"data\">
                    <h5 class=\"heading\">{{ 'Status'|t('app') }}</h5>
                    <div id=\"status-value\" class=\"value\"><span class=\"status {{ statusColor }}\"></span>{{ statusLabel }}</div>
                </div>
            {% endif %}
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Created at\"|t('app') }}</h5>
                <div id=\"date-created-value\" class=\"value\">{{ element.dateCreated|datetime('short') }}</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Updated at\"|t('app') }}</h5>
                <div id=\"date-updated-value\" class=\"value\">{{ element.dateUpdated|datetime('short') }}</div>
            </div>
            {% if isRevision %}
                {% set revisionNotes = element.revisionNotes %}
            {% elseif not isDraft and element.currentRevision %}
                {% set revisionNotes = element.currentRevision.revisionNotes %}
            {% else %}
                {% set revisionNotes = null %}
            {% endif %}
            {% if revisionNotes %}
                <div class=\"data\">
                    <h5 class=\"heading\">{{ \"Notes\"|t('app') }}</h5>
                    <div class=\"value\">{{ revisionNotes }}</div>
                </div>
            {% endif %}
        {% endblock %}
    </div>

    {% if isCurrent and (hasRevisions ?? false) %}
        {{ forms.textarea({
            id: 'revision-notes',
            class: ['nicetext'],
            name: 'revisionNotes',
            placeholder: 'Notes about your changes'|t('app'),
            value: revisionNotes ?? null,
            inputAttributes: {
                aria: {
                    label: 'Notes about your changes'|t('app'),
                },
            },
        }) }}
    {% endif %}

    {% if isDraft and element.getIsOutdated() %}
        {% do craft.app.session.authorize('mergeDraftSourceChanges:' ~ element.draftId) %}
        <div class=\"meta read-only warning\">
            <p>{{ 'The source {type} has been updated recently.'|t('app', {type: element.lowerDisplayName()}) }}</p>
            <div class=\"flex flex-nowrap\">
                {% if element.trackChanges %}
                    {{ tag('button', {
                        type: 'button',
                        id: 'merge-changes-btn',
                        class: ['btn'],
                        text: 'Merge changes into draft'|t('app'),
                    }) }}
                    <div id=\"merge-changes-spinner\" class=\"spinner hidden\"></div>
                {% endif %}
            </div>
        </div>
    {% endif %}
{% endblock %}

{% block settings %}
    {% if showStatusToggles and not isMultiSiteElement %}
        {{ forms.lightswitchField({
            status: element.getAttributeStatus('enabled'),
            label: 'Enabled'|t('app'),
            id: 'enabled',
            name: 'enabled',
            on: element.enabled,
            disabled: isRevision,
        }) }}
    {% endif %}
{% endblock %}

{% if canEditMultipleSites and element.enabled %}
    {# get the element's statuses across all sites #}
    {% set siteStatusesQuery = element.find()
        .select(['elements_sites.siteId', 'elements_sites.enabled'])
        .id(element.id)
        .siteId(propEditableSiteIds)
        .anyStatus()
        .asArray() %}
    {% if isDraft %}
        {% do siteStatusesQuery.drafts() %}
    {% elseif isRevision %}
        {% do siteStatusesQuery.revisions() %}
    {% endif %}
    {% set siteStatuses = siteStatusesQuery
        .pairs()|map(s => s ? true : false) %}
{% elseif canEditMultipleSites %}
    {% set siteStatusValues = {} %}
    {% for siteId in propEditableSiteIds %}
        {% set siteStatusValues = siteStatusValues|merge([false]) %}
    {% endfor %}
    {% set siteStatuses = combine(propEditableSiteIds, siteStatusValues) %}
{% else %}
    {% set siteStatuses = {
        (\"#{element.siteId}\"): element.enabled ? true : false
    } %}
{% endif %}

{% set settings = {
    elementType: className(element),
    elementTypeDisplayName: element.displayName(),
    sourceId: element.getSourceId(),
    siteId: element.siteId,
    siteToken: not element.getSite().enabled ? element.siteId|hash,
    isUnsavedDraft: isUnsavedDraft,
    siteStatuses: siteStatuses,
    addlSiteIds: addlEditableSiteIds|values,
    enabled: element.enabled ? true : false,
    enabledForSite: element.enabled and element.getEnabledForSite(),
    isLive: isCurrent and element.enabled and element.getEnabledForSite() and element.getRoute(),
    cpEditUrl: element.cpEditUrl,
    hashedRedirectUrl: (isUnsavedDraft ? redirectUrl : '{cpEditUrl}')|hash,
    draftId: element.draftId,
    revisionId: element.revisionId,
    draftName: isDraft ? element.draftName : null,
    draftNotes: isDraft ? element.draftNotes : null,
    canEditMultipleSites: canEditMultipleSites,
    canDeleteDraft: canDeleteDraft,
    canUpdateSource: canUpdateSource,
    saveDraftAction: saveDraftAction,
    deleteDraftAction: deleteDraftAction ?? null,
    applyDraftAction: applyDraftAction ?? null,
    enablePreview: enablePreview,
    previewTargets: previewTargets,
} %}
{% js %}
    window.draftEditor = new Craft.DraftEditor({{ settings|json_encode|raw }});
{% endjs %}
", "_layouts/element", "/home/ubuntu/sites/seekult-nitro/craft/vendor/craftcms/cms/src/templates/_layouts/element.html");
    }
}

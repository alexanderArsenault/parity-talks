<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__66bb4bbccf3eb88bd0c6ad023abe76c4675ee9a28a846bfa33f14cfac402e7af */
class __TwigTemplate_1cef04684f6d67aadd143dd6ca02a02eff6c558a58f7b5e340955aece46730f9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__66bb4bbccf3eb88bd0c6ad023abe76c4675ee9a28a846bfa33f14cfac402e7af");
        // line 1
        echo "artist/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        craft\helpers\Template::endProfile("template", "__string_template__66bb4bbccf3eb88bd0c6ad023abe76c4675ee9a28a846bfa33f14cfac402e7af");
    }

    public function getTemplateName()
    {
        return "__string_template__66bb4bbccf3eb88bd0c6ad023abe76c4675ee9a28a846bfa33f14cfac402e7af";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("artist/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__66bb4bbccf3eb88bd0c6ad023abe76c4675ee9a28a846bfa33f14cfac402e7af", "");
    }
}

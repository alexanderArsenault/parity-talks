<?php
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

use yii\base\Behavior;

/**
 * Custom field behavior
 *
 * This class provides attributes for all the unique custom field handles.
 *
 * @method static artistImage(mixed $value) Sets the [[artistImage]] property
 * @method static artistCategory(mixed $value) Sets the [[artistCategory]] property
 * @method static artistText(mixed $value) Sets the [[artistText]] property
 * @method static text(mixed $value) Sets the [[text]] property
 * @method static image(mixed $value) Sets the [[image]] property
 * @method static privacyTitle(mixed $value) Sets the [[privacyTitle]] property
 * @method static privacyText(mixed $value) Sets the [[privacyText]] property
 * @method static contactHeader(mixed $value) Sets the [[contactHeader]] property
 * @method static contactText(mixed $value) Sets the [[contactText]] property
 * @method static aboutContent(mixed $value) Sets the [[aboutContent]] property
 * @method static sectionTitle(mixed $value) Sets the [[sectionTitle]] property
 * @method static artistLinkTwitter(mixed $value) Sets the [[artistLinkTwitter]] property
 * @method static artistLinkFacebook(mixed $value) Sets the [[artistLinkFacebook]] property
 * @method static artistLinkInstagram(mixed $value) Sets the [[artistLinkInstagram]] property
 * @method static artistLinkYoutube(mixed $value) Sets the [[artistLinkYoutube]] property
 * @method static artistLinkVimeo(mixed $value) Sets the [[artistLinkVimeo]] property
 * @method static artistLinkSoundcloud(mixed $value) Sets the [[artistLinkSoundcloud]] property
 * @method static artistLinkSpotify(mixed $value) Sets the [[artistLinkSpotify]] property
 * @method static artistLinkWebsite(mixed $value) Sets the [[artistLinkWebsite]] property
 * @method static logbookResponses(mixed $value) Sets the [[logbookResponses]] property
 * @method static responseName(mixed $value) Sets the [[responseName]] property
 * @method static responseTitle(mixed $value) Sets the [[responseTitle]] property
 * @method static photo(mixed $value) Sets the [[photo]] property
 * @method static video(mixed $value) Sets the [[video]] property
 * @method static linkToAudio(mixed $value) Sets the [[linkToAudio]] property
 * @method static entryDate(mixed $value) Sets the [[entryDate]] property
 */
class CustomFieldBehavior extends Behavior
{
    /**
     * @var bool Whether the behavior should provide methods based on the field handles.
     */
    public $hasMethods = false;

    /**
     * @var string[] List of supported field handles.
     */
    public static $fieldHandles = [
        'artistImage' => true,
        'artistCategory' => true,
        'artistText' => true,
        'text' => true,
        'image' => true,
        'privacyTitle' => true,
        'privacyText' => true,
        'contactHeader' => true,
        'contactText' => true,
        'aboutContent' => true,
        'sectionTitle' => true,
        'artistLinkTwitter' => true,
        'artistLinkFacebook' => true,
        'artistLinkInstagram' => true,
        'artistLinkYoutube' => true,
        'artistLinkVimeo' => true,
        'artistLinkSoundcloud' => true,
        'artistLinkSpotify' => true,
        'artistLinkWebsite' => true,
        'logbookResponses' => true,
        'responseName' => true,
        'responseTitle' => true,
        'photo' => true,
        'video' => true,
        'linkToAudio' => true,
        'entryDate' => true,
    ];

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “artistImage”.
     */
    public $artistImage;

    /**
     * @var \craft\elements\db\CategoryQuery Value for field with the handle “artistCategory”.
     */
    public $artistCategory;

    /**
     * @var mixed Value for field with the handle “artistText”.
     */
    public $artistText;

    /**
     * @var mixed Value for field with the handle “text”.
     */
    public $text;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “image”.
     */
    public $image;

    /**
     * @var string|null Value for field with the handle “privacyTitle”.
     */
    public $privacyTitle;

    /**
     * @var string|null Value for field with the handle “privacyText”.
     */
    public $privacyText;

    /**
     * @var string|null Value for field with the handle “contactHeader”.
     */
    public $contactHeader;

    /**
     * @var string|null Value for field with the handle “contactText”.
     */
    public $contactText;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “aboutContent”.
     */
    public $aboutContent;

    /**
     * @var string|null Value for field with the handle “sectionTitle”.
     */
    public $sectionTitle;

    /**
     * @var string|null Value for field with the handle “artistLinkTwitter”.
     */
    public $artistLinkTwitter;

    /**
     * @var string|null Value for field with the handle “artistLinkFacebook”.
     */
    public $artistLinkFacebook;

    /**
     * @var string|null Value for field with the handle “artistLinkInstagram”.
     */
    public $artistLinkInstagram;

    /**
     * @var string|null Value for field with the handle “artistLinkYoutube”.
     */
    public $artistLinkYoutube;

    /**
     * @var string|null Value for field with the handle “artistLinkVimeo”.
     */
    public $artistLinkVimeo;

    /**
     * @var string|null Value for field with the handle “artistLinkSoundcloud”.
     */
    public $artistLinkSoundcloud;

    /**
     * @var string|null Value for field with the handle “artistLinkSpotify”.
     */
    public $artistLinkSpotify;

    /**
     * @var string|null Value for field with the handle “artistLinkWebsite”.
     */
    public $artistLinkWebsite;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “logbookResponses”.
     */
    public $logbookResponses;

    /**
     * @var string|null Value for field with the handle “responseName”.
     */
    public $responseName;

    /**
     * @var string|null Value for field with the handle “responseTitle”.
     */
    public $responseTitle;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “photo”.
     */
    public $photo;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “video”.
     */
    public $video;

    /**
     * @var string|null Value for field with the handle “linkToAudio”.
     */
    public $linkToAudio;

    /**
     * @var \DateTime|null Value for field with the handle “entryDate”.
     */
    public $entryDate;

    /**
     * @var array Additional custom field values we don’t know about yet.
     */
    private $_customFieldValues = [];

    /**
     * @inheritdoc
     */
    public function __call($name, $params)
    {
        if ($this->hasMethods && isset(self::$fieldHandles[$name]) && count($params) === 1) {
            $this->$name = $params[0];
            return $this->owner;
        }
        return parent::__call($name, $params);
    }

    /**
     * @inheritdoc
     */
    public function hasMethod($name)
    {
        if ($this->hasMethods && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::hasMethod($name);
    }

    /**
     * @inheritdoc
     */
    public function __isset($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::__isset($name);
    }

    /**
     * @inheritdoc
     */
    public function __get($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return $this->_customFieldValues[$name] ?? null;
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        if (isset(self::$fieldHandles[$name])) {
            $this->_customFieldValues[$name] = $value;
            return;
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public function canGetProperty($name, $checkVars = true)
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canGetProperty($name, $checkVars);
    }

    /**
     * @inheritdoc
     */
    public function canSetProperty($name, $checkVars = true)
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canSetProperty($name, $checkVars);
    }
}
